"""Fetch exact external assets, or import them from the supplied archives.

No third-party dependencies. ZIP range requests retrieve a single member and
verify its CRC. All outputs must match the checked-in SHA256 manifest.
"""
import argparse
import datetime
import hashlib
import io
import json
import re
import struct
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
GROUPS = {
    'molecular': ['bbbp', 'hiv', 'bace', 'pretrained_gcn', 'pretrained_gin'],
    'xe135': ['endf8_xe135', 'tendl2021_xe135', 'cendl32_xe135'],
    'transfer': ['endf8_fe56', 'endf8_u235', 'cendl32_fe56', 'cendl32_u235'],
}


def request_bytes(url, start=None, end=None, suffix=None):
    for attempt in range(3):
        try:return _request_bytes(url,start,end,suffix)
        except urllib.error.URLError as exc:
            if isinstance(exc,urllib.error.HTTPError) and exc.code not in (429,500,502,503,504):raise
            if attempt==2:raise
            time.sleep(.5*(attempt+1))


def _request_bytes(url, start=None, end=None, suffix=None):
    headers = {'User-Agent': 'SwarmPNMResearch/0.2', 'Accept-Encoding': 'identity'}
    if suffix is not None:
        headers['Range'] = f'bytes=-{suffix}'
    elif start is not None:
        headers['Range'] = f'bytes={start}-{end}'
    with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=60) as response:
        status = response.status
        if start is not None or suffix is not None:
            if status != 206:
                raise ValueError('Server does not support byte ranges; use --archive with the downloaded ZIP')
            match = re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)', response.headers.get('Content-Range', ''))
            if match is None:
                raise ValueError('Missing/invalid HTTP Content-Range')
            a, b, total = map(int, match.groups())
            if suffix is not None:
                expected = (max(0, total-suffix), total-1)
            else:
                expected = (start, end)
            if (a, b) != expected:
                raise ValueError('HTTP range does not match requested bytes')
            limit = b-a+1
        else:
            # Largest direct asset here is 10 MB; reject oversized responses.
            limit = 32 * 1024 * 1024
        data = response.read(limit+1)
        if len(data) > limit or (status == 206 and len(data) != limit):
            raise ValueError('Wrong HTTP response length')
        return data


def zip_member(url, member):
    tail = request_bytes(url, suffix=65557)
    offset = tail.rfind(b'PK\x05\x06')
    if offset < 0 or len(tail)-offset < 22:
        raise ValueError('Missing ZIP end record')
    record = struct.unpack('<4s4H2LH', tail[offset:offset+22])
    if record[1] or record[2] or record[3] != record[4] or record[5] == 0xffffffff or record[6] == 0xffffffff:
        raise ValueError('Multi-disk/ZIP64 archives are not supported')
    size, position = record[5:7]
    central = request_bytes(url, position, position+size-1)
    virtual_end = struct.pack('<4s4H2LH', b'PK\x05\x06', 0, 0, record[3], record[4], size, 0, 0)
    with zipfile.ZipFile(io.BytesIO(central+virtual_end)) as archive:
        entry = archive.getinfo(member)
    # Virtual ZIP may adjust offsets; the original directory supplies the true one.
    cursor = 0
    selected = None
    while cursor < len(central):
        header = struct.unpack('<4s6H3L5H2L', central[cursor:cursor+46])
        if header[0] != b'PK\x01\x02':raise ValueError('Invalid central directory')
        n, extra, comment = header[10:13]
        length = 46+n+extra+comment
        name = central[cursor+46:cursor+46+n].decode('utf-8' if header[3]&0x800 else 'cp437')
        if name == member:
            selected = bytearray(central[cursor:cursor+length]);original_offset = header[-1];break
        cursor += length
    if selected is None:raise ValueError('Missing requested ZIP member')
    local = request_bytes(url, original_offset, original_offset+29)
    fields = struct.unpack('<4s5H3L2H', local)
    if fields[0] != b'PK\x03\x04':raise ValueError('Invalid local ZIP header')
    n, extra = fields[-2:]
    if entry.compress_size > 128*1024*1024 or entry.file_size > 128*1024*1024:
        raise ValueError('ZIP member exceeds the supported asset size')
    block = request_bytes(url, original_offset, original_offset+30+n+extra+entry.compress_size-1)
    selected[42:46] = struct.pack('<L', 0)
    end = struct.pack('<4s4H2LH', b'PK\x05\x06', 0, 0, 1, 1, len(selected), len(block), 0)
    with zipfile.ZipFile(io.BytesIO(block+selected+end)) as archive:
        return archive.read(member)  # ZipFile checks the member CRC.


def local_member(path, asset):
    if path.is_dir():
        candidate = path/Path(asset['target']).name
        return candidate.read_bytes()
    with zipfile.ZipFile(path) as archive:
        if 'member' in asset:
            return archive.read(asset['member'])
        filename = Path(asset['target']).name
        backbone = filename.removeprefix('pretrained_').removesuffix('.pth')
        if filename.startswith('pretrained_'):
            matches = [n for n in archive.namelist() if n.endswith(f'ckpt/pretrained_{backbone}/checkpoints/model.pth') or n.endswith('/'+filename)]
        else:
            matches = [n for n in archive.namelist() if n.endswith('/'+filename) or n == filename]
        if len(matches) != 1:raise ValueError(f'Expected one matching file in archive: {filename}, found {len(matches)}')
        return archive.read(matches[0])


def fetch(name, asset, root=ROOT, archive=None):
    root = Path(root).resolve()
    target = (root/asset['target']).resolve()
    if not target.is_relative_to(root):raise ValueError('Asset target escapes repository')
    if target.exists():
        if hashlib.sha256(target.read_bytes()).hexdigest() != asset['sha256']:
            raise ValueError(f'Existing {target.name} differs from manifest; preserve it and use a separate output directory')
        acquisition=target.with_name(target.stem+'_acquisition.json')
        if not acquisition.exists():
            acquisition.write_text(json.dumps(dict(url=asset['url'],member=asset.get('member'),bytes=asset['bytes'],sha256=asset['sha256'],method='existing local file; SHA256 verified'),indent=2),encoding='utf-8')
        print(name, 'already verified', flush=True);return target
    data = local_member(Path(archive), asset) if archive else (zip_member(asset['url'], asset['member']) if 'member' in asset else request_bytes(asset['url']))
    source_sha=hashlib.sha256(data).hexdigest()
    if not archive and asset.get('transform'):
        if source_sha!=asset['source_sha256']:raise ValueError('Upstream raw file hash differs from transform manifest')
        if asset['transform']!='bace_header_mol_to_smiles' or not data.startswith(b'mol,'):
            raise ValueError('Unsupported asset transform or unexpected CSV header')
        data=b'smiles,'+data[4:]
    if len(data) != asset['bytes'] or hashlib.sha256(data).hexdigest() != asset['sha256']:
        raise ValueError(f'{name}: source differs from reconstruction manifest; import the original archive with --archive; no replacement accepted')
    target.parent.mkdir(parents=True, exist_ok=True)
    temp = target.with_name(target.name+'.download.tmp')
    temp.write_bytes(data);temp.replace(target)
    record = dict(url=asset['url'], member=asset.get('member'), bytes=len(data), sha256=asset['sha256'],source_sha256=source_sha,
                  transform=asset.get('transform') if not archive else None,
                  retrieved_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  method='local verified import' if archive else 'HTTP; ZIP member CRC checked when applicable')
    target.with_name(target.stem+'_acquisition.json').write_text(json.dumps(record, indent=2), encoding='utf-8')
    print(name, 'verified', len(data), 'bytes', flush=True)
    return target


def main():
    assets = json.loads((ROOT/'configs/assets.json').read_text(encoding='utf-8'))
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--group', choices=list(GROUPS)+['all'])
    parser.add_argument('--asset', choices=list(assets), action='append')
    parser.add_argument('--archive', type=Path, help='Local original ZIP, or directory of downloaded asset files')
    parser.add_argument('--output-root', type=Path, default=ROOT)
    args = parser.parse_args()
    names = args.asset or (list(assets) if args.group == 'all' else GROUPS.get(args.group, []))
    if not names:parser.error('Choose --group or at least one --asset')
    failures=[]
    for name in names:
        try:fetch(name, assets[name], args.output_root, args.archive)
        except (OSError,ValueError,KeyError,zipfile.BadZipFile) as exc:
            failures.append(name);print(f'{name}: {type(exc).__name__}: {exc}',flush=True)
    if failures:raise SystemExit('Assets not acquired: '+', '.join(failures)+'. Retry or import a downloaded archive with --archive.')


if __name__ == '__main__':main()
