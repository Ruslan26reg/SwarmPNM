"""Exact Xe135 rerun and shuffled-train-label negative control, with held-out labels intact."""
import argparse
import copy
import csv
import json
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
import torch
from torch import nn
from swarmpnmlab.registry import make_method
from swarmpnmlab.training import RepeatableClosure
from nuclear.architectures import make_architecture
from nuclear.metrics import regression_metrics
from scripts.run_nuclear import ROOT,prediction,save_json,save_csv


def main(run_name):
    torch.set_num_threads(1)
    ref=ROOT/'results/nuclear/xe135_architecture_refit_v1'
    final=json.loads((ref/'final.json').read_text())
    reference=torch.load(ref/final['winner']['candidate']/'seed0/best_train.pt',weights_only=True,map_location='cpu')
    out=ROOT/'results/nuclear'/run_name
    if out.exists():raise ValueError('Preserve earlier controls')
    out.mkdir(parents=True)
    rows=list(csv.DictReader((ref/'dataset_native.csv').open()))
    energy=np.array([float(r['energy_ev'])/1e6 for r in rows])
    y=np.array([float(r['sigma_barn']) for r in rows])
    split=reference['split'];train=np.array(split['train_ids']);test=np.array(split['test_ids'])
    x=torch.tensor(((energy-split['input_mean_mev'])/split['input_std_mev'])[:,None],dtype=torch.float32)
    target=torch.tensor(y[:,None],dtype=torch.float32)
    save_json(out/'protocol.json',dict(reference_run=ref.name,seed=0,epochs=reference['epoch'],
        architecture=reference['spec'],swarmpnm_config=reference['swarmpnm_config'],split=split,
        negative_control='Shuffle ONLY 112 training labels with fixed RNG seed 20261011. Hold-out targets remain untouched; no tuning.',
        checks='Bitwise re-run comparison to previous model personal best AND training_last_model; negative-control test R2 compared with actual test R2.'))
    records=[]
    for control in ['exact_rerun','shuffled_training_labels']:
        labels=target.clone()
        permutation=None
        if control=='shuffled_training_labels':
            permutation=np.random.default_rng(20261011).permutation(train)
            labels[train]=target[permutation]
        torch.manual_seed(0)
        model=make_architecture(reference['spec'],x[train],labels[train])
        opt,_=make_method('swarmpnm_sqrt',model.parameters(),reference['swarmpnm_config'])
        for epoch in range(reference['epoch']):
            model.train()
            closure=RepeatableClosure(model,opt,lambda:nn.functional.mse_loss(model(x[train]),labels[train]))
            try:opt.step(closure)
            finally:closure.commit()
        last=copy.deepcopy(model.state_dict())
        with torch.no_grad():
            for p in model.parameters():p.copy_(opt.state[p]['best'])
        predicted=prediction(model,x[test]);result=dict(control=control,**regression_metrics(y[test],predicted))
        if control=='exact_rerun':
            best_equal=all(torch.equal(value,reference['model'][key]) for key,value in model.state_dict().items())
            last_equal=all(torch.equal(value,reference['training_last_model'][key]) for key,value in last.items())
            if not best_equal or not last_equal:raise AssertionError('Exact CPU rerun differs from recorded weights')
            result.update(personal_best_weights_bitwise_equal=best_equal,last_weights_bitwise_equal=last_equal)
        else:
            result.update(shuffled_train_row_ids=permutation.tolist(),test_targets_unchanged=True,
                          control_reduces_test_r2=result['r2']<records[0]['r2']-.2)
            if not result['control_reduces_test_r2']:raise AssertionError('Shuffled-label control did not substantially degrade held-out prediction')
        records.append(result)
        save_csv(out/f'{control}_test_predictions.csv',[dict(**rows[int(i)],prediction_barn=float(p)) for i,p in zip(test,predicted)])
        save_json(out/f'{control}.json',result)
        print('CONTROL',json.dumps(result),flush=True)
    save_json(out/'results.json',records);save_json(out/'status.json',dict(status='passed',results=records))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--run-name',required=True)
    main(parser.parse_args().run_name)
