"""Deterministic benchmarks and neural backpropagation checks, with raw CSV."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import argparse,copy,csv,json,math,time,platform
import numpy as np
import torch
from swarmpnmlab.registry import make_method,METHODS
from swarmpnmlab.optimizers import SwarmPNM

ROOT=Path(__file__).resolve().parents[1]
def finite(x):
    if isinstance(x,torch.Tensor): return bool(torch.isfinite(x).all())
    if isinstance(x,dict): return all(finite(v) for v in x.values())
    if isinstance(x,(list,tuple)): return all(finite(v) for v in x)
    return not isinstance(x,float) or math.isfinite(x)

def functions(name,x):
    if name=='sphere': return x.square().sum(dim=-1)
    if name=='rosenbrock': return 100*(x[...,1]-x[...,0]**2)**2+(1-x[...,0])**2
    return 20+(x.square()-10*torch.cos(2*math.pi*x)).sum(dim=-1)

def write_csv(name,rows):
    dest=ROOT/'results'/name
    with dest.open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)

def benchmarks(config,steps):
    rows=[]; trajectories=[]
    for function in ['sphere','rosenbrock','rastrigin']:
        for seed in config['seeds']:
            rng=np.random.default_rng(seed); start=rng.uniform(-1.5,1.5,2)
            for name in METHODS:
                torch.manual_seed(seed); p=torch.nn.Parameter(torch.tensor(start,dtype=torch.float64))
                cfg=copy.deepcopy(config['methods'][name])
                if 'seed' in cfg: cfg['seed']=seed
                if name=='adaswarm': cfg['swarm']['seed']=seed
                opt,criterion=make_method(name,[p],cfg); evaluations=0
                def objective(x):
                    nonlocal evaluations; evaluations+=1; return functions(function,x)
                def batched_objective(x):
                    nonlocal evaluations; evaluations+=len(x); return functions(function,x)
                def closure():
                    opt.zero_grad(); loss=objective(p); loss.backward(); return loss
                initial=float(objective(p).detach()); best=initial; status='ok'; error=''; tic=time.perf_counter(); last=initial; completed=0
                for step in range(steps):
                    try:
                        if isinstance(opt,SwarmPNM): opt.step(closure)
                        else:
                            opt.zero_grad()
                            loss=criterion(p,loss_fn=objective,fitness_fn=batched_objective) if criterion else objective(p)
                            loss.backward(); opt.step()
                            with torch.no_grad(): p.clamp_(-10,10)
                        last=float(objective(p).detach())
                        if not finite([p,opt.state_dict(),last]): raise FloatingPointError('non-finite state/loss')
                        best=min(best,last); completed=step+1
                        trajectories.append(dict(problem=function,method=name,seed=seed,step=step+1,loss=last,x=float(p[0].detach()),y=float(p[1].detach())))
                    except Exception as e: status='error'; error=f'{type(e).__name__}: {e}'; break
                rows.append(dict(problem=function,method=name,seed=seed,start_x=start[0],start_y=start[1],initial_loss=initial,final_loss=last,best_loss=best,steps=completed,step_budget=steps,objective_evaluations=evaluations,seconds=time.perf_counter()-tic,status=status,decreased=best<initial,converged=best<1e-6,error=error))
                print(function,name,seed,status,f'{initial:.5g} -> {last:.5g}',flush=True)
    write_csv('benchmarks.csv',rows); write_csv('benchmark_trajectories.csv',trajectories)
    return rows

def regression(config,steps):
    rows=[]
    for seed in config['seeds']:
        torch.manual_seed(seed); x=torch.randn(64,3,dtype=torch.float64); y=(.6*x[:,0]-.4*x[:,1]+.3*x[:,2]).unsqueeze(1)
        initial_model=torch.nn.Sequential(torch.nn.Linear(3,8),torch.nn.Tanh(),torch.nn.Linear(8,1)).double(); snapshot=copy.deepcopy(initial_model.state_dict())
        for name in METHODS:
            model=copy.deepcopy(initial_model); model.load_state_dict(snapshot)
            cfg=copy.deepcopy(config['methods'][name])
            if 'seed' in cfg: cfg['seed']=seed
            if name=='adaswarm': cfg['swarm'].update(seed=seed,bounds=None)
            opt,criterion=make_method(name,model.parameters(),cfg)
            def mse(): return (model(x)-y).square().mean()
            def closure(): opt.zero_grad(); loss=mse(); loss.backward(); return loss
            initial=float(mse().detach()); status='ok'; error=''; tic=time.perf_counter(); completed=0; final=initial
            for step in range(steps):
                try:
                    if isinstance(opt,SwarmPNM): opt.step(closure)
                    else:
                        opt.zero_grad(); prediction=model(x)
                        loss=criterion(prediction,y,center=y,fitness_fn=lambda z:(z-y).square().mean(dim=(1,2))) if criterion else (prediction-y).square().mean()
                        loss.backward(); opt.step()
                    final=float(mse().detach()); completed=step+1
                    if not finite([list(model.parameters()),opt.state_dict(),final]): raise FloatingPointError('Non-finite regression')
                except Exception as e: status='error'; error=f'{type(e).__name__}: {e}'; break
            changed=any(not torch.equal(model.state_dict()[k],v) for k,v in snapshot.items())
            rows.append(dict(method=name,seed=seed,initial_loss=initial,final_loss=final,steps=completed,seconds=time.perf_counter()-tic,weights_changed=changed,decreased=final<initial,status=status,error=error))
            print('regression',name,seed,status,f'{initial:.5g} -> {final:.5g}',flush=True)
    write_csv('regression.csv',rows); return rows

if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('--steps',type=int,default=500); parser.add_argument('--regression-steps',type=int,default=200); args=parser.parse_args()
    torch.set_num_threads(1); config=json.loads((ROOT/'configs/checks.json').read_text())
    (ROOT/'results').mkdir(exist_ok=True)
    if args.steps<1 or args.regression_steps<1:parser.error('Step budgets must be positive')
    (ROOT/'results/environment.json').write_text(json.dumps(dict(python=sys.version,platform=platform.platform(),torch=torch.__version__,numpy=np.__version__,cuda=torch.cuda.is_available(),threads=torch.get_num_threads()),indent=2))
    b=benchmarks(config,args.steps); r=regression(config,args.regression_steps)
    (ROOT/'results/check_summary.json').write_text(json.dumps(dict(benchmark_runs=len(b),benchmark_errors=sum(x['status']=='error' for x in b),regression_runs=len(r),regression_errors=sum(x['status']=='error' for x in r),regression_decreased=sum(x['decreased'] for x in r)),indent=2))
    if any(x['status']=='error' for x in b+r):raise SystemExit('Errors recorded in results/check_summary.json')
