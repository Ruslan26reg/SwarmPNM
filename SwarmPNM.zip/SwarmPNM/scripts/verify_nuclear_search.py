"""Recompute reported held-out predictions/metrics from saved trained weights."""
import argparse
import csv
import hashlib
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
from scripts.predict_nuclear import predict_energies
from scripts.run_nuclear import ROOT, save_json


def metrics(y, pred):
    error = np.asarray(pred)-np.asarray(y)
    return dict(rmse=float(np.sqrt(np.mean(error**2))), mae=float(np.mean(np.abs(error))),
                r2=float(1-np.sum(error**2)/np.sum((np.asarray(y)-np.mean(y))**2)))


def main(run_name):
    run = ROOT/'results/nuclear'/run_name
    protocol = json.loads((run/'protocol.json').read_text())
    refit = 'refit_config' in protocol
    cfg = protocol.get('search_config', protocol.get('refit_config'))
    seeds = protocol['seeds'] if refit else cfg['seeds']
    assert hashlib.sha256((run/'dataset_native.csv').read_bytes()).hexdigest() == protocol['dataset_sha256']
    rows = list(csv.DictReader((run/'dataset_native.csv').open()))
    ranking = json.loads((run/'ranking.json').read_text())
    lock = json.loads((run/'selection_locked.json').read_text())
    final = json.loads((run/'final.json').read_text())
    assert lock['winner'] == ranking[0] == final['winner']
    assert all(ranking[i]['validation']['r2']['mean'] >= ranking[i+1]['validation']['r2']['mean'] for i in range(len(ranking)-1))
    winner = final['winner']['candidate']
    records = []
    for seed in seeds:
        split = json.loads((run/f'split_seed{seed}.json').read_text())
        train, test = (set(split[k]) for k in ['train_ids','test_ids'])
        val = set() if refit else set(split['validation_ids'])
        assert not train&val and not train&test and not val&test
        assert train|val|test == set(range(len(rows)))
        if not refit:
            assert train|val == set(split['outer_train_ids'])
        trial = run/winner/f'seed{seed}'
        checkpoint = trial/('best_train.pt' if refit else 'best_validation.pt')
        pred = predict_energies(checkpoint, [float(rows[i]['energy_ev'])/1e6 for i in split['test_ids']])
        saved = list(csv.DictReader((trial/'test_predictions.csv').open()))
        assert [int(r['row_id']) for r in saved] == split['test_ids']
        np.testing.assert_allclose(pred, [float(r['predicted_sigma_barn']) for r in saved], atol=2e-6, rtol=2e-6)
        measured = metrics([float(rows[i]['sigma_barn']) for i in split['test_ids']], pred)
        reported = json.loads((trial/'test.json').read_text())
        for key, value in measured.items():
            assert abs(value-reported[key]) < 2e-6, (seed,key,value,reported[key])
        check_ids = split['train_ids'] if refit else split['validation_ids']
        checkpred = predict_energies(checkpoint, [float(rows[i]['energy_ev'])/1e6 for i in check_ids])
        checkmetrics = metrics([float(rows[i]['sigma_barn']) for i in check_ids], checkpred)
        selected = json.loads((trial/'train.json').read_text()) if refit else json.loads((trial/'result.json').read_text())['validation']
        for key, value in checkmetrics.items():
            assert abs(value-selected[key]) < 2e-6
        records.append(dict(seed=seed, **measured))
    for key in ['r2','rmse','mae']:
        assert abs(np.mean([r[key] for r in records])-final['test'][key]['mean']) < 2e-6
        assert abs(np.std([r[key] for r in records],ddof=1)-final['test'][key]['sample_std']) < 2e-6
    assert final['target_met'] == (final['test']['r2']['mean'] >= final['target_r2'])
    output = dict(status='passed', run=run_name, winner=winner, per_seed_recomputed=records,
                  checks=['dataset hash','disjoint train/validation/test partitions','validation ranking/lock consistency',
                          'checkpoint test predictions','post-row metric recomputation',
                          'checkpoint train predictions' if refit else 'checkpoint validation predictions','aggregate mean/std and target flag'])
    save_json(run/'verification.json', output)
    print(json.dumps(output, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--run-name', required=True)
    main(parser.parse_args().run_name)
