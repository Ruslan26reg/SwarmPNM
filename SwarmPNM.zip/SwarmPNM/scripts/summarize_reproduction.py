"""Report actual completed metrics; never treat calibration as a 100-epoch result."""
from pathlib import Path
import csv,json,datetime

ROOT=Path(__file__).resolve().parents[1]
RUNS=[('BBBP','bbbp_gcn_full_calibration',73.19),
      ('BACE','bace_gcn_full_seed0',74.25),
      ('HIV','hiv_gcn_full_seed0',78.84)]

def main():
    directory=ROOT/'results/reproduction';directory.mkdir(parents=True,exist_ok=True)
    rows=[]
    for dataset,name,target in RUNS:
        path=directory/name;status={};history=[]
        if (path/'status.json').exists():
            try:status=json.loads((path/'status.json').read_text(encoding='utf-8'))
            except json.JSONDecodeError:status={'status':'updating'}
        if (path/'epochs.csv').exists():
            with (path/'epochs.csv').open(newline='') as f:history=list(csv.DictReader(f))
        completed=int(history[-1]['epoch']) if history else 0
        result={}
        if (path/'test.json').exists():
            candidate=json.loads((path/'test.json').read_text(encoding='utf-8'))
            if candidate.get('completed_epochs')==100 and status.get('status')=='complete':result=candidate
        rows.append(dict(dataset=dataset,status=status.get('status','pending'),completed_epochs=completed,
                         paper_auc_percent=target,test_auc_percent=100*result['test_auc'] if result else None,
                         test_loss=result.get('test_loss'),best_epoch=result.get('best_epoch'),
                         best_valid_auc_percent=100*float(history[-1]['best_valid_auc']) if history else None,
                         last_epoch_seconds=float(history[-1]['seconds']) if history else None))
    with (directory/'summary.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    text=['# Фактический прогресс обучения SwarmPNM',
          '',f"Снимок UTC: {datetime.datetime.now(datetime.timezone.utc).isoformat()}",
          '', 'GCN, SwarmPNM-sqrt, seed 0, 100 эпох на полных данных. Это новая реконструкция; совпадение с историческим экспериментом не установлено.',
          '', '| Датасет | Состояние | Сохранено эпох | Test ROC-AUC | Статья |',
          '|---|---|---:|---:|---:|']
    for row in rows:
        auc=f"{row['test_auc_percent']:.2f}%" if row['test_auc_percent'] is not None else 'ещё нет'
        text.append(f"| {row['dataset']} | {row['status']} | {row['completed_epochs']}/100 | {auc} | {row['paper_auc_percent']:.2f}% |")
    text += ['', 'Первая калибровочная эпоха BBBP: test ROC-AUC 44.98%, loss 0.718071, время эпохи 113.73 с. Это отдельная проверка pipeline, не итог полного обучения.',
             '', 'Checkpoint выбирается по validation ROC-AUC. Test оценивается после бюджета; промежуточные validation показатели не выдаются за test.',
             '', 'Отчёт статический. Обновление: `python scripts/summarize_reproduction.py`. Живое состояние: `results/reproduction/queue_status.json` и `status.json` внутри папок запусков. Компьютер должен оставаться включённым; очередь работает в отдельном фоновом процессе.',
             '', 'Подробный протокол: `reproduction_plan.md`. Все попытки и ошибки сохраняются.']
    output=directory/'progress.md';output.write_text('\n'.join(text)+'\n',encoding='utf-8')
    print(output)

if __name__=='__main__':main()
