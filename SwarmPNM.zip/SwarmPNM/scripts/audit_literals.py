"""Actual optimization with the literal 2024 YogiPNM formula, preserved failure."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import csv,json,torch
from swarmpnmlab.optimizers import YogiPNM
def main():
    root=Path(__file__).resolve().parents[1];rows=[]
    (root/'results').mkdir(exist_ok=True)
    for interpretation in ['literal_2024','corrected']:
        for seed in [0,1,2]:
            torch.manual_seed(seed);p=torch.nn.Parameter(torch.tensor([1.,-.7],dtype=torch.float64))
            opt=YogiPNM([p],lr=.01,interpretation=interpretation,normalization='printed')
            initial=float(p.square().sum().detach())
            for step in range(10):
                opt.zero_grad();loss=p.square().sum();loss.backward();opt.step();final=float(p.square().sum().detach())
                rows.append(dict(interpretation=interpretation,seed=seed,step=step+1,initial_loss=initial,loss=final,second_moment_min=float(opt.state[p]['v'].min()),decreased=final<initial,finite=bool(torch.isfinite(p).all())))
                if not torch.isfinite(p).all():break
    with (root/'results/yogipnm_literal_audit.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    print('Recorded',len(rows),'literal/corrected Sphere updates; literal rises on first update')


if __name__=='__main__':main()
