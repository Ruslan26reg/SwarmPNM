"""Create a retrospective comparison report and a scientific plot from recorded results."""
import argparse
import csv
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scripts.predict_nuclear import predict_energies
from scripts.run_nuclear import ROOT


def main(run_name):
    directory = ROOT / 'results/nuclear' / run_name
    final = json.loads((directory / 'final.json').read_text())
    protocol = json.loads((directory / 'protocol.json').read_text())
    ranking = json.loads((directory / 'ranking.json').read_text())
    winner = final['winner']['candidate']
    cfg = protocol['search_config']
    config_file = protocol.get('search_config_file', 'nuclear_architecture_search_'+run_name.rsplit('_',1)[-1]+'.json' if 'phase_reason' in cfg else 'nuclear_architecture_search.json')
    data = list(csv.DictReader((directory / 'dataset_native.csv').open()))
    lines = ['# Подбор архитектуры SwarmPNM: 135Xe(n,2n)', '',
             f"Выбранная архитектура: **{winner}**. Средний test R² по трём разбиениям: **{final['test']['r2']['mean']:.6f} ± {final['test']['r2']['sample_std']:.6f}** (выборочное стандартное отклонение, не доверительный интервал).",
             f"Цель среднего R² ≥ {final['target_r2']:.2f}: **{'достигнута' if final['target_met'] else 'не достигнута'}**.", '',
             'R² — коэффициент детерминации регрессии, не доля правильных ответов классификации.', '',
             '## Итоговые отложенные данные', '', '| Seed | Эпоха по validation | Test R² | RMSE, барн | MAE, барн |',
             '|---|---:|---:|---:|---:|']
    for r in final['per_seed']:
        lines.append(f"| {r['seed']} | {r['selected_epoch']} | {r['r2']:.6f} | {r['rmse']:.6f} | {r['mae']:.6f} |")
    lines += ['', f"Средние RMSE/MAE: {final['test']['rmse']['mean']:.6f}/{final['test']['mae']['mean']:.6f} барн.",
              f"Все три прогона имеют R² ≥ 0,94: {'да' if final['all_three_seeds_at_least_target'] else 'нет'}.", '',
              '## Архитектура и обучение', '', '```json', json.dumps(final['winner']['spec'], indent=2), '```', '',
              f"Проверены {len(cfg['candidates'])} архитектур, каждая с seeds {cfg['seeds']}. В каждом разбиении: 90 строк train, 22 validation, 28 test; всего 140 исходных узлов ENDF/B-VIII.0, TENDL-2021 и CENDL-3.2. JENDL-5 отсутствует.",
              f"Бюджет — до {cfg['epochs']} эпох, полный train-batch. Обучение MSE в исходных барнах. Стандартизация энергии вычислена только на 90 train-строках. Ни имя библиотеки, ни test-ответы не подаются модели.",
              'SwarmPNM sqrt и все его коэффициенты сохранены из предыдущего запуска. Новый протокол использует validation для выбора эпохи и архитектуры; исходный эксперимент использовал 200 эпох и последний checkpoint. Поэтому улучшение нельзя приписать одной архитектуре.',
              'Для RBF-вариантов центры и ширина фиксируются по диапазону train-энергий; SwarmPNM обучает линейную выходную голову. Начальная голова имеет нулевые веса и выдаёт train-среднее сечение. У вариантов gain5/gain10 выход головы умножается на фиксированные 5/10, а начальный bias равен train-среднему, делённому на gain. Это изменение масштаба параметризации сети, ускоряющее сходимость; ответы и loss остаются в исходных барнах. Аналитического подбора весов, интерполяции ответов test или подмены SwarmPNM другим оптимизатором нет.', '',
              '## Выбор по validation', '', '| Кандидат | Средний validation R² | Стд. откл. | Выбранные эпохи |', '|---|---:|---:|---|']
    for r in ranking:
        lines.append(f"| {r['candidate']} | {r['validation']['r2']['mean']:.6f} | {r['validation']['r2']['sample_std']:.6f} | {r['selected_epochs']} |")
    lines += ['', f"Архитектура ранжирована исключительно по среднему validation R². Файл selection_locked.json создан до расчёта test-метрик выбранной модели. Сохранены истории всех кандидатов и checkpoints всех {len(cfg['candidates'])*len(cfg['seeds'])} прогонов этой стадии; плохие результаты не удалены.",
              'Ансамбль, если выбран, усредняет выходы трёх подсетей. Все параметры обучаются совместно одним SwarmPNM по общей MSE; это не усреднение моделей, обученных на чужих test-строках.', '',
              '## Что подтверждает результат', '',
              'Это ретроспективное улучшение на прежних random-row test-разбиениях: их результаты уже были просмотрены в исходном эксперименте. Новый поиск не использовал их для выбора модели, но они не являются свежим независимым подтверждением.',
              'Узлы из оценённых библиотек не являются независимыми экспериментальными измерениями. Одна энергия может встречаться в нескольких библиотеках и в разных частях разбиения. Оценка относится к интерполяции одной реакции одного изотопа; перенос на другие изотопы и экстраполяция не проверялись.',
              'В статье SwarmPNM R² = 0,977; 0,94 — новая пользовательская цель. Исторические данные и преобразования авторов не известны полностью, поэтому это не воспроизведение таблицы статьи.', '',
              '## Файлы и повторение', '',
              f"`python scripts/search_nuclear.py --config configs/{config_file} --run-name new_architecture_search` повторяет эту стадию поиска. Используйте новое имя, чтобы сохранить предыдущие результаты.",
              f'`python scripts/predict_nuclear.py --checkpoint results/nuclear/{run_name}/{winner}/seed0/best_validation.pt --energy-mev 7 10 15 20` возвращает предсказания в барнах.', '',
              'protocol.json содержит источники, хеш датасета, настройки и ограничения; ranking.json — ранжирование; final.json — метрики; test_predictions.csv — построчные ответы; best_validation.pt — веса, состояние SwarmPNM и настройки входа.', '',
              '![Кривые и метрики](comparison.png)', '']
    (directory / 'report.md').write_text('\n'.join(lines), encoding='utf-8')
    fig, axes = plt.subplots(1, 2, figsize=(13, 5), gridspec_kw={'width_ratios': [1.6, 1]})
    for library in sorted({r['library'] for r in data}):
        subset = [r for r in data if r['library'] == library]
        axes[0].plot([float(r['energy_ev'])/1e6 for r in subset], [float(r['sigma_barn']) for r in subset], '.-', linewidth=.8, markersize=3, alpha=.6, label=library)
    grid = np.linspace(min(float(r['energy_ev'])/1e6 for r in data), max(float(r['energy_ev'])/1e6 for r in data), 250)
    for seed in cfg['seeds']:
        pred = predict_energies(directory / winner / f'seed{seed}' / 'best_validation.pt', grid)
        axes[0].plot(grid, pred, linewidth=1.3, label=f'SwarmPNM seed {seed}')
    axes[0].set(xlabel='Neutron energy (MeV)', ylabel='Cross section (barn)', title=f'135Xe(n,2n): {winner}')
    axes[0].legend(fontsize=8, ncols=2)
    values = [r['r2'] for r in final['per_seed']]
    axes[1].bar([f'Seed {r["seed"]}' for r in final['per_seed']], values, color='#347da1')
    axes[1].axhline(.94, linestyle='--', color='#bd4e2e', label='Requested R² = 0.94')
    for i, value in enumerate(values):
        axes[1].text(i, value+.005, f'{value:.4f}', ha='center', fontsize=10)
    axes[1].set(ylabel='Outer test R²', ylim=(min(.8, min(values)-.05), 1.01), title=f'Mean R² = {final["test"]["r2"]["mean"]:.4f}')
    axes[1].legend(fontsize=8)
    for ax in axes:
        ax.grid(alpha=.15)
    fig.suptitle('Validation-selected architecture; previously viewed random-row test splits', fontsize=11)
    fig.tight_layout()
    fig.savefig(directory / 'comparison.png', dpi=180)
    fig.savefig(directory / 'comparison.svg')
    plt.close(fig)
    print(directory / 'report.md')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--run-name', required=True)
    main(parser.parse_args().run_name)
