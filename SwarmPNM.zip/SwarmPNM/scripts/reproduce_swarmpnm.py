"""Resume-capable full-data SwarmPNM experiments, train mode and clean holdout."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import argparse,csv,json,random,time,hashlib,os,platform
import numpy as np
import torch
from torch_geometric.loader import DataLoader
from scripts.run_molclr import model_for,update,evaluate,ROOT
from scripts.run_checks import finite
from molclr.data_utils import load_dataset,split,FILES
from swarmpnmlab.registry import make_method,METHODS

TARGETS={'BBBP':{'gin':(.702,.7426),'gcn':(.705,.7319)},
         'BACE':{'gin':(1.080,.7612),'gcn':(.682,.7425)},
         'HIV':{'gin':(1.452,.7868),'gcn':(.748,.7884)}}

def clean_json(value):
    if isinstance(value,float) and not np.isfinite(value):return None
    if isinstance(value,dict):return {k:clean_json(v) for k,v in value.items()}
    if isinstance(value,list):return [clean_json(v) for v in value]
    return value

def write_json(path,value):
    path.write_text(json.dumps(clean_json(value),indent=2,allow_nan=False),encoding='utf-8')

def class_counts(data,ids):
    return {str(k):sum(int(data[i].y)==k for i in ids) for k in [0,1]}

def run(dataset,backbone,method,seed,epochs,threads,run_name,resume=False,pretrained=True,config_path=None):
    if epochs<1 or threads<1:raise ValueError('Positive epochs and threads required')
    torch.set_num_threads(threads);torch.manual_seed(seed);np.random.seed(seed);random.seed(seed)
    cfg=json.loads((Path(config_path) if config_path else ROOT/'configs'/f'{dataset.lower()}_{backbone}.json').read_text())
    if cfg['dataset']!=dataset or cfg['backbone']!=backbone:raise ValueError('Config dataset/backbone mismatch')
    cfg['seed']=seed
    if method in ('swarmpnm_sqrt','swarmpnm_inverse','glfgd'):cfg['methods'][method]['seed']=seed
    if method=='adaswarm':cfg['methods'][method]['swarm']['seed']=seed
    model=model_for(cfg)
    compatible={}
    if pretrained:
        source=torch.load(ROOT/'molclr/ckpt'/f'pretrained_{backbone}.pth',map_location='cpu',weights_only=True)
        compatible={k:v for k,v in source.items() if k in model.state_dict() and model.state_dict()[k].shape==v.shape and not k.startswith('pred_head')}
        model.load_state_dict(compatible,strict=False)
        if not compatible:raise ValueError('No pretrained encoder tensors found')
    print('Loading FULL',dataset,'...',flush=True)
    items,rejected=load_dataset(dataset);ids=split(items,'scaffold',seed);data=[d for _,d in items]
    counts={k:class_counts(data,v) for k,v in zip(['train','valid','test'],ids)}
    if any(not all(c.values()) for c in counts.values()):raise ValueError(f'Both classes required in every partition: {counts}')
    gen=torch.Generator().manual_seed(seed)
    loaders=[DataLoader([data[i] for i in v],batch_size=cfg['batch_size'],shuffle=j==0,generator=gen if j==0 else None,num_workers=0) for j,v in enumerate(ids)]
    opt,criterion=make_method(method,model.parameters(),cfg['methods'][method])
    directory=ROOT/'results'/'reproduction'/run_name
    if directory.exists() and not resume:raise ValueError('Run already exists; pass --resume or choose a new --run-name')
    directory.mkdir(parents=True,exist_ok=True)
    state_path=directory/'last_state.pt';history=directory/'epochs.csv'
    if state_path.exists() and not resume:raise ValueError('Run already exists; pass --resume or choose a new --run-name')
    csv_path=ROOT/'molclr/data'/FILES[dataset][0]
    protocol=dict(config=cfg,epoch_budget=epochs,method=method,seed=seed,pretrained=pretrained,model_mode='train; repeated SwarmPNM comparisons reuse RNG and pre-step buffers; BN/RNG commit once',
                  split='deterministic MolCLR scaffold 80/10/10',train_ids=ids[0],valid_ids=ids[1],test_ids=ids[2],
                  class_counts=counts,molecules=len(data),rejected=rejected,encoder_tensors_loaded=len(compatible),
                  data_sha256=hashlib.sha256(csv_path.read_bytes()).hexdigest(),device='cpu',threads=threads,
                  target_paper_loss=TARGETS[dataset][backbone][0],target_paper_auc=TARGETS[dataset][backbone][1],
                  unknowns=['historical epsilon, seed, exact scaffold membership','lambda not applied: role ambiguous','sqrt SwarmPNM chosen; inverse alternative not selected by holdout','single trajectory P=G, no defined population'],
                  selection='best validation ROC-AUC only; test evaluated once after epoch budget',
                  tuning='No test-set tuning. SwarmPNM defaults reconstructed from manuscript; other method settings are new comparison settings.',python=sys.version,torch=torch.__version__,platform=platform.platform())
    fields=['epoch','train_loss','valid_loss','valid_auc','seconds','updates','best_epoch','best_valid_auc']
    start=0;best=-float('inf');best_epoch=0
    if resume:
        # Own locally generated checkpoint; includes NumPy/Python RNG structures.
        state=torch.load(state_path,map_location='cpu',weights_only=False)
        if state['data_sha256']!=protocol['data_sha256'] or state['config']!=cfg or state.get('method',method)!=method or state.get('pretrained',True)!=pretrained:raise ValueError('Data/config/method/initialization differ from resume checkpoint')
        model.load_state_dict(state['model']);opt.load_state_dict(state['optimizer']);start=state['epoch'];best=state['best_valid_auc'];best_epoch=state['best_epoch']
        if criterion is not None:
            if state.get('criterion') is None:raise ValueError('Missing criterion RNG/state in checkpoint')
            criterion.load_state_dict(state['criterion'])
        if start>=epochs:raise ValueError('Resume epoch budget must exceed completed epochs')
        torch.set_rng_state(state['torch_rng']);np.random.set_state(state['numpy_rng']);random.setstate(state['python_rng']);gen.set_state(state['loader_rng'])
        if not history.exists():raise ValueError('Missing epoch history')
        # Ignore a row appended after the most recent fully saved epoch.
        with history.open(newline='') as f:kept=[r for r in csv.DictReader(f) if int(r['epoch'])<=start]
        with history.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(kept)
    else:
        with history.open('w',newline='') as f:csv.DictWriter(f,fieldnames=fields).writeheader()
    write_json(directory/'protocol.json',protocol)
    print('FULL DATA',len(data),'classes',counts,'encoder tensors',len(compatible),'start',start,flush=True)
    write_json(directory/'status.json',dict(status='running',epoch=start,epoch_budget=epochs,pid=os.getpid(),class_counts=counts))
    total_start=time.perf_counter()
    try:
        for epoch in range(start,epochs):
            model.train();total=0.;n=0;updates=0;tic=time.perf_counter()
            for batch_number,batch in enumerate(loaders[0]):
                loss=update(model,batch,opt,criterion);total+=float(loss.detach())*batch.num_graphs;n+=batch.num_graphs;updates+=1
                if not finite([list(model.parameters()),opt.state_dict(),float(loss.detach())]):raise FloatingPointError('Non-finite training loss/parameters/state')
                write_json(directory/'status.json',dict(status='running',epoch=epoch+1,batch=batch_number+1,batches=len(loaders[0]),epoch_budget=epochs,pid=os.getpid(),elapsed_seconds=time.perf_counter()-total_start))
                print(f'EPOCH {epoch+1}/{epochs} BATCH {batch_number+1}/{len(loaders[0])} LOSS {float(loss.detach()):.6g}',flush=True)
            vl,va=evaluate(model,loaders[1])
            if not np.isfinite(vl) or not np.isfinite(va):raise FloatingPointError('Validation must have finite loss/AUC')
            if va>best:
                best=va;best_epoch=epoch+1
                torch.save(model.state_dict(),directory/'best_model.tmp');os.replace(directory/'best_model.tmp',directory/'best_model.pt')
            row=dict(epoch=epoch+1,train_loss=total/n,valid_loss=vl,valid_auc=va,seconds=time.perf_counter()-tic,updates=updates,best_epoch=best_epoch,best_valid_auc=best)
            with history.open('a',newline='') as f:csv.DictWriter(f,fieldnames=fields).writerow(row)
            checkpoint=dict(model=model.state_dict(),optimizer=opt.state_dict(),criterion=criterion.state_dict() if criterion is not None else None,method=method,pretrained=pretrained,torch_rng=torch.get_rng_state(),numpy_rng=np.random.get_state(),python_rng=random.getstate(),loader_rng=gen.get_state(),epoch=epoch+1,best_valid_auc=best,best_epoch=best_epoch,config=cfg,data_sha256=protocol['data_sha256'])
            torch.save(checkpoint,directory/'last_state.tmp');os.replace(directory/'last_state.tmp',state_path)
            print('EPOCH COMPLETE',json.dumps(row),flush=True)
            write_json(directory/'status.json',dict(status='running' if epoch+1<epochs else 'evaluating_test',epoch=epoch+1,epoch_budget=epochs,best_valid_auc=best,best_epoch=best_epoch,last_epoch_seconds=row['seconds'],estimated_remaining_seconds=row['seconds']*(epochs-epoch-1),pid=os.getpid()))
        model.load_state_dict(torch.load(directory/'best_model.pt',weights_only=True));tl,ta=evaluate(model,loaders[2])
        write_json(directory/'test.json',dict(test_loss=tl,test_auc=ta,best_epoch=best_epoch,best_valid_auc=best,paper_loss=TARGETS[dataset][backbone][0],paper_auc=TARGETS[dataset][backbone][1],auc_difference_pp=(ta-TARGETS[dataset][backbone][1])*100,loss_difference=tl-TARGETS[dataset][backbone][0],seed=seed,completed_epochs=epochs,interpretation='Single NEW reconstruction run, not historical mean/std reproduction'))
        write_json(directory/'status.json',dict(status='complete',epoch=epochs,epoch_budget=epochs,best_epoch=best_epoch,test_auc=ta,test_loss=tl))
        print('COMPLETE',dataset,backbone,method,'TEST',tl,ta,flush=True)
    except BaseException as e:
        write_json(directory/'status.json',dict(status='interrupted' if isinstance(e,KeyboardInterrupt) else 'error',last_completed_epoch=epoch if 'epoch' in locals() else start,error=f'{type(e).__name__}: {e}',resume_checkpoint_available=state_path.exists()))
        raise

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--dataset',choices=TARGETS,default='BBBP');p.add_argument('--backbone',choices=['gin','gcn'],default='gcn');p.add_argument('--method',choices=METHODS,default='swarmpnm_sqrt');p.add_argument('--seed',type=int,default=0);p.add_argument('--epochs',type=int,default=100);p.add_argument('--threads',type=int,default=4);p.add_argument('--run-name',required=True);p.add_argument('--resume',action='store_true');p.add_argument('--from-scratch',action='store_true');p.add_argument('--config',type=Path);a=p.parse_args()
    run(a.dataset,a.backbone,a.method,a.seed,a.epochs,a.threads,a.run_name,a.resume,not a.from_scratch,a.config)
