"""Fixed-protocol audit on new isotopes: frozen Xe weights versus separate refits."""
import argparse
import copy
import hashlib
import json
import sys
import time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import torch
from torch import nn
from swarmpnmlab.registry import make_method
from swarmpnmlab.training import RepeatableClosure
from nuclear.architectures import make_architecture
from nuclear.endf import read_cross_section
from nuclear.metrics import regression_metrics
from scripts.predict_nuclear import predict_energies, load_predictor
from scripts.run_nuclear import ROOT, prediction, save_csv, save_json
from scripts.search_nuclear import aggregate


def energy_group_split(energy_ev, seed, group_width_ev):
    if group_width_ev<=0:raise ValueError('Energy group width must be positive')
    groups=np.floor(np.asarray(energy_ev)/group_width_ev).astype(np.int64)
    unique=np.unique(groups)
    if len(unique)<5:raise ValueError('Too few independent energy groups')
    ordered=np.random.default_rng(seed).permutation(unique)
    ntrain=max(2,min(len(unique)-2,int(.8*len(unique))))
    mask=np.isin(groups,ordered[:ntrain])
    train,test=np.flatnonzero(mask),np.flatnonzero(~mask)
    if len(test)<2 or len(train)<2:raise ValueError('Insufficient split rows')
    if set(groups[train])&set(groups[test]):raise ValueError('Overlapping energy groups')
    return train,test,groups


def main(config_path, run_name):
    cfg=json.loads(config_path.read_text())
    torch.set_num_threads(cfg['threads'])
    out=ROOT/'results/nuclear'/run_name
    if out.exists():raise ValueError('Preserve previous checks')
    out.mkdir(parents=True)
    ref=ROOT/'results/nuclear'/cfg['reference_run']
    refresult=json.loads((ref/'final.json').read_text())
    spec=refresult['winner']['spec'];epochs=refresult['epochs']
    refs=[ref/refresult['winner']['candidate']/f'seed{s}'/'best_train.pt' for s in cfg['seeds']]
    refstate=torch.load(refs[0],weights_only=True,map_location='cpu')
    optcfg=refstate['swarmpnm_config']
    reference_model,_=load_predictor(refs[0])
    refdomain=reference_model.nuclear_context['energy_domain_mev']
    protocol=dict(config=cfg, architecture=spec, epochs=epochs, swarmpnm_config=optcfg,
        reference_checkpoint_hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in refs},
        reference_energy_domain_mev=refdomain,
        interpretation='Fixed architecture retraining on new isotope tables. Frozen-reference tests intentionally mismatch Xe135 weights and target isotope. Not a universal multi-isotope model and not experimental-measurement validation.')
    save_json(out/'protocol.json',protocol)
    results=[]
    for isotope in cfg['isotopes']:
        target_dir=out/isotope['token'];target_dir.mkdir()
        tables={};sources={}
        for library,name in isotope['sources'].items():
            path=ROOT/'nuclear/sources'/name
            tables[library]=read_cross_section(path,mt=isotope['mt'],expected_za=isotope['za'])
            sources[library]=dict(file=name,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                acquisition=json.loads(path.with_name(path.stem+'_acquisition.json').read_text()))
        low=max(refdomain[0]*1e6,*[t['energy_ev'][0] for t in tables.values()])
        high=min(refdomain[1]*1e6,*[t['energy_ev'][-1] for t in tables.values()])
        rows=[]
        for library,table in tables.items():
            for native_id,(energy,sigma) in enumerate(zip(table['energy_ev'],table['sigma_barn'])):
                if low<=energy<=high:
                    rows.append(dict(row_id=len(rows),library=library,native_point_id=native_id,energy_ev=energy,sigma_barn=sigma))
        if len(rows)<10 or low>=high:raise ValueError('Insufficient aligned isotope data')
        save_csv(target_dir/'dataset_native.csv',rows)
        context=dict(za=isotope['za'],isotope=isotope['isotope'],mf=3,mt=isotope['mt'],
            energy_domain_mev=[low/1e6,high/1e6],source_libraries=list(tables))
        save_json(target_dir/'data_protocol.json',dict(nuclear_context=context,sources=sources,
            dataset_sha256=hashlib.sha256((target_dir/'dataset_native.csv').read_bytes()).hexdigest(),rows=len(rows),
            library_counts={lib:sum(r['library']==lib for r in rows) for lib in tables}))
        energy_ev=np.array([r['energy_ev'] for r in rows]);energy=energy_ev/1e6
        y=np.array([r['sigma_barn'] for r in rows]);target=torch.tensor(y[:,None],dtype=torch.float32)
        for seed in cfg['seeds']:
            train,test,groups=energy_group_split(energy_ev,seed,cfg['energy_group_width_ev'])
            mean,scale=energy[train].mean(),energy[train].std()
            if not np.isfinite(scale) or scale<=0:raise ValueError('Constant training energy')
            x=torch.tensor(((energy-mean)/scale)[:,None],dtype=torch.float32)
            split=dict(seed=seed,train_ids=train.tolist(),test_ids=test.tolist(),
                energy_group_width_ev=cfg['energy_group_width_ev'],energy_groups=groups.tolist(),
                input_mean_mev=float(mean),input_std_mev=float(scale))
            trial=target_dir/f'seed{seed}';trial.mkdir();save_json(trial/'split.json',split)
            frozen=np.mean([predict_energies(p,energy[test]) for p in refs],axis=0)
            frozen_metrics=regression_metrics(y[test],frozen)
            torch.manual_seed(seed)
            model=make_architecture(spec,x[train],target[train])
            opt,_=make_method('swarmpnm_sqrt',model.parameters(),dict(optcfg,seed=seed))
            tic=time.perf_counter();history=[]
            for epoch in range(1,epochs+1):
                model.train()
                def objective():return nn.functional.mse_loss(model(x[train]),target[train])
                closure=RepeatableClosure(model,opt,objective)
                try:opt.step(closure)
                finally:closure.commit()
                if not torch.isfinite(closure.initial_loss) or any(not torch.isfinite(p).all() for p in model.parameters()):
                    raise FloatingPointError('Non-finite transfer training')
                if epoch==1 or epoch%10==0 or epoch==epochs:
                    history.append(dict(epoch=epoch,train_mse=float(closure.initial_loss),swarmpnm_best_mse=opt.meta['best_loss']))
            last_model=copy.deepcopy(model.state_dict())
            with torch.no_grad():
                for p in model.parameters():p.copy_(opt.state[p]['best'])
            trained_pred=prediction(model,x[test])
            trained_metrics=regression_metrics(y[test],trained_pred)
            train_metrics=regression_metrics(y[train],prediction(model,x[train]))
            if abs(train_metrics['rmse']**2-opt.meta['best_loss'])>1e-5:raise ValueError('Personal-best snapshot mismatch')
            checkpoint=trial/'best_train.pt'
            torch.save(dict(model=model.state_dict(),training_last_model=last_model,optimizer=opt.state_dict(),
                torch_rng=torch.get_rng_state(),spec=spec,split=split,nuclear_context=context,
                epoch=epochs,swarmpnm_config=dict(optcfg,seed=seed),train_metrics=train_metrics,
                inference='Training personal best; optimizer state corresponds to training_last_model'),checkpoint)
            # Independent public predictor verifies the just-written checkpoint.
            restored=predict_energies(checkpoint,energy[test],expected_za=isotope['za'],expected_mt=isotope['mt'])
            np.testing.assert_allclose(restored,trained_pred,atol=2e-6,rtol=2e-6)
            result=dict(isotope=isotope['isotope'],za=isotope['za'],seed=seed,epochs=epochs,
                train_rows=len(train),test_rows=len(test),train_energy_groups=len(set(groups[train])),
                test_energy_groups=len(set(groups[test])),overlapping_groups=0,seconds=time.perf_counter()-tic,
                frozen_xe135=frozen_metrics,retrained_swarmpnm=trained_metrics,checkpoint_predictions_verified=True)
            save_json(trial/'result.json',result);save_json(trial/'train.json',train_metrics)
            save_csv(trial/'training_history.csv',history)
            save_csv(trial/'test_predictions.csv',[dict(**rows[int(i)],frozen_xe135_sigma_barn=float(f),retrained_sigma_barn=float(p)) for i,f,p in zip(test,frozen,trained_pred)])
            results.append(result);save_json(out/'results.json',results)
            save_json(out/'status.json',dict(status='running',completed_trials=len(results),total_trials=len(cfg['seeds'])*len(cfg['isotopes'])))
            print('TRANSFER CHECK',json.dumps(result),flush=True)
    summary={}
    for isotope in cfg['isotopes']:
        trials=[r for r in results if r['za']==isotope['za']]
        summary[isotope['isotope']]={method:aggregate([r[method] for r in trials]) for method in ['frozen_xe135','retrained_swarmpnm']}
    save_json(out/'summary.json',summary);save_json(out/'status.json',dict(status='complete',runs=len(results),summary=summary))
    print('ALL TRANSFER RESULTS',json.dumps(summary),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--config',type=Path,default=ROOT/'configs/nuclear_transfer_check.json')
    parser.add_argument('--run-name',required=True)
    args=parser.parse_args();main(args.config,args.run_name)
