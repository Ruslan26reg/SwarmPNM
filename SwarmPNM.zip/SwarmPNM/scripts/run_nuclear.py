"""200-epoch MLP check on documented native 135Xe(n,2n) evaluated tables."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import argparse,csv,json,hashlib,time,datetime,traceback,copy
import numpy as np
import torch
from torch import nn
from swarmpnmlab.registry import make_method
from swarmpnmlab.training import RepeatableClosure
from nuclear.endf import read_cross_section
from nuclear.metrics import regression_metrics

ROOT=Path(__file__).resolve().parents[1]

def save_json(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False),encoding='utf-8')

def save_csv(path,rows):
    with path.open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)

def make_model(cfg):
    layers=[];inputs=1
    activations={'ReLU':nn.ReLU,'Tanh':nn.Tanh,'LeakyReLU':lambda:nn.LeakyReLU(cfg['leaky_relu_slope'])}
    for units,act,drop in zip(cfg['hidden_layers'],cfg['activations'],cfg['dropout_after_hidden']):
        layers.extend([nn.Linear(inputs,units),activations[act]()])
        if drop:layers.append(nn.Dropout(drop))
        inputs=units
    layers.append(nn.Linear(inputs,1));return nn.Sequential(*layers)

@torch.no_grad()
def prediction(model,x):model.eval();return model(x).detach().numpy().reshape(-1)

def main(config,run_name):
    cfg=json.loads(config.read_text());torch.set_num_threads(cfg['threads'])
    directory=ROOT/'results/nuclear'/run_name
    if directory.exists():raise ValueError('Run name already exists; preserve previous attempts and select a new name')
    directory.mkdir(parents=True)
    tables={};manifest={}
    for library,name in cfg['available_libraries'].items():
        path=ROOT/'nuclear/sources'/name
        tables[library]=read_cross_section(path,mt=cfg['mt'],expected_za=cfg.get('za',54135))
        manifest[library]=dict(file=name,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),native_points=tables[library]['native_points'])
    low=max(t['energy_ev'][0] for t in tables.values());high=min(t['energy_ev'][-1] for t in tables.values())
    if low>=high:raise ValueError('No common energy domain')
    rows=[]
    for library,table in tables.items():
        for point,(energy,sigma) in enumerate(zip(table['energy_ev'],table['sigma_barn'])):
            if low<=energy<=high:rows.append(dict(row_id=len(rows),library=library,native_point_id=point,energy_ev=energy,sigma_barn=sigma))
    if len(rows)<10:raise ValueError('Too few native data points')
    save_csv(directory/'dataset_native.csv',rows)
    dataset_hash=hashlib.sha256((directory/'dataset_native.csv').read_bytes()).hexdigest()
    protocol=dict(config=cfg,source_manifest=manifest,energy_domain_ev=[low,high],rows=len(rows),
                  library_counts={lib:sum(r['library']==lib for r in rows) for lib in tables},
                  dataset_sha256=dataset_hash,device='cpu',torch=torch.__version__,python=sys.version,
                  started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  interpretation=f'Partial {len(tables)}-library native-grid reconstruction; no claim of Table 7 replication',
                  metric_units='RMSE and MAE in raw barns; R2 dimensionless. Article target scaling is unspecified.',
                  data_limit='Rows are evaluated library nodes, not independent experimental measurements. Random-row holdout measures interpolation, not new-isotope/reaction generalization.',
                  missing_libraries=cfg['missing_libraries'])
    save_json(directory/'protocol.json',protocol)
    energy=np.array([r['energy_ev']/1e6 for r in rows],dtype=np.float64)
    y=np.array([r['sigma_barn'] for r in rows],dtype=np.float64)
    results=[]
    print('NATIVE DATA',len(rows),'DOMAIN MeV',low/1e6,high/1e6,'COUNTS',protocol['library_counts'],flush=True)
    for seed in cfg['seeds']:
        order=np.random.default_rng(seed).permutation(len(rows));n=int(.8*len(rows));train_ids=order[:n];test_ids=order[n:]
        mean=energy[train_ids].mean();scale=energy[train_ids].std()
        if scale<=0:raise ValueError('Constant training energy')
        x=torch.tensor(((energy-mean)/scale)[:,None],dtype=torch.float32);target=torch.tensor(y[:,None],dtype=torch.float32)
        overlaps=sorted(set(energy[train_ids]).intersection(energy[test_ids]))
        split=dict(seed=seed,train_ids=train_ids.tolist(),test_ids=test_ids.tolist(),input_mean_mev=float(mean),input_std_mev=float(scale),
                   shared_train_test_energies_mev=overlaps,shared_energy_note='Different libraries may contain the same energy in random row split; explicitly retained to match stated random-row protocol')
        save_json(directory/f'split_seed{seed}.json',split)
        for method in cfg['methods']:
            trial=directory/f'{method}_seed{seed}';trial.mkdir()
            torch.manual_seed(seed);model=make_model(cfg)
            method_cfg=copy.deepcopy(cfg['methods'][method])
            if method.startswith('swarmpnm_'):method_cfg['seed']=seed
            opt,criterion=make_method(method,model.parameters(),method_cfg)
            gen=torch.Generator().manual_seed(seed)
            initial=regression_metrics(y[test_ids],prediction(model,x[test_ids]));history=[];tic=time.perf_counter()
            try:
                for epoch in range(cfg['epochs']):
                    model.train();total=0.;count=0
                    shuffled=train_ids[torch.randperm(len(train_ids),generator=gen).numpy()]
                    for offset in range(0,len(shuffled),cfg['batch_size']):
                        ids=shuffled[offset:offset+cfg['batch_size']];xb=x[ids];yb=target[ids]
                        def objective():return nn.functional.mse_loss(model(xb),yb)
                        if method.startswith('swarmpnm_'):
                            closure=RepeatableClosure(model,opt,objective)
                            try:opt.step(closure)
                            finally:closure.commit()
                            loss=closure.initial_loss
                        else:
                            opt.zero_grad();loss=objective();loss.backward();opt.step()
                        if not torch.isfinite(loss) or any(not torch.isfinite(p).all() for p in model.parameters()):raise FloatingPointError('Non-finite training loss/parameters')
                        total+=float(loss.detach())*len(ids);count+=len(ids)
                    history.append(dict(epoch=epoch+1,train_mse=total/count))
                    if epoch%25==0 or epoch+1==cfg['epochs']:
                        save_json(directory/'status.json',dict(status='running',method=method,seed=seed,epoch=epoch+1,epoch_budget=cfg['epochs']))
                        print(method,'SEED',seed,'EPOCH',epoch+1,'TRAIN MSE',total/count,flush=True)
                pred=prediction(model,x[test_ids]);metrics=regression_metrics(y[test_ids],pred)
                by_library={}
                for library in tables:
                    mask=np.array([rows[i]['library']==library for i in test_ids])
                    if mask.sum()>=2:by_library[library]=regression_metrics(y[test_ids][mask],pred[mask])
                result=dict(method=method,seed=seed,status='complete',epochs=cfg['epochs'],train_rows=n,test_rows=len(test_ids),seconds=time.perf_counter()-tic,**metrics)
                results.append(result)
                save_json(trial/'test.json',dict(**result,initial_test_metrics=initial,per_library=by_library,interpretation=protocol['interpretation']))
                predictions=[dict(**rows[int(i)],predicted_sigma_barn=float(p),residual_barn=float(p-y[int(i)])) for i,p in zip(test_ids,pred)]
                save_csv(trial/'test_predictions.csv',predictions);save_csv(trial/'epochs.csv',history)
                torch.save(dict(model=model.state_dict(),optimizer=opt.state_dict(),torch_rng=torch.get_rng_state(),loader_rng=gen.get_state(),config=cfg,split=split,epoch=cfg['epochs'],dataset_sha256=dataset_hash),trial/'last_state.pt')
                print('COMPLETE',json.dumps(result),flush=True)
            except Exception as e:
                traceback.print_exc();results.append(dict(method=method,seed=seed,status='error',error=str(e)))
                save_json(trial/'error.json',results[-1])
                if history:save_csv(trial/'epochs.csv',history)
    save_json(directory/'results.json',results)
    aggregate={}
    for method in cfg['methods']:
        good=[r for r in results if r['method']==method and r['status']=='complete']
        if good:
            aggregate[method]=dict(successful_runs=len(good),**{m:dict(mean=float(np.mean([r[m] for r in good])),sample_std=float(np.std([r[m] for r in good],ddof=1)) if len(good)>1 else None) for m in ['rmse','mae','r2']})
    save_json(directory/'aggregate.json',aggregate)
    save_json(directory/'status.json',dict(status='complete' if all(r['status']=='complete' for r in results) else 'completed_with_errors',runs=len(results),aggregate=aggregate))
    print('ALL RESULTS',json.dumps(aggregate),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--config',type=Path,default=ROOT/'configs/nuclear_xe135.json');parser.add_argument('--run-name',required=True)
    args=parser.parse_args();main(args.config,args.run_name)
