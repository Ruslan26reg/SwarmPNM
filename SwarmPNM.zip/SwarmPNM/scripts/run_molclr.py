"""Run original MolCLR GIN/GCN models through the unified optimizer registry."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import argparse,copy,csv,json,time,random
import numpy as np
import torch
import torch.nn.functional as F
from torch_geometric.data import Batch
from torch_geometric.loader import DataLoader
from swarmpnmlab.registry import make_method,METHODS
from swarmpnmlab.optimizers import SwarmPNM
from swarmpnmlab.training import RepeatableClosure
from molclr.models.ginet_finetune import GINet
from molclr.models.gcn_finetune import GCN
from molclr.data_utils import load_dataset,split,auc
from scripts.run_checks import finite
ROOT=Path(__file__).resolve().parents[1]

def model_for(config,small=False):
    cls=GINet if config['backbone']=='gin' else GCN
    shape=dict(config['model'])
    if small: shape.update(num_layer=2,emb_dim=16,feat_dim=16,drop_ratio=0)
    return cls(task='classification',**shape)

def update(model,batch,opt,criterion):
    def closure():
        opt.zero_grad(); _,pred=model(batch); loss=F.cross_entropy(pred,batch.y.view(-1)); loss.backward(); return loss
    if isinstance(opt,SwarmPNM):
        bridge=RepeatableClosure(model,opt,lambda:F.cross_entropy(model(batch)[1],batch.y.view(-1)))
        try: opt.step(bridge)
        finally: bridge.commit()
        return bridge.initial_loss
    opt.zero_grad(); _,pred=model(batch)
    if criterion:
        labels=batch.y.view(-1)
        center=F.one_hot(labels,2).to(pred.dtype)*5
        loss=criterion(pred,loss_fn=lambda z:F.cross_entropy(z,labels),center=center,
                       fitness_fn=lambda z:F.cross_entropy(z.reshape(-1,2),labels.repeat(z.shape[0]),reduction='none').reshape(z.shape[0],-1).mean(1))
    else: loss=F.cross_entropy(pred,batch.y.view(-1))
    loss.backward(); opt.step(); return loss

@torch.no_grad()
def evaluate(model,loader):
    was_training=model.training; model.eval(); total=0.;count=0; labels=[];scores=[]
    for batch in loader:
        _,pred=model(batch); total+=float(F.cross_entropy(pred,batch.y.view(-1)))*batch.num_graphs; count+=batch.num_graphs
        labels.extend(batch.y.view(-1).tolist());scores.extend(pred.softmax(-1)[:,1].tolist())
    model.train(was_training)
    return total/max(1,count),auc(labels,scores)

def smoke(steps=12):
    (ROOT/'results').mkdir(exist_ok=True)
    rows=[]; split_manifest={}
    for dataset in ['BBBP','HIV','BACE']:
        items,rejected=load_dataset(dataset,limit=32); batch=Batch.from_data_list([d for _,d in items])
        split_manifest[dataset]=dict(rows=[int(d.rowid) for _,d in items],rejected=rejected)
        for backbone in ['gin','gcn']:
            cfg=json.loads((ROOT/'configs'/f'{dataset.lower()}_{backbone}.json').read_text())
            torch.manual_seed(0); base=model_for(cfg,small=True)
            for name in METHODS:
                model=copy.deepcopy(base); model.eval() # deterministic closure, dropout/BN disabled for ALL methods
                opt,criterion=make_method(name,model.parameters(),cfg['methods'][name]); snapshots=[p.clone() for p in model.parameters()]
                with torch.no_grad(): initial=float(F.cross_entropy(model(batch)[1],batch.y.view(-1)))
                status='ok';error='';tic=time.perf_counter();final=initial;completed=0
                for step in range(steps):
                    try:
                        update(model,batch,opt,criterion)
                        with torch.no_grad(): final=float(F.cross_entropy(model(batch)[1],batch.y.view(-1)))
                        if not finite([list(model.parameters()),opt.state_dict(),final]): raise FloatingPointError('Non-finite MolCLR state')
                        completed=step+1
                    except Exception as e: status='error';error=f'{type(e).__name__}: {e}';break
                changed=any(not torch.equal(p,q) for p,q in zip(model.parameters(),snapshots))
                rows.append(dict(dataset=dataset,backbone=backbone,method=name,seed=0,molecules=len(items),steps=completed,initial_loss=initial,final_loss=final,decreased=final<initial,weights_changed=changed,status=status,seconds=time.perf_counter()-tic,error=error))
                print(dataset,backbone,name,status,f'{initial:.5g} -> {final:.5g}',flush=True)
    with (ROOT/'results/molclr_smoke.csv').open('w',newline='',encoding='utf-8') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    (ROOT/'results/molclr_smoke_rows.json').write_text(json.dumps(split_manifest,indent=2))

def train(config_path,method,epochs=None,limit=None,pretrained=True):
    cfg=json.loads(Path(config_path).read_text()); seed=cfg['seed']; torch.manual_seed(seed);np.random.seed(seed);random.seed(seed)
    model=model_for(cfg); checkpoint_info={}
    if pretrained:
        path=ROOT/'molclr/ckpt'/f"pretrained_{cfg['backbone']}.pth"
        source=torch.load(path,map_location='cpu',weights_only=True)
        compatible={k:v for k,v in source.items() if k in model.state_dict() and model.state_dict()[k].shape==v.shape and not k.startswith('pred_head')}
        info=model.load_state_dict(compatible,strict=False);checkpoint_info=dict(path=str(path),loaded=len(compatible),missing=info.missing_keys)
        if not compatible: raise ValueError('No compatible pretrained encoder tensors')
    items,rejected=load_dataset(cfg['dataset'],limit=limit); train_ids,valid_ids,test_ids=split(items,cfg['split'],seed)
    if not train_ids or not valid_ids or not test_ids: raise ValueError('Split has empty partition; use larger dataset')
    data=[x[1] for x in items]
    generator=torch.Generator().manual_seed(seed)
    train_loader=DataLoader([data[i] for i in train_ids],batch_size=cfg['batch_size'],shuffle=True,generator=generator,num_workers=0)
    valid_loader=DataLoader([data[i] for i in valid_ids],batch_size=cfg['batch_size'],num_workers=0)
    test_loader=DataLoader([data[i] for i in test_ids],batch_size=cfg['batch_size'],num_workers=0)
    opt,criterion=make_method(method,model.parameters(),cfg['methods'][method]); epochs=epochs or cfg['epochs']
    run=ROOT/'results'/f"{cfg['dataset'].lower()}_{cfg['backbone']}_{method}";run.mkdir(parents=True,exist_ok=True)
    (run/'protocol.json').write_text(json.dumps(dict(config=cfg,epochs_used=epochs,train_ids=train_ids,valid_ids=valid_ids,test_ids=test_ids,rejected=rejected,checkpoint=checkpoint_info,objective_mode='eval for all methods: gradients enabled; dropout/BN updates disabled'),indent=2))
    best=-float('inf');logs=[]
    for epoch in range(epochs):
        # SwarmPNM best evaluation requires a deterministic objective within each step.
        model.eval() # same deterministic objective for all methods; see recovery_notes.md
        training_loss=0.;n=0;tic=time.perf_counter()
        for batch in train_loader:
            loss=update(model,batch,opt,criterion); training_loss+=float(loss.detach())*batch.num_graphs;n+=batch.num_graphs
            if not finite([list(model.parameters()),opt.state_dict(),float(loss.detach())]): raise FloatingPointError('Non-finite training')
        vl,va=evaluate(model,valid_loader)
        logs.append(dict(epoch=epoch+1,train_loss=training_loss/n,valid_loss=vl,valid_auc=va,seconds=time.perf_counter()-tic));print(logs[-1],flush=True)
        if np.isfinite(va) and va>best:
            best=va;torch.save(model.state_dict(),run/'best_model.pt')
        torch.save(dict(model=model.state_dict(),optimizer=opt.state_dict(),criterion=None if criterion is None else criterion.state_dict(),torch_rng=torch.get_rng_state(),numpy_rng=np.random.get_state(),python_rng=random.getstate(),loader_rng=generator.get_state(),epoch=epoch+1),run/'last_state.pt')
    if (run/'best_model.pt').exists(): model.load_state_dict(torch.load(run/'best_model.pt',weights_only=True))
    tl,ta=evaluate(model,test_loader)
    label_counts={str(label):sum(int(data[i].y)==label for i in test_ids) for label in [0,1]}
    (run/'test.json').write_text(json.dumps(dict(loss=tl,auc=ta if np.isfinite(ta) else None,
        auc_undefined_reason=None if np.isfinite(ta) else 'test partition contains one class',
        test_label_counts=label_counts,counts=dict(train=len(train_ids),valid=len(valid_ids),test=len(test_ids))),indent=2,allow_nan=False))
    with (run/'epochs.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(logs[0]));writer.writeheader();writer.writerows(logs)

if __name__=='__main__':
    torch.set_num_threads(1)
    parser=argparse.ArgumentParser();parser.add_argument('--smoke',action='store_true');parser.add_argument('--steps',type=int,default=12);parser.add_argument('--config',default=str(ROOT/'configs/bbbp_gin.json'));parser.add_argument('--method',choices=METHODS,default='swarmpnm_sqrt');parser.add_argument('--epochs',type=int);parser.add_argument('--limit',type=int);parser.add_argument('--from-scratch',action='store_true');a=parser.parse_args()
    if a.smoke: smoke(a.steps)
    else: train(a.config,a.method,a.epochs,a.limit,not a.from_scratch)
