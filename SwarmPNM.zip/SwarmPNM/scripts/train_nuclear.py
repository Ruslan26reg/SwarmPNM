"""General native-grid nuclear regression with any registered method/architecture.

This is a new comparison runner, separate from the recorded historical search.
Training uses only train rows. Same/near energy groups across libraries stay
together. The fixed final-epoch model is evaluated once on the held-out set.
"""
import argparse
import copy
import hashlib
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import torch
from swarmpnmlab.registry import METHODS, make_method
from swarmpnmlab.optimizers import SwarmPNM
from swarmpnmlab.training import RepeatableClosure
from nuclear.architectures import make_architecture
from nuclear.endf import read_cross_section
from nuclear.metrics import regression_metrics
from scripts.check_nuclear_transfer import energy_group_split
from scripts.run_nuclear import ROOT, prediction, save_csv, save_json
from scripts.run_checks import finite

SOURCES = {
    'xe135': (54135, '135Xe', ['endf8_xe135.endf','tendl2021_xe135.endf','cendl32_xe135.endf']),
    'fe56': (26056, '56Fe', ['endf8_fe56.endf','cendl32_fe56.endf']),
    'u235': (92235, '235U', ['endf8_u235.endf','cendl32_u235.endf']),
}


def run(files, za, isotope, mt, spec, method, optimizer_config, epochs, seed, out, group_width_ev=25000, threads=1):
    if epochs < 1 or threads < 1:raise ValueError('Positive epochs and threads required')
    if Path(out).exists():raise ValueError('Preserve previous runs; choose a new run name')
    tables = [read_cross_section(path, mt=mt, expected_za=za) for path in files]
    low, high = max(t['energy_ev'][0] for t in tables), min(t['energy_ev'][-1] for t in tables)
    if low >= high:raise ValueError('No shared nuclear energy domain')
    rows = [dict(library=Path(path).name, native_point_id=i, energy_ev=e, sigma_barn=s)
            for path, table in zip(files, tables) for i,(e,s) in enumerate(zip(table['energy_ev'], table['sigma_barn'])) if low <= e <= high]
    energy_ev = np.array([r['energy_ev'] for r in rows]);energy = energy_ev/1e6
    y = np.array([r['sigma_barn'] for r in rows])
    train, test, groups = energy_group_split(energy_ev, seed, group_width_ev)
    mean, scale = float(energy[train].mean()), float(energy[train].std())
    if not np.isfinite(scale) or scale <= 0:raise ValueError('Degenerate training energy scale')
    torch.set_num_threads(threads);torch.manual_seed(seed)
    x = torch.tensor(((energy-mean)/scale)[:,None], dtype=torch.float32)
    target = torch.tensor(y[:,None], dtype=torch.float32)
    model = make_architecture(spec, x[train], target[train])
    cfg = copy.deepcopy(optimizer_config)
    if method in ('swarmpnm_sqrt','swarmpnm_inverse','glfgd'):cfg['seed'] = seed
    if method == 'adaswarm':cfg['swarm']['seed'] = seed;cfg['swarm']['bounds'] = None
    opt, criterion = make_method(method, model.parameters(), cfg)
    directory = Path(out);directory.mkdir(parents=True)
    context = dict(za=za, isotope=isotope, mf=3, mt=mt, energy_domain_mev=[low/1e6,high/1e6])
    split = dict(seed=seed, train_ids=train.tolist(), test_ids=test.tolist(), energy_groups=groups.tolist(),
                 input_mean_mev=mean, input_std_mev=scale, energy_group_width_ev=group_width_ev)
    save_csv(directory/'dataset_native.csv', rows)
    save_json(directory/'protocol.json', dict(nuclear_context=context, spec=spec, method=method, optimizer=cfg,
        epochs=epochs, split=split, selection='Fixed final-epoch checkpoint; no test-based selection',
        source_sha256={Path(p).name:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files},
        metric_units='RMSE/MAE in raw barns; R2 dimensionless',
        interpretation='New grouped-holdout comparison; not the old random-row refit and not exact manuscript replication'))
    history=[]
    for epoch in range(1,epochs+1):
        model.train()
        def objective():return torch.nn.functional.mse_loss(model(x[train]), target[train])
        if isinstance(opt, SwarmPNM):
            closure=RepeatableClosure(model,opt,objective)
            try:opt.step(closure)
            finally:closure.commit()
            loss=closure.initial_loss
        else:
            opt.zero_grad();pred=model(x[train])
            loss=criterion(pred,target[train],center=target[train],fitness_fn=lambda z:(z-target[train]).square().mean(dim=(1,2))) if criterion else torch.nn.functional.mse_loss(pred,target[train])
            loss.backward();opt.step()
        if not finite([loss,list(model.parameters()),opt.state_dict()]):raise FloatingPointError('Non-finite training state')
        history.append(dict(epoch=epoch,train_mse=float(loss.detach())))
        if epoch==1 or epoch==epochs or epoch%50==0:print(method,isotope,epoch,'train MSE',float(loss.detach()),flush=True)
    model.eval()
    checkpoint=directory/'model.pt'
    torch.save(dict(model=model.state_dict(), spec=spec, split=split, nuclear_context=context, epoch=epochs,
                    optimizer=opt.state_dict(), criterion=criterion.state_dict() if criterion else None,
                    inference='Final-epoch weights; no resume CLI'),checkpoint)
    pred=prediction(model,x[test]);metrics=regression_metrics(y[test],pred)
    save_csv(directory/'training_history.csv',history)
    save_csv(directory/'test_predictions.csv',[dict(**rows[int(i)],predicted_sigma_barn=float(p)) for i,p in zip(test,pred)])
    result=dict(method=method,architecture=spec,seed=seed,epochs=epochs,train_rows=len(train),test_rows=len(test),**metrics)
    save_json(directory/'test.json',result);print(json.dumps(result),flush=True)
    return result


def main():
    specs=json.loads((ROOT/'configs/architectures.json').read_text())
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--isotope',choices=SOURCES,default='xe135')
    parser.add_argument('--source',type=Path,action='append',help='Custom ENDF files; also pass --za and --isotope-name')
    parser.add_argument('--za',type=int);parser.add_argument('--isotope-name')
    parser.add_argument('--mt',type=int,default=16)
    parser.add_argument('--architecture',choices=list(specs),default='ensemble_3_relu')
    parser.add_argument('--architecture-config',type=Path,help='A custom JSON architecture spec')
    parser.add_argument('--method',choices=METHODS,default='swarmpnm_sqrt')
    parser.add_argument('--methods-config',type=Path,default=ROOT/'configs/checks.json')
    parser.add_argument('--epochs',type=int,default=595);parser.add_argument('--seed',type=int,default=0)
    parser.add_argument('--energy-group-width-ev',type=float,default=25000);parser.add_argument('--threads',type=int,default=1)
    parser.add_argument('--run-name',required=True);args=parser.parse_args()
    za,name,filenames=SOURCES[args.isotope]
    if args.source:
        if args.za is None or not args.isotope_name:parser.error('Custom sources require --za and --isotope-name')
        files=args.source;za,name=args.za,args.isotope_name
    else:
        if args.za is not None or args.isotope_name:parser.error('--za/--isotope-name require custom --source')
        files=[ROOT/'nuclear/sources'/n for n in filenames]
    cfg=json.loads(args.methods_config.read_text())['methods'][args.method]
    if args.methods_config.resolve()==(ROOT/'configs/checks.json').resolve() and args.method=='swarmpnm_sqrt':
        cfg=json.loads((ROOT/'configs/nuclear_xe135.json').read_text())['methods']['swarmpnm_sqrt']
    spec=json.loads(args.architecture_config.read_text()) if args.architecture_config else specs[args.architecture]
    run(files,za,name,args.mt,spec,args.method,cfg,args.epochs,args.seed,ROOT/'results/nuclear'/args.run_name,args.energy_group_width_ev,args.threads)


if __name__=='__main__':main()
