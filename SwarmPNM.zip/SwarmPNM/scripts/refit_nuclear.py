"""Validation-ranked architecture, fixed-budget refit, SwarmPNM training-best inference."""
import argparse
import copy
import csv
import datetime
import json
import sys
import time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import torch
from torch import nn
from swarmpnmlab.registry import make_method
from swarmpnmlab.training import RepeatableClosure
from nuclear.architectures import make_architecture
from nuclear.metrics import regression_metrics
from scripts.run_nuclear import ROOT, prediction, save_csv, save_json
from scripts.search_nuclear import aggregate


def main(config_path, run_name):
    cfg = json.loads(config_path.read_text())
    torch.set_num_threads(cfg['threads'])
    out = ROOT/'results/nuclear'/run_name
    if out.exists():
        raise ValueError('Preserve existing attempts')
    candidates = []
    for source_name in cfg['source_searches']:
        source = ROOT/'results/nuclear'/source_name
        assert json.loads((source/'status.json').read_text())['status'] == 'complete'
        candidates.extend(dict(**r, source_search=source_name) for r in json.loads((source/'ranking.json').read_text()))
    candidates.sort(key=lambda r:r['validation']['r2']['mean'], reverse=True)
    winner = candidates[0]
    source = ROOT/'results/nuclear'/winner['source_search']
    original = json.loads((source/'protocol.json').read_text())
    epochs = int(np.median(winner['selected_epochs']))
    out.mkdir(parents=True)
    (out/'dataset_native.csv').write_bytes((source/'dataset_native.csv').read_bytes())
    rows = list(csv.DictReader((source/'dataset_native.csv').open()))
    energy = np.array([float(r['energy_ev'])/1e6 for r in rows])
    y = np.array([float(r['sigma_barn']) for r in rows])
    save_json(out/'ranking.json', candidates)
    lock = dict(winner=winner, epochs=epochs, config=cfg, test_evaluated=False,
                locked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save_json(out/'selection_locked.json', lock)
    save_json(out/'protocol.json', dict(refit_config=cfg, source_protocol=original,
        dataset_sha256=original['dataset_sha256'], seeds=original['search_config']['seeds'],
        training_rows=112, test_rows=28, epochs=epochs, winner=winner,
        interpretation='Retrospective architecture selection and refit on evaluated Xe135(n,2n) tables; not manuscript Table 7 replication.'))
    final = []
    for seed in original['search_config']['seeds']:
        previous = json.loads((source/f'split_seed{seed}.json').read_text())
        train, test = np.array(previous['outer_train_ids']), np.array(previous['test_ids'])
        mean, scale = energy[train].mean(), energy[train].std()
        split = dict(seed=seed, train_ids=train.tolist(), test_ids=test.tolist(),
                     input_mean_mev=float(mean), input_std_mev=float(scale),
                     previous_validation_ids=previous['validation_ids'])
        save_json(out/f'split_seed{seed}.json', split)
        x = torch.tensor(((energy-mean)/scale)[:,None], dtype=torch.float32)
        target = torch.tensor(y[:,None], dtype=torch.float32)
        torch.manual_seed(seed)
        model = make_architecture(winner['spec'], x[train], target[train])
        if any(isinstance(m, nn.Dropout) and m.p for m in model.modules()):
            raise ValueError('Training-best refit requires deterministic no-dropout objective')
        optcfg = dict(original['swarmpnm_config'], seed=seed)
        opt, _ = make_method('swarmpnm_sqrt', model.parameters(), optcfg)
        trial = out/winner['candidate']/f'seed{seed}'
        trial.mkdir(parents=True)
        history = []
        tic = time.perf_counter()
        for epoch in range(1, epochs+1):
            model.train()
            def objective():
                return nn.functional.mse_loss(model(x[train]), target[train])
            closure = RepeatableClosure(model, opt, objective)
            try:
                opt.step(closure)
            finally:
                closure.commit()
            if not torch.isfinite(closure.initial_loss) or any(not torch.isfinite(p).all() for p in model.parameters()):
                raise FloatingPointError('Non-finite refit')
            if epoch == 1 or epoch % 10 == 0 or epoch == epochs:
                history.append(dict(epoch=epoch, current_train_mse=float(closure.initial_loss), swarmpnm_best_train_mse=opt.meta['best_loss']))
        last_model = copy.deepcopy(model.state_dict())
        with torch.no_grad():
            for p in model.parameters():
                p.copy_(opt.state[p]['best'])
        best_train_metrics = regression_metrics(y[train], prediction(model, x[train]))
        assert abs(best_train_metrics['rmse']**2-opt.meta['best_loss']) < 1e-5
        state = dict(model=copy.deepcopy(model.state_dict()), training_last_model=last_model,
            optimizer=opt.state_dict(), torch_rng=torch.get_rng_state().clone(), epoch=epochs,
            spec=winner['spec'], split=split, swarmpnm_config=optcfg, train_metrics=best_train_metrics,
            inference='SwarmPNM personal-best model; optimizer state corresponds to training_last_model, not the inference model. No resume CLI.',
            validation_selected_epochs=winner['selected_epochs'])
        torch.save(state, trial/'best_train.pt')
        pred = prediction(model, x[test])
        result = dict(seed=seed, candidate=winner['candidate'], epochs=epochs, train_rows=len(train),
                      seconds=time.perf_counter()-tic, **regression_metrics(y[test], pred))
        save_json(trial/'test.json', result)
        save_csv(trial/'test_predictions.csv', [dict(**rows[int(i)], predicted_sigma_barn=float(p), residual_barn=float(p-y[i])) for i,p in zip(test,pred)])
        save_csv(trial/'training_history.csv', history)
        save_json(trial/'train.json', best_train_metrics)
        final.append(result)
        print('REFIT TEST', json.dumps(result), flush=True)
    summary = dict(winner=winner, epochs=epochs, test=aggregate(final), per_seed=final,
                   target_r2=cfg['target_test_mean_r2'], target_met=aggregate(final)['r2']['mean']>=cfg['target_test_mean_r2'],
                   all_three_seeds_at_least_target=all(r['r2']>=cfg['target_test_mean_r2'] for r in final))
    save_json(out/'final.json', summary)
    save_json(out/'status.json', dict(status='complete', **summary))
    print('FINAL REFIT', json.dumps(summary), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=Path, default=ROOT/'configs/nuclear_refit.json')
    parser.add_argument('--run-name', required=True)
    args = parser.parse_args()
    main(args.config, args.run_name)
