"""Predict barns at specified MeV energies using a saved, locally trained checkpoint."""
import argparse
import json
import math
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import torch
from nuclear.architectures import make_architecture


def _context(state, checkpoint):
    if 'nuclear_context' in state:
        return state['nuclear_context']
    # Original checkpoints omitted isotope metadata. Recover it from their
    # adjacent recorded protocol, never from an arbitrary filename.
    path = Path(checkpoint).resolve().parents[2]/'protocol.json'
    if path.exists():
        protocol = json.loads(path.read_text(encoding='utf-8'))
        while isinstance(protocol, dict) and protocol:
            cfg = protocol.get('config', {})
            if 'isotope' in cfg and 'energy_domain_ev' in protocol:
                za = cfg.get('za', 54135 if cfg['isotope']=='135Xe' else None)
                if za is not None:
                    return dict(za=za, isotope=cfg['isotope'], mt=cfg['mt'],
                        energy_domain_mev=[e/1e6 for e in protocol['energy_domain_ev']],
                        metadata_source='adjacent recorded protocol (legacy checkpoint)')
            protocol = protocol.get('source_protocol')
    return None


def load_predictor(checkpoint):
    state = torch.load(checkpoint, map_location='cpu', weights_only=True)
    # Shapes are created here; trained basis buffers and weights are restored below.
    with torch.random.fork_rng(devices=[]):
        model = make_architecture(state['spec'], torch.tensor([[-1.], [1.]]), torch.zeros(2, 1))
    # Phase-1 Gaussian checkpoints predate the explicit default gain buffer.
    if state['spec']['kind'] == 'rbf' and 'output_gain' not in state['model']:
        state['model']['output_gain'] = torch.tensor(1.)
    model.load_state_dict(state['model'])
    model.eval()
    model.nuclear_context = _context(state, checkpoint)
    return model, state['split']


@torch.no_grad()
def predict_energies(checkpoint, energies_mev, *, expected_za=None, expected_mt=None, allow_extrapolation=False):
    values = torch.as_tensor(energies_mev, dtype=torch.float64).reshape(-1)
    if not values.numel() or not torch.isfinite(values).all() or torch.any(values<=0):
        raise ValueError('Provide finite positive neutron energies in MeV')
    model, split = load_predictor(checkpoint)
    context = model.nuclear_context
    if context is None:
        raise ValueError('Checkpoint lacks isotope/reaction/domain metadata; retain the adjacent protocol or add verified nuclear_context')
    if expected_za is not None and (context is None or context.get('za')!=expected_za):
        raise ValueError('Checkpoint isotope does not match requested ZA, or isotope metadata is missing')
    if expected_mt is not None and (context is None or context.get('mt')!=expected_mt):
        raise ValueError('Checkpoint reaction does not match requested MT, or reaction metadata is missing')
    domain=context.get('energy_domain_mev',[])
    if len(domain)!=2 or not all(math.isfinite(e) for e in domain) or not 0<domain[0]<domain[1]:
        raise ValueError('Invalid checkpoint energy domain')
    if not allow_extrapolation:
        low, high = domain
        if torch.any(values<low) or torch.any(values>high):
            raise ValueError(f'Energy outside recorded data domain [{low}, {high}] MeV; extrapolation requires explicit opt-in')
    mean, scale = split['input_mean_mev'], split['input_std_mev']
    if not math.isfinite(mean) or not math.isfinite(scale) or scale<=0:
        raise ValueError('Invalid checkpoint input standardization')
    x = ((values.reshape(-1, 1) - mean) / scale).to(torch.float32)
    if not torch.isfinite(x).all():raise ValueError('Normalized energy is not finite in float32')
    output = model(x).flatten()
    if not torch.isfinite(output).all():raise FloatingPointError('Non-finite model prediction')
    return output.tolist()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--energy-mev', type=float, nargs='+', required=True)
    parser.add_argument('--za', type=int, help='Expected isotope ZA = 1000*Z + A')
    parser.add_argument('--mt', type=int, help='Expected ENDF reaction MT (16 for n,2n)')
    parser.add_argument('--allow-extrapolation', action='store_true')
    args = parser.parse_args()
    pred = predict_energies(args.checkpoint, args.energy_mev, expected_za=args.za, expected_mt=args.mt, allow_extrapolation=args.allow_extrapolation)
    model, _ = load_predictor(args.checkpoint)
    print(json.dumps(dict(nuclear_context=model.nuclear_context, predictions=[dict(energy_mev=e, predicted_sigma_barn=p)
                      for e,p in zip(args.energy_mev, pred)]), indent=2, allow_nan=False))
