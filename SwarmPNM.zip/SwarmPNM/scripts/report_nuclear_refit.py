"""Report the validation-ranked, fixed-budget refit without hiding prior searches."""
import argparse
import csv
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scripts.predict_nuclear import predict_energies
from scripts.run_nuclear import ROOT


def main(run_name):
    run = ROOT/'results/nuclear'/run_name
    final = json.loads((run/'final.json').read_text())
    protocol = json.loads((run/'protocol.json').read_text())
    cfg = protocol['refit_config']
    winner = final['winner']['candidate']
    lines = ['# SwarmPNM: итог подбора архитектуры 135Xe(n,2n)', '',
        f"Архитектура: **{winner}**. Средний test R² = **{final['test']['r2']['mean']:.6f} ± {final['test']['r2']['sample_std']:.6f}** на seeds 0,1,2. ± означает выборочное стандартное отклонение, не доверительный интервал.",
        f"Цель среднего R² ≥ 0,94: **{'достигнута' if final['target_met'] else 'не достигнута'}**. Все три разбиения по отдельности ≥ 0,94: **{'да' if final['all_three_seeds_at_least_target'] else 'нет'}**.",
        'R² — коэффициент детерминации регрессии, не accuracy классификации.', '',
        '| Seed | Test R² | RMSE, барн | MAE, барн |', '|---|---:|---:|---:|']
    for r in final['per_seed']:
        lines.append(f"| {r['seed']} | {r['r2']:.6f} | {r['rmse']:.6f} | {r['mae']:.6f} |")
    lines += ['', f"Средние RMSE/MAE: {final['test']['rmse']['mean']:.6f}/{final['test']['mae']['mean']:.6f} барн.", '',
        '## Что выбрано', '', '```json', json.dumps(final['winner']['spec'], indent=2), '```', '',
        f"Архитектура выбрана по максимальному среднему validation R² среди всех кандидатов трёх стадий. Источник выбора: {final['winner']['source_search']}, validation R² = {final['winner']['validation']['r2']['mean']:.6f}.",
        'Проверены 22 различные архитектуры: MLP, RBF с разными масштабами выходной головы и ансамбли. С учётом повторов с большим бюджетом — 26 конфигураций, 78 прогонов на трёх разбиениях. Все результаты и плохие попытки сохранены.',
        f"На поиске выделялось 90 train / 22 validation / 28 test строк. Затем выбранная архитектура обучена заново на всех **112 train-строках**, включая прежние validation-строки; прежние 28 test-строк каждого seed оставлены отложенными. Бюджет **{final['epochs']} эпох** — медиана validation-выбранных эпох {final['winner']['selected_epochs']}, зафиксированная до финального переобучения.",
        'Выходная модель использует целиком лучший набор параметров SwarmPNM по MSE на полном train-batch. Это внутренний personal best оптимизатора, не выбор по test. Текущая последняя точка, состояние оптимизатора и лучшая модель сохранены раздельно внутри checkpoint; состояния оптимизатора соответствуют training_last_model. CLI resume не реализован.',
        'Вход — только энергия; стандартизация на 112 train-строках. Ответ и MSE в исходных барнах. В ансамбле три подсети обучаются совместно одним SwarmPNM по MSE их среднего выхода. Формула SwarmPNM sqrt, lr=0,0005 и остальные коэффициенты прежние; другой оптимизатор не подставлялся.',
        'Изменились архитектура, бюджет, выбор модели и финальное переобучение. Улучшение нельзя приписать только архитектуре.', '',
        '## Все стадии', '', '| Стадия | Победитель по validation | Средний test R² этого победителя |', '|---|---|---:|']
    for name in cfg['source_searches']:
        result = json.loads((ROOT/'results/nuclear'/name/'final.json').read_text())
        lines.append(f"| {name} | {result['winner']['candidate']} | {result['test']['r2']['mean']:.6f} |")
    lines += ['', '## Пределы сравнения', '',
        'Это ретроспективный подбор: прежние test-разбиения уже просматривались, и поиск продолжался после недостижения целевой test-метрики. Внутри стадий ranking и checkpoint selection используют validation; это не делает итог свежим независимым подтверждением.',
        '140 исходных MF3/MT16 узлов трёх оценённых библиотек ENDF/B-VIII.0, TENDL-2021, CENDL-3.2, общий диапазон 6,50539–20 МэВ. JENDL-5 отсутствует. Узлы не являются независимыми экспериментальными измерениями; одинаковая энергия из разных библиотек может попасть в разные части разбиения. Проверяется интерполяция этой реакции этого изотопа, не перенос на другие ядра и не экстраполяция.',
        'В статье SwarmPNM R² = 0,977. Исторические CSV и преобразования авторов неизвестны полностью, поэтому результат здесь не приравнивается к таблице статьи. Исходная новая проверка MLP после 200 эпох имела средний R² = 0,727836; сравнение с итогом меняет несколько условий одновременно.', '',
        '## Использование', '',
        f'`python scripts/predict_nuclear.py --checkpoint results/nuclear/{run_name}/{winner}/seed0/best_train.pt --energy-mev 7 10 15 20`',
        f'`python scripts/verify_nuclear_search.py --run-name {run_name}` пересчитывает построчные предсказания и метрики из весов.',
        '`python scripts/refit_nuclear.py --run-name new_refit` повторяет финальное переобучение из сохранённых validation-рейтингов. Для полного поиска запустите три configs/nuclear_architecture_search*.json под новыми именами и укажите их в копии nuclear_refit.json.',
        'Весовые файлы best_train.pt содержат модель, масштабы входа, optimizer state и параметры выбранной архитектуры. protocol.json — весь протокол; selection_locked.json — решение до test; final.json — агрегаты; test_predictions.csv — ответы по каждой строке; verification.json — независимый пересчёт из checkpoint.', '',
        '![Кривые и метрики](comparison.png)', '']
    (run/'report.md').write_text('\n'.join(lines), encoding='utf-8')
    rows = list(csv.DictReader((run/'dataset_native.csv').open()))
    fig, axes = plt.subplots(1, 2, figsize=(13, 5), gridspec_kw={'width_ratios':[1.6,1]})
    for library in sorted({r['library'] for r in rows}):
        subset = [r for r in rows if r['library']==library]
        axes[0].plot([float(r['energy_ev'])/1e6 for r in subset], [float(r['sigma_barn']) for r in subset], '.-', linewidth=.8, markersize=3, alpha=.55, label=library)
    grid = np.linspace(6.50539, 20, 250)
    for seed in protocol['seeds']:
        pred = predict_energies(run/winner/f'seed{seed}'/'best_train.pt', grid)
        axes[0].plot(grid, pred, linewidth=1.4, label=f'SwarmPNM seed {seed}')
    axes[0].set(xlabel='Energy (MeV)', ylabel='Cross section (barn)', title=f'135Xe(n,2n): {winner}')
    axes[0].legend(fontsize=8, ncols=2)
    values = [r['r2'] for r in final['per_seed']]
    axes[1].bar([f'Seed {r["seed"]}' for r in final['per_seed']], values, color='#347da1')
    axes[1].axhline(.94, color='#b44e2e', linestyle='--', label='Requested R² = 0.94')
    for i,value in enumerate(values):
        axes[1].text(i,value+.006,f'{value:.4f}',ha='center')
    axes[1].set(ylabel='Outer test R²', ylim=(min(.8,min(values)-.04),1.01), title=f'Mean R² = {final["test"]["r2"]["mean"]:.4f}')
    axes[1].legend(fontsize=8)
    for ax in axes:
        ax.grid(alpha=.15)
    fig.suptitle('Validation-ranked architecture, refit, training-best inference; retrospective holdout', fontsize=11)
    fig.tight_layout()
    fig.savefig(run/'comparison.png', dpi=180)
    fig.savefig(run/'comparison.svg')
    plt.close(fig)
    print(run/'report.md')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--run-name', required=True)
    main(parser.parse_args().run_name)
