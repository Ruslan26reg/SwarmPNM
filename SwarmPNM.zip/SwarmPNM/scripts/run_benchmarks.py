"""All manuscript formulas; new explicitly projected comparison protocol."""
import argparse
import copy
import csv
import json
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import torch
from swarmpnmlab.benchmarks import FUNCTIONS,PAPER_FUNCTIONS,STARTS,objective
from swarmpnmlab.optimizers import SwarmPNM
from swarmpnmlab.registry import METHODS,make_method
from scripts.run_checks import ROOT,finite


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--functions',nargs='+',choices=FUNCTIONS,default=list(PAPER_FUNCTIONS))
    parser.add_argument('--methods',nargs='+',choices=METHODS,default=list(METHODS))
    parser.add_argument('--seeds',nargs='+',type=int,default=[0,1,2])
    parser.add_argument('--steps',type=int,default=500)
    parser.add_argument('--config',type=Path,default=ROOT/'configs/checks.json')
    parser.add_argument('--run-name',required=True);args=parser.parse_args()
    if args.steps<1:parser.error('Positive step budget required')
    out=ROOT/'results/benchmarks'/args.run_name
    if out.exists():raise ValueError('Preserve previous attempts; choose a new run name')
    out.mkdir(parents=True);torch.set_num_threads(1)
    config=json.loads(args.config.read_text());summary=[];trajectory=[]
    protocol=dict(functions=args.functions,methods=args.methods,seeds=args.seeds,steps=args.steps,config=config,
        initial_points='Printed manuscript coordinates; Sphere uses (1,-1)',
        bounds=[-10,10],projection='Every method is projected to the same NEW box [-10,10]; CFGD anchor must cover it',
        interpretation='New comparison, no recovery of historical Bayesian tuning or convergence criterion',
        formula_issues=['Modified Easom-type has a positive exponential: origin is not a minimum and it is unbounded below without bounds',
                        'Plateau is sum(floor(x)); origin is not a global minimum; autograd derivative is zero almost everywhere',
                        'The printed Levy formula is preserved, rather than replaced by another Levy variant'])
    (out/'protocol.json').write_text(json.dumps(protocol,indent=2))
    for name in args.functions:
        for seed in args.seeds:
            for method in args.methods:
                torch.manual_seed(seed)
                p=torch.nn.Parameter(torch.tensor(STARTS.get(name,(1.,-1.)),dtype=torch.float64))
                cfg=copy.deepcopy(config['methods'][method])
                if method in ('swarmpnm_sqrt','swarmpnm_inverse','glfgd'):cfg['seed']=seed
                if method.startswith('swarmpnm'):cfg['bounds']=[-10,10]
                if method=='adaswarm':cfg['swarm'].update(seed=seed,bounds=[-10,10])
                if method=='cfgd' and cfg.get('anchor',-10)>-10:raise ValueError('CFGD anchor must be <= -10 in this protocol')
                opt,criterion=make_method(method,[p],cfg);evaluations=0
                def loss(x):
                    nonlocal evaluations
                    evaluations+=1 if x.ndim==1 else x.shape[0]
                    return objective(name,x)
                def closure():
                    opt.zero_grad();value=loss(p);value.backward();return value
                initial=float(loss(p).detach());best=initial;final=initial;status='ok';error='';completed=0
                for step in range(1,args.steps+1):
                    try:
                        if isinstance(opt,SwarmPNM):opt.step(closure)
                        else:
                            opt.zero_grad();value=criterion(p,loss_fn=loss,fitness_fn=loss) if criterion else loss(p)
                            value.backward();opt.step()
                            with torch.no_grad():p.clamp_(-10,10)
                        final=float(loss(p).detach())
                        if not finite([p,opt.state_dict(),final]):raise FloatingPointError('Non-finite benchmark state')
                        best=min(best,final);completed=step
                        trajectory.append(dict(function=name,method=method,seed=seed,step=step,x=float(p[0].detach()),y=float(p[1].detach()),loss=final))
                    except Exception as exc:
                        status='error';error=f'{type(exc).__name__}: {exc}';break
                summary.append(dict(function=name,method=method,seed=seed,steps=completed,initial_loss=initial,final_loss=final,best_loss=best,objective_evaluations=evaluations,status=status,error=error))
                print(name,method,seed,status,best,flush=True)
    for filename,rows in [('summary.csv',summary),('trajectories.csv',trajectory)]:
        if rows:
            with (out/filename).open('w',newline='') as stream:
                writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    (out/'summary.json').write_text(json.dumps(summary,indent=2))
    if any(row['status']=='error' for row in summary):raise SystemExit('Some runs failed; raw failures preserved in summary.csv')


if __name__=='__main__':main()
