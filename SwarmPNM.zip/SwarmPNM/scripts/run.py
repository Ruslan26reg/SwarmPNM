"""One entry point for the source checkout: list, benchmarks, checks, molecular, nuclear."""
import json
import runpy
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
COMMANDS={'benchmarks':'run_benchmarks','checks':'run_checks','molecular':'reproduce_swarmpnm','nuclear':'train_nuclear','fetch':'fetch_assets'}

if __name__=='__main__':
    if len(sys.argv)<2 or sys.argv[1] in ['-h','--help']:
        print(__doc__);print('Commands:',', '.join(['list']+list(COMMANDS)));raise SystemExit(0)
    command=sys.argv[1]
    if command=='list':
        print((ROOT/'configs/tasks.json').read_text());raise SystemExit(0)
    if command not in COMMANDS:raise SystemExit('Unknown task; run python scripts/run.py --help')
    sys.argv=[str(ROOT/'scripts'/f'{COMMANDS[command]}.py')]+sys.argv[2:]
    try:runpy.run_module('scripts.'+COMMANDS[command],run_name='__main__')
    except ModuleNotFoundError as exc:
        if exc.name in ['rdkit','torch_geometric']:
            raise SystemExit('Molecular tasks require: python -m pip install -e ".[molecular]"') from exc
        raise
