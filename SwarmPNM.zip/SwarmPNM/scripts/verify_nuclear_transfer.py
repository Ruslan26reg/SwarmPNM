"""Reconstruct new-isotope test responses and grouping checks from archived evidence."""
import argparse,csv,hashlib,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
import torch
from nuclear.endf import read_cross_section
from nuclear.metrics import regression_metrics
from scripts.predict_nuclear import predict_energies
from scripts.run_nuclear import ROOT,save_json


def main(run_name):
    root=ROOT/'results/nuclear'/run_name
    protocol=json.loads((root/'protocol.json').read_text())
    cfg=protocol['config'];summary=json.loads((root/'summary.json').read_text())
    refs=[ROOT/name for name in protocol['reference_checkpoint_hashes']]
    for path in refs:
        assert hashlib.sha256(path.read_bytes()).hexdigest()==protocol['reference_checkpoint_hashes'][str(path.relative_to(ROOT))]
    verified=[]
    for isotope in cfg['isotopes']:
        directory=root/isotope['token'];data=json.loads((directory/'data_protocol.json').read_text())
        assert hashlib.sha256((directory/'dataset_native.csv').read_bytes()).hexdigest()==data['dataset_sha256']
        rows=list(csv.DictReader((directory/'dataset_native.csv').open()))
        tables={}
        for library,source in data['sources'].items():
            path=ROOT/'nuclear/sources'/source['file']
            assert hashlib.sha256(path.read_bytes()).hexdigest()==source['sha256']==source['acquisition']['sha256']
            tables[library]=read_cross_section(path,mt=isotope['mt'],expected_za=isotope['za'])
        energy=np.array([float(r['energy_ev'])/1e6 for r in rows]);y=np.array([float(r['sigma_barn']) for r in rows])
        for row in rows:
            table=tables[row['library']];index=int(row['native_point_id'])
            assert float(row['energy_ev'])==table['energy_ev'][index]
            assert float(row['sigma_barn'])==table['sigma_barn'][index]
        methods={'frozen_xe135':[],'retrained_swarmpnm':[]}
        for seed in cfg['seeds']:
            trial=directory/f'seed{seed}';split=json.loads((trial/'split.json').read_text())
            train=np.array(split['train_ids']);test=np.array(split['test_ids'])
            assert not set(train)&set(test) and set(train)|set(test)==set(range(len(rows)))
            groups=np.floor(energy*1e6/cfg['energy_group_width_ev']).astype(np.int64)
            assert not set(groups[train])&set(groups[test])
            assert abs(energy[train].mean()-split['input_mean_mev'])<1e-12
            assert abs(energy[train].std()-split['input_std_mev'])<1e-12
            checkpoint=trial/'best_train.pt';state=torch.load(checkpoint,weights_only=True,map_location='cpu')
            assert state['spec']==protocol['architecture'] and state['epoch']==protocol['epochs']
            assert state['nuclear_context']==data['nuclear_context']
            assert all(group['variant']=='sqrt' for group in state['optimizer']['param_groups'])
            prediction=predict_energies(checkpoint,energy[test],expected_za=isotope['za'],expected_mt=isotope['mt'])
            frozen=np.mean([predict_energies(p,energy[test]) for p in refs],axis=0)
            saved=list(csv.DictReader((trial/'test_predictions.csv').open()))
            assert [int(r['row_id']) for r in saved]==test.tolist()
            np.testing.assert_allclose(prediction,[float(r['retrained_sigma_barn']) for r in saved],atol=2e-6,rtol=2e-6)
            np.testing.assert_allclose(frozen,[float(r['frozen_xe135_sigma_barn']) for r in saved],atol=2e-6,rtol=2e-6)
            result=json.loads((trial/'result.json').read_text())
            for method,pred in [('frozen_xe135',frozen),('retrained_swarmpnm',prediction)]:
                measured=regression_metrics(y[test],pred)
                for key in ['r2','rmse','mae']:assert abs(measured[key]-result[method][key])<2e-6
                methods[method].append(measured)
            verified.append(dict(isotope=isotope['isotope'],seed=seed,group_overlap=0,checkpoint_metrics_reproduced=True))
        for method,records in methods.items():
            for key in ['r2','rmse','mae']:
                assert abs(np.mean([r[key] for r in records])-summary[isotope['isotope']][method][key]['mean'])<2e-6
                assert abs(np.std([r[key] for r in records],ddof=1)-summary[isotope['isotope']][method][key]['sample_std'])<2e-6
    output=dict(status='passed',trials=verified,checks=['official source hashes and native-row correspondence',
        'unchanged Xe reference checkpoint hashes','no shared energy groups','train-only normalization',
        'fixed architecture and epoch budget','recomputed checkpoint predictions and aggregate metrics'])
    save_json(root/'verification.json',output);print(json.dumps(output,indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--run-name',required=True)
    main(parser.parse_args().run_name)
