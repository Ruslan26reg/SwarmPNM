"""Validation-only architecture search, followed by locked-winner outer-test evaluation."""
import argparse
import copy
import csv
import datetime
import hashlib
import json
import sys
import time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import torch
from torch import nn
from swarmpnmlab.registry import make_method
from swarmpnmlab.training import RepeatableClosure
from nuclear.architectures import make_architecture
from nuclear.metrics import regression_metrics
from scripts.run_nuclear import ROOT, prediction, save_csv, save_json


def aggregate(values):
    return {metric: {'mean': float(np.mean([v[metric] for v in values])),
                     'sample_std': float(np.std([v[metric] for v in values], ddof=1))}
            for metric in ('r2', 'rmse', 'mae')}


def main(config_path, run_name):
    cfg = json.loads(config_path.read_text(encoding='utf-8'))
    source = ROOT / 'results/nuclear' / cfg['source_run']
    out = ROOT / 'results/nuclear' / run_name
    if out.exists():
        raise ValueError('Preserve existing runs; use a new run name')
    out.mkdir(parents=True)
    torch.set_num_threads(cfg['threads'])
    rows = list(csv.DictReader((source / 'dataset_native.csv').open(encoding='utf-8')))
    energy = np.array([float(r['energy_ev']) / 1e6 for r in rows])
    y = np.array([float(r['sigma_barn']) for r in rows])
    (out / 'dataset_native.csv').write_bytes((source / 'dataset_native.csv').read_bytes())
    original = json.loads((source / 'protocol.json').read_text())
    optimizer_config = original['config']['methods']['swarmpnm_sqrt']
    save_json(out / 'protocol.json', dict(
        search_config=cfg, search_config_file=config_path.name, swarmpnm_config=optimizer_config, source_protocol=original,
        started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        dataset_sha256=hashlib.sha256((out / 'dataset_native.csv').read_bytes()).hexdigest(),
        test_exposure='Outer test rows were already evaluated in the previous architecture experiment. This is a retrospective comparison, not a fresh confirmatory holdout.',
        changes=f"New architectures; train-only inner split/standardization/RBF centers and initialization; up to {cfg['epochs']} epochs; validation checkpoint selection. SwarmPNM formula and coefficients unchanged. No test-based checkpoint/architecture selection.",
        interpretation='R2 on random held-out evaluated-library rows for Xe135(n,2n), three libraries; not reproduction of manuscript Table 7.'))
    splits = {}
    for seed in cfg['seeds']:
        previous = json.loads((source / f'split_seed{seed}.json').read_text())
        outer_train = np.array(previous['train_ids'])
        shuffled = np.random.default_rng(seed + 104729).permutation(outer_train)
        nval = max(2, int(round(len(shuffled) * cfg['validation_fraction_of_outer_train'])))
        train, val = shuffled[nval:], shuffled[:nval]
        mean, scale = energy[train].mean(), energy[train].std()
        split = dict(seed=seed, train_ids=train.tolist(), validation_ids=val.tolist(),
                     outer_train_ids=previous['train_ids'], test_ids=previous['test_ids'],
                     input_mean_mev=float(mean), input_std_mev=float(scale))
        save_json(out / f'split_seed{seed}.json', split)
        splits[seed] = split
    records = []
    ranking = []
    for spec in cfg['candidates']:
        candidate = out / spec['name']
        candidate.mkdir()
        current = []
        for seed in cfg['seeds']:
            split = splits[seed]
            train, val = np.array(split['train_ids']), np.array(split['validation_ids'])
            x = torch.tensor(((energy - split['input_mean_mev']) / split['input_std_mev'])[:, None], dtype=torch.float32)
            target = torch.tensor(y[:, None], dtype=torch.float32)
            torch.manual_seed(seed)
            model = make_architecture(spec, x[train], target[train])
            ocfg = dict(optimizer_config, seed=seed)
            opt, _ = make_method('swarmpnm_sqrt', model.parameters(), ocfg)
            trial = candidate / f'seed{seed}'
            trial.mkdir()
            best_mse, best = float('inf'), None
            history = []
            tic = time.perf_counter()
            error = None
            for epoch in range(1, cfg['epochs'] + 1):
                model.train()
                def objective():
                    return nn.functional.mse_loss(model(x[train]), target[train])
                closure = RepeatableClosure(model, opt, objective)
                try:
                    opt.step(closure)
                finally:
                    closure.commit()
                if not torch.isfinite(closure.initial_loss) or any(not torch.isfinite(p).all() for p in model.parameters()):
                    error = 'Non-finite training loss or parameters'
                    break
                if epoch == 1 or epoch % cfg['validation_every'] == 0:
                    pred = prediction(model, x[val])
                    metrics = regression_metrics(y[val], pred)
                    history.append(dict(epoch=epoch, train_mse=float(closure.initial_loss), **metrics))
                    if metrics['rmse'] ** 2 < best_mse:
                        best_mse = metrics['rmse'] ** 2
                        best = dict(model=copy.deepcopy(model.state_dict()), optimizer=copy.deepcopy(opt.state_dict()),
                                    torch_rng=torch.get_rng_state().clone(), epoch=epoch, spec=spec, split=split,
                                    validation=metrics, swarmpnm_config=ocfg)
            save_csv(trial / 'validation_history.csv', history)
            if best is not None:
                torch.save(best, trial / 'best_validation.pt')
            record = dict(candidate=spec['name'], seed=seed, status='complete' if error is None else 'error',
                          error=error, seconds=time.perf_counter()-tic, selected_epoch=best['epoch'] if best else None,
                          train_rows=len(train), validation_rows=len(val), parameters=sum(p.numel() for p in model.parameters()),
                          validation=best['validation'] if best else None)
            save_json(trial / 'result.json', record)
            records.append(record)
            current.append(record)
            save_json(out / 'search_results.json', records)
            save_json(out / 'status.json', dict(status='searching', candidate=spec['name'], seed=seed,
                                              finished_trials=len(records), total_trials=len(cfg['candidates'])*len(cfg['seeds'])))
            print('VALIDATION', json.dumps(record), flush=True)
        if all(r['status'] == 'complete' for r in current):
            ranking.append(dict(candidate=spec['name'], spec=spec, validation=aggregate([r['validation'] for r in current]),
                                selected_epochs=[r['selected_epoch'] for r in current]))
    ranking.sort(key=lambda r: r['validation']['r2']['mean'], reverse=True)
    if not ranking:
        raise RuntimeError('No complete candidate')
    save_json(out / 'ranking.json', ranking)
    winner = ranking[0]
    # Persist the selection before any outer-test predictions are computed.
    save_json(out / 'selection_locked.json', dict(winner=winner,
        locked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        criterion=cfg['selection'], test_evaluated=False))
    final = []
    for seed in cfg['seeds']:
        trial = out / winner['candidate'] / f'seed{seed}'
        state = torch.load(trial / 'best_validation.pt', map_location='cpu', weights_only=False)
        split = state['split']
        train, test = np.array(split['train_ids']), np.array(split['test_ids'])
        x = torch.tensor(((energy-split['input_mean_mev'])/split['input_std_mev'])[:,None], dtype=torch.float32)
        target = torch.tensor(y[:,None], dtype=torch.float32)
        model = make_architecture(state['spec'], x[train], target[train])
        model.load_state_dict(state['model'])
        pred = prediction(model, x[test])
        metrics = regression_metrics(y[test], pred)
        result = dict(seed=seed, candidate=winner['candidate'], selected_epoch=state['epoch'], **metrics)
        save_json(trial / 'test.json', result)
        save_csv(trial / 'test_predictions.csv', [dict(**rows[int(i)], predicted_sigma_barn=float(p), residual_barn=float(p-y[i])) for i,p in zip(test,pred)])
        final.append(result)
        print('LOCKED WINNER TEST', json.dumps(result), flush=True)
    summary = dict(winner=winner, test=aggregate(final), per_seed=final,
                   target_r2=cfg['target_test_mean_r2'],
                   target_met=aggregate(final)['r2']['mean'] >= cfg['target_test_mean_r2'],
                   all_three_seeds_at_least_target=all(r['r2'] >= cfg['target_test_mean_r2'] for r in final))
    save_json(out / 'final.json', summary)
    save_json(out / 'status.json', dict(status='complete', **summary))
    print('FINAL', json.dumps(summary), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=Path, default=ROOT/'configs/nuclear_architecture_search.json')
    parser.add_argument('--run-name', required=True)
    args = parser.parse_args()
    main(args.config, args.run_name)
