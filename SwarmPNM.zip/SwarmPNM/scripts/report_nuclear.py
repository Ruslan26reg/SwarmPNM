"""Save an auditable nuclear report and standard scientific plots."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import argparse,json,csv,datetime
import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scripts.run_nuclear import make_model
from nuclear.endf import read_cross_section

ROOT=Path(__file__).resolve().parents[1]

def main(run_name):
    directory=ROOT/'results/nuclear'/run_name
    protocol=json.loads((directory/'protocol.json').read_text());cfg=protocol['config']
    results=json.loads((directory/'results.json').read_text());aggregate=json.loads((directory/'aggregate.json').read_text())
    fig,axes=plt.subplots(1,2,figsize=(12.8,4.5),layout='constrained')
    colors={'ENDF/B-VIII.0':'#bb3344','TENDL-2021':'#2465ad','CENDL-3.2':'#268766'}
    low,high=protocol['energy_domain_ev']
    for library,name in cfg['available_libraries'].items():
        table=read_cross_section(ROOT/'nuclear/sources'/name)
        e=np.array(table['energy_ev']);s=np.array(table['sigma_barn']);mask=(e>=low)&(e<=high)
        axes[0].plot(e[mask]/1e6,s[mask],'.-',color=colors[library],label=library,markersize=3,linewidth=1.4)
    # Own local checkpoint only. Seed 0 was predeclared, not chosen by test score.
    state=torch.load(directory/'swarmpnm_sqrt_seed0/last_state.pt',map_location='cpu',weights_only=False)
    model=make_model(cfg);model.load_state_dict(state['model']);model.eval()
    energy=np.linspace(low/1e6,high/1e6,400)
    split=state['split'];x=torch.tensor(((energy-split['input_mean_mev'])/split['input_std_mev'])[:,None],dtype=torch.float32)
    with torch.no_grad():p=model(x).numpy().reshape(-1)
    axes[0].plot(energy,p,'--',color='#e18325',linewidth=2,label='SwarmPNM seed 0, epoch 200')
    axes[0].set(xlabel='Neutron energy (MeV)',ylabel='Cross section (barn)',title=r'$^{135}$Xe(n,2n): official native tables')
    axes[0].grid(alpha=.2);axes[0].legend(fontsize=8)
    for method,color,offset in [('swarmpnm_sqrt','#e18325',-.17),('adamw','#2465ad',.17)]:
        rows=sorted([r for r in results if r['method']==method and r['status']=='complete'],key=lambda r:r['seed'])
        values=[r['rmse'] for r in rows];positions=np.array([r['seed'] for r in rows])+offset
        bars=axes[1].bar(positions,values,width=.30,color=color,label=method)
        axes[1].bar_label(bars,fmt='%.3f',fontsize=9,padding=4)
    axes[1].axhline(.1263,color='#555555',linestyle=':',label='Paper RMSE 0.1263 (different protocol)')
    axes[1].set(xlabel='Seed / random 80:20 row split',ylabel='Test RMSE (barn)',title='All three runs; no failed score removed',xticks=[0,1,2])
    axes[1].set_ylim(0,max(r['rmse'] for r in results if r['status']=='complete')*1.27)
    axes[1].grid(axis='y',alpha=.2);axes[1].legend(fontsize=8)
    for extension in ['png','svg']:fig.savefig(directory/f'comparison.{extension}',dpi=170)
    plt.close(fig)
    fig,axes=plt.subplots(1,3,figsize=(12.8,3.5),layout='constrained',sharey=True)
    for seed,ax in enumerate(axes):
        for method,color in [('swarmpnm_sqrt','#e18325'),('adamw','#2465ad')]:
            with (directory/f'{method}_seed{seed}/epochs.csv').open(newline='') as f:rows=list(csv.DictReader(f))
            ax.plot([int(r['epoch']) for r in rows],[float(r['train_mse']) for r in rows],color=color,label=method,linewidth=1)
        ax.set(xlabel='Epoch',title=f'Seed {seed}',yscale='log');ax.grid(alpha=.2);ax.legend(fontsize=8)
    axes[0].set_ylabel('Training MSE with dropout (barn squared)')
    fig.savefig(directory/'training_curves.png',dpi=170);plt.close(fig)
    report=['# Проверка SwarmPNM на ядерных данных',
            '', 'Проверка завершена. Метрики ядерной части статьи устойчиво не воспроизведены в этом протоколе.',
            '', 'Статья, раздел Nuclear physics problem solving и Table 7: библиотеки ENDF/B-VIII.0, TENDL-2021, CENDL-3.2 и JENDL-5; график ¹³⁵Xe(n,2n); MLP 32–256–256–128, ReLU/Tanh/Tanh/LeakyReLU; dropouts 0.0/0.4/0.4; 200 эпох, batch 256, случайное деление 80/20. SwarmPNM: RMSE 0.1263±0.0084, MAE 0.1173±0.0063, R² 0.977±0.002 по таблице. Точные единицы/нормализация targets, состав выборки и число повторов не установлены.',
            '', 'Выполнено 6 обучений: SwarmPNM-sqrt и AdamW, seeds 0/1/2, по 200 эпох. Полные исходные узлы MF3/MT16 трёх официальных библиотек в общей области 6.50539–20 МэВ. Это 140 строк: ENDF 24, TENDL 27, CENDL 89; train 112, test 28. JENDL-5 не получен: официальные запросы вернули HTML отказа Incapsula, зеркало IAEA — HTTP 403. Иная версия JENDL не подставлялась.',
            '', 'Энергия — единственный вход, переведён в МэВ и стандартизован только по train. Target и RMSE/MAE — в исходных barns; target не нормализован. MSE, последний dropout 0, LeakyReLU slope 0.01, seed, последний checkpoint и способ объединения библиотек — явно новые решения. Параметры SwarmPNM из статьи; неоднозначный lambda сохранён, но не применяется. AdamW — новый контроль с lr=5e-4, wd=1e-5. Это сравнение фиксированных настроек, не оптимально настроенных методов.',
            '', 'Checkpoint — последняя 200-я эпоха, test не используется для подбора. Одинаковые initial weights, split и batch order между методами для каждого seed. SwarmPNM использует RepeatableClosure для одинаковых dropout draws внутри одного шага.',
            '', '| Метод | Seed | Test RMSE, barn | Test MAE, barn | Test R² |',
            '|---|---:|---:|---:|---:|']
    for r in results:
        if r['status']=='complete':report.append(f"| {r['method']} | {r['seed']} | {r['rmse']:.6f} | {r['mae']:.6f} | {r['r2']:.6f} |")
        else:report.append(f"| {r['method']} | {r['seed']} | error | error | error |")
    report+=['', '| Метод | RMSE mean±sample std | MAE mean±sample std | R² mean±sample std |',
             '|---|---:|---:|---:|']
    for method,a in aggregate.items():
        formatted=[f"{a[m]['mean']:.6f} ± {a[m]['sample_std']:.6f}" for m in ['rmse','mae','r2']]
        report.append(f"| {method} | {' | '.join(formatted)} |")
    report+=['', 'SwarmPNM seed 0 ближе к ориентиру: RMSE 0.1354, MAE 0.0964, R² 0.9456. Но остальные seeds заметно хуже, поэтому только этот запуск не выдаётся за воспроизведение. На текущем протоколе контроль AdamW имеет меньшую среднюю ошибку.',
             '', 'Первый эксперимент на двух доступных библиотеках сохранён в соседней папке xe135_native_two_libraries_200epochs. Все 6 попыток сохранены, включая SwarmPNM seed 1 с RMSE 54.4326 и R² −44888.3511. После получения третьей библиотеки выполнен новый запуск с теми же настройками, а не замена плохих seeds или подбор гиперпараметров.',
             '', 'Это проверка интерполяции библиотечных оценок, не независимых измерений. При random-row split энергии могут встречаться и в train, и в test, но в разных библиотеках; точные совпадения перечислены в split JSON. Native grids неравномерны; CENDL даёт 89/140 строк. Таблица статьи может относиться к другой области/набору реакций и transforms; напрямую приравнивать эти значения к Table 7 нельзя.',
             '', 'Все 65 тестов проекта прошли: tests/test_nuclear.py проверяет ENDF-числа, известные физические значения официальной таблицы, ошибочный изотоп/MT, обрезанную таблицу и метрики. Два этапа дали 12 завершённых обучений, все raw predictions и per-epoch logs сохранены.',
             '', 'Для точной репликации нужны авторские CSV, входные признаки/преобразования, область энергии, правила объединения четырёх библиотек, seeds и правило выбора checkpoint. Следующее научное улучшение — восстановить именно этот протокол; подгонка test метрик здесь не проводилась.',
             '', 'Файлы: protocol.json, dataset_native.csv, split_seed*.json, results.json, aggregate.json, */test.json, */test_predictions.csv, */epochs.csv, */last_state.pt. На графике показан заранее выбранный seed 0; промежуточная smooth линия — предсказание модели, не добавленные обучающие данные.',
             '', 'Повторение:', '```powershell', 'python scripts/run_nuclear.py --run-name nuclear_new_attempt', f'python scripts/report_nuclear.py --run-name {run_name}', '```',
             '', 'Для графиков дополнительно установить Matplotlib; для самого обучения он не нужен.',
             '', 'Первичные источники:',
             '- Рукопись: originals/main.tex, строки 1368–1402; исходный рисунок: nuclear/paper_XE-135.png.',
             '- ENDF/B-VIII.0: https://www.nndc.bnl.gov/endf-b8.0/download.html',
             '- TENDL-2021: https://tendl.imperial.ac.uk/tendl_2021/neutron_html/Xe/NeutronXe135.html',
             '- CNDC исходный CENDL-3.2: http://www.nuclear.csdb.cn/CENDL-3.2/n-CENDL-3.2.zip',
             '- IAEA подтверждение исходной ссылки CNDC: https://www-pub.iaea.org/MTCD/Publications/PDF/Newsletters/ND69.pdf',
             '- JENDL-5: https://wwwndc.jaea.go.jp/jendl/j5/elm/z054.html',
             '- Разбор ENDF TAB1: https://docs.openmc.org/en/stable/_modules/openmc/data/endf.html',
             '', 'SHA256 и даты проверки: nuclear/sources/verified_sources.json. NNDC/CNDC ZIP member CRC проверен при извлечении.']
    (directory/'report.md').write_text('\n'.join(report)+'\n',encoding='utf-8')
    print(directory/'report.md')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--run-name',required=True);args=parser.parse_args();main(args.run_name)
