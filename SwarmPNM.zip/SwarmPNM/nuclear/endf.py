"""Read native MF=3 cross-section TAB1 points from an ENDF-6 evaluation.

The record structure follows ENDF-102. Only native points are returned;
no resonance reconstruction, resampling or unit conversion is performed.
"""
from pathlib import Path
import math,re

def number(field):
    value=field.strip()
    if not value:return 0.0
    value=value.replace('D','E').replace('d','e')
    if 'e' not in value.lower():value=re.sub(r'(?<=\d)([+-]\d+)$',r'e\1',value)
    return float(value)

def _fields(line):return [line[j:j+11] for j in range(0,66,11)]

def read_cross_section(path,mt=16,expected_za=54135):
    section=[];mats=set()
    for line in Path(path).read_text(encoding='ascii').splitlines():
        if len(line)<75:continue
        try:mat,mf,kind=int(line[66:70]),int(line[70:72]),int(line[72:75])
        except ValueError:continue  # TPID descriptive line may not have control fields.
        if mf==3 and kind==mt:
            section.append(line);mats.add(mat)
    if len(mats)!=1 or len(section)<3:raise ValueError(f'Expected one complete MF3/MT{mt} section, found MAT={mats}')
    head=_fields(section[0]);za_value=number(head[0])
    if not math.isfinite(za_value) or not za_value.is_integer():raise ValueError('Invalid integer isotope ZA')
    za=int(za_value)
    if za!=expected_za:raise ValueError(f'Wrong isotope: ZA={za}, expected {expected_za}')
    control=_fields(section[1]);nr,np_=int(control[4]),int(control[5])
    if nr<1 or np_<2:raise ValueError('Invalid TAB1 region/point count')
    n_interpolation=(2*nr+5)//6
    if len(section)<2+n_interpolation+(2*np_+5)//6:raise ValueError('Truncated TAB1 points')
    interpolation=[int(x) for line in section[2:2+n_interpolation] for x in _fields(line) if x.strip()][:2*nr]
    regions=list(zip(interpolation[::2],interpolation[1::2]))
    if len(regions)!=nr or regions[-1][0]!=np_:raise ValueError('Invalid TAB1 interpolation breakpoints')
    if any(n<2 or n>np_ or law not in (1,2,3,4,5) for n,law in regions):raise ValueError('Unsupported/invalid interpolation metadata')
    if any(b[0]<=a[0] for a,b in zip(regions,regions[1:])):raise ValueError('TAB1 interpolation breakpoints must increase')
    raw=[number(x) for line in section[2+n_interpolation:] for x in _fields(line)][:2*np_]
    energy=raw[::2];sigma=raw[1::2]
    if len(energy)!=np_ or len(sigma)!=np_:raise ValueError('Wrong TAB1 point count')
    if not all(math.isfinite(x) for x in energy+sigma):raise ValueError('Non-finite nuclear data')
    if any(x<=0 for x in energy) or any(b<a for a,b in zip(energy,energy[1:])):raise ValueError('Energies must be positive and nondecreasing')
    if any(y<0 for y in sigma):raise ValueError('Negative evaluated cross section')
    return dict(za=za,mat=next(iter(mats)),mf=3,mt=mt,qm_ev=number(control[0]),qi_ev=number(control[1]),
                interpolation=regions,energy_ev=energy,sigma_barn=sigma,native_points=np_)
