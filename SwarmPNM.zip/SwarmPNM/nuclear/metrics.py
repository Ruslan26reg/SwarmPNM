import numpy as np

def regression_metrics(observed,predicted):
    y=np.asarray(observed,dtype=np.float64).reshape(-1)
    p=np.asarray(predicted,dtype=np.float64).reshape(-1)
    if len(y)!=len(p) or len(y)<2:raise ValueError('Aligned predictions with at least two rows required')
    if not np.isfinite(y).all() or not np.isfinite(p).all():raise ValueError('Non-finite predictions/targets')
    error=p-y;mse=np.mean(error**2);denom=np.sum((y-y.mean())**2)
    return dict(rmse=float(np.sqrt(mse)),mae=float(np.mean(np.abs(error))),
                r2=float(1-np.sum(error**2)/denom) if denom>0 else None,
                negative_prediction_count=int(np.sum(p<0)),rows=len(y))
