"""Documented nuclear regression reconstruction, separate from MolCLR."""
