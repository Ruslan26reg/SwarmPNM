"""Explicit candidates for one-energy-input regression; no library identity input."""
import torch
from torch import nn


class GaussianNetwork(nn.Module):
    """Fixed Gaussian feature layer and a SwarmPNM-trained linear output head."""
    def __init__(self, centers, width, target_mean, output_gain=1.0):
        super().__init__()
        self.register_buffer('centers', centers.reshape(1, -1).clone())
        self.register_buffer('width', torch.tensor(float(width)))
        self.register_buffer('output_gain', torch.tensor(float(output_gain)))
        self.head = nn.Linear(centers.numel(), 1)
        nn.init.zeros_(self.head.weight)
        nn.init.constant_(self.head.bias, float(target_mean) / output_gain)

    def forward(self, x):
        features = torch.exp(-0.5 * ((x - self.centers) / self.width) ** 2)
        return self.output_gain * self.head(features)


class MeanEnsemble(nn.Module):
    """Jointly trained subnetworks with one mean output and one SwarmPNM optimizer."""
    def __init__(self, members):
        super().__init__()
        self.members = nn.ModuleList(members)

    def forward(self, x):
        return torch.stack([member(x) for member in self.members], dim=0).mean(dim=0)


def make_architecture(spec, training_x, training_y):
    if spec['kind'] == 'ensemble':
        if len(spec['members']) < 2:
            raise ValueError('Ensemble requires at least two members')
        return MeanEnsemble([make_architecture(member, training_x, training_y) for member in spec['members']])
    if spec['kind'] == 'rbf':
        if spec['centers'] < 2 or spec['width_in_spacings'] <= 0 or training_x.max() <= training_x.min() or spec.get('output_gain', 1.0) <= 0:
            raise ValueError('RBF requires distinct training energies, at least two centers and positive width')
        centers = torch.linspace(float(training_x.min()), float(training_x.max()), spec['centers'])
        width = float(centers[1] - centers[0]) * spec['width_in_spacings']
        return GaussianNetwork(centers, width, float(training_y.mean()), spec.get('output_gain', 1.0))
    if spec['kind'] != 'mlp' or not (len(spec['hidden']) == len(spec['activations']) == len(spec['dropout'])):
        raise ValueError('Invalid MLP specification')
    activation = {'ReLU': nn.ReLU, 'Tanh': nn.Tanh, 'SiLU': nn.SiLU, 'LeakyReLU': nn.LeakyReLU}
    layers = []
    inputs = 1
    for units, act, dropout in zip(spec['hidden'], spec['activations'], spec['dropout']):
        layers.extend([nn.Linear(inputs, units), activation[act]()])
        if dropout:
            layers.append(nn.Dropout(dropout))
        inputs = units
    layers.append(nn.Linear(inputs, 1))
    return nn.Sequential(*layers)
