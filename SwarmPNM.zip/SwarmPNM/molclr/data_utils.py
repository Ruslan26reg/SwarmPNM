"""MolCLR atom/bond encodings with deterministic scaffold or seeded splits."""
import csv
from pathlib import Path
import numpy as np
import torch
from rdkit import Chem,RDLogger
from rdkit.Chem.Scaffolds.MurckoScaffold import MurckoScaffoldSmiles
from torch_geometric.data import Data
RDLogger.DisableLog('rdApp.*')
FILES={'BBBP':('BBBP.csv','p_np'),'HIV':('HIV.csv','HIV_active'),'BACE':('bace.csv','Class')}
CHIRAL=[Chem.rdchem.ChiralType.CHI_UNSPECIFIED,Chem.rdchem.ChiralType.CHI_TETRAHEDRAL_CW,Chem.rdchem.ChiralType.CHI_TETRAHEDRAL_CCW]
BONDS=[Chem.rdchem.BondType.SINGLE,Chem.rdchem.BondType.DOUBLE,Chem.rdchem.BondType.TRIPLE,Chem.rdchem.BondType.AROMATIC]
DIRECTIONS=[Chem.rdchem.BondDir.NONE,Chem.rdchem.BondDir.ENDUPRIGHT,Chem.rdchem.BondDir.ENDDOWNRIGHT]

def graph(smiles,label):
    mol=Chem.MolFromSmiles(smiles)
    if mol is None: raise ValueError('Invalid SMILES')
    mol=Chem.AddHs(mol)
    atom=[]
    for a in mol.GetAtoms():
        if a.GetChiralTag() not in CHIRAL: raise ValueError('Unsupported chirality (3-token MolCLR embedding)')
        atom.append([a.GetAtomicNum()-1,CHIRAL.index(a.GetChiralTag())])
    edges=[]; attributes=[]
    for b in mol.GetBonds():
        u=b.GetBeginAtomIdx(); v=b.GetEndAtomIdx(); feature=[BONDS.index(b.GetBondType()),DIRECTIONS.index(b.GetBondDir())]
        edges.extend([[u,v],[v,u]]); attributes.extend([feature,feature])
    return Data(x=torch.tensor(atom,dtype=torch.long),edge_index=torch.tensor(edges,dtype=torch.long).reshape(-1,2).T.contiguous(),edge_attr=torch.tensor(attributes,dtype=torch.long).reshape(-1,2),y=torch.tensor([int(label)],dtype=torch.long))

def load_dataset(name,limit=None,data_dir=None):
    file,target=FILES[name]; items=[]; rejected=[]
    directory=Path(data_dir) if data_dir is not None else Path(__file__).parent/'data'
    with (directory/file).open(encoding='utf-8-sig',newline='') as stream:
        for rowid,row in enumerate(csv.DictReader(stream)):
            try:
                smiles=row['smiles']; data=graph(smiles,row[target]); data.rowid=rowid
                items.append((smiles,data))
            except Exception as e: rejected.append(dict(rowid=rowid,error=str(e)))
            if limit is not None and len(items)>=limit: break
    return items,rejected

def split(items,kind='scaffold',seed=0):
    n=len(items)
    if kind=='random':
        ids=np.random.default_rng(seed).permutation(n).tolist(); return ids[:int(.8*n)],ids[int(.8*n):int(.9*n)],ids[int(.9*n):]
    if kind!='scaffold': raise ValueError('split must be scaffold or random')
    groups={}
    for i,(smiles,_) in enumerate(items): groups.setdefault(MurckoScaffoldSmiles(smiles=smiles,includeChirality=False),[]).append(i)
    ordered=sorted(groups.values(),key=lambda g:(len(g),g[0]),reverse=True)
    train=[];valid=[];test=[]
    for ids in ordered:
        if len(train)+len(ids)<=.8*n: train.extend(ids)
        elif len(train)+len(valid)+len(ids)<=.9*n: valid.extend(ids)
        else: test.extend(ids)
    return train,valid,test

def auc(labels,scores):
    # Pairwise ROC-AUC with 0.5 credit for ties, independent of sklearn.
    y=np.asarray(labels); s=np.asarray(scores); pos=s[y==1]; neg=s[y==0]
    if not len(pos) or not len(neg): return float('nan')
    # Sort negatives: avoids constructing a huge pairwise array for HIV.
    neg=np.sort(neg)
    return float((np.searchsorted(neg,pos,'left')+.5*(np.searchsorted(neg,pos,'right')-np.searchsorted(neg,pos,'left'))).sum()/(len(pos)*len(neg)))
