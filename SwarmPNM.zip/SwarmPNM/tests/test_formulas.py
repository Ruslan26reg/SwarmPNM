import math
import numpy as np
import pytest
import torch
from swarmpnmlab.optimizers import DiffPNM,YogiPNM,CFGD,GLFGD,SwarmPNM
from swarmpnmlab.adaswarm import AdaSwarmLoss


@pytest.mark.parametrize('dtype',[torch.float32,torch.float64])
@pytest.mark.parametrize('kind',['diffpnm','yogi_corrected','yogi_literal','cfgd','glfgd'])
def test_independent_multistep(kind,dtype):
    x=np.array([1.2,-.7]); p=torch.nn.Parameter(torch.tensor(x,dtype=dtype))
    lr=.003; wd=.02; b0=.6; b1=.7; b2=.8; eps=.05
    if kind=='diffpnm': opt=DiffPNM([p],lr=lr,beta0=b0,beta1=b1,beta2=b2,eps=eps,weight_decay=wd)
    elif kind.startswith('yogi'): opt=YogiPNM([p],lr=lr,beta0=b0,beta1=b1,beta2=b2,eps=eps,weight_decay=wd,interpretation='literal_2024' if kind.endswith('literal') else 'corrected')
    elif kind=='cfgd': opt=CFGD([p],lr=lr,order=.75,anchor=-3,weight_decay=wd)
    else: opt=GLFGD([p],lr=lr,order=.75,weight_decay=wd,seed=17)
    m=np.zeros(2); v=np.zeros(2); vmax=np.zeros(2); prevg=np.zeros(2); hist=[]
    rng=torch.Generator().manual_seed(17)
    for t,grad in enumerate([[.4,-.2],[-.6,.3],[0.,0.],[.1,-.8],[.9,.2]],1):
        raw=np.array(grad); p.grad=torch.tensor(raw,dtype=dtype)
        if kind.startswith('diff') or kind.startswith('yogi'):
            g=raw+wd*x; old=m.copy(); sign=np.sign(v-g*g)
            m=b1*b1*m+(1-b1*b1)*(sign*g if kind=='yogi_literal' else g)
            if kind=='diffpnm': v=b2*v+(1-b2)*g*g
            elif kind=='yogi_literal': v=b2*v+(1-b2)*sign*g*g
            else: v=v-(1-b2)*sign*g*g
            vmax=np.maximum(vmax,v)
            mh=((1+b0)*m-b0*old)/(1-b1**t)
            vh=vmax/(1-b2**t)
            f=1/(1+np.exp(-np.abs(g-prevg))) if kind=='diffpnm' else 1
            x=x-lr*f*mh/(np.sqrt(vh)+eps)/math.sqrt(1+2*b0*b0); prevg=g.copy()
        elif kind=='cfgd': x=np.maximum(-3,x-lr*(raw*(x+3)**.25/math.gamma(1.25)+wd*x))
        else:
            drop=int(torch.randint(10,(),generator=rng)); d=raw.copy(); w=1
            for j in range(1,11):
                w*=1-(.75+1)/(j+1)
                if j<=len(hist) and j-1!=drop: d+=w*hist[j-1]
            d+=wd*x; x-=lr*d; hist=[raw]+hist[:9]
        opt.step()
        np.testing.assert_allclose(p.detach().numpy(),x,rtol=2e-6 if dtype==torch.float32 else 1e-12,atol=1e-7 if dtype==torch.float32 else 1e-12)


@pytest.mark.parametrize('variant',['sqrt','inverse'])
@pytest.mark.parametrize('dtype',[torch.float32,torch.float64])
def test_swarmpnm_independent_sphere(variant,dtype):
    x=np.array([1.2,-.7]); p=torch.nn.Parameter(torch.tensor(x,dtype=dtype))
    opt=SwarmPNM([p],lr=.01,beta0=.6,beta1=.7,beta2=.8,c1=.25,c2=.4,delta=.02,eps=.05,variant=variant,bounds=[-2,2],seed=17)
    def closure():
        opt.zero_grad(); loss=p.square().sum(); loss.backward(); return loss
    m=np.zeros(2); v=np.zeros(2); vmax=np.zeros(2); vel=np.zeros(2); best=x.copy()
    rng=torch.Generator().manual_seed(17)
    for t in range(1,9):
        if np.dot(x,x)<np.dot(best,best): best=x.copy()
        r=torch.rand(2,generator=rng,dtype=torch.float64).numpy(); g=2*x
        old=m.copy(); m=.49*m+.51*g; mh=(1.6*m-.6*old)/(1-.7**(2*t))
        v=.8*v+.2*g*g; vmax=np.maximum(vmax,v); V=vmax+.02/t
        vel=vel+(.25*r[0]+.4*r[1])*(best-x)
        denom=np.sqrt(V)+.05 if variant=='sqrt' else V
        x=np.clip(x+vel-.01*mh/denom/math.sqrt(1.6**2+.6**2),-2,2)
        if np.dot(x,x)<np.dot(best,best): best=x.copy()
        opt.step(closure)
        np.testing.assert_allclose(p.detach().numpy(),x,rtol=2e-6 if dtype==torch.float32 else 1e-12,atol=1e-7 if dtype==torch.float32 else 1e-12)


def test_caputo_first_term_matches_integral_for_affine_objective():
    # For affine f, f' is constant and the one-term formula is exact.
    order=.4; x=.7; c=-2; slope=3
    # Integral of (x-t)^(-a) f'(t) / Gamma(1-a).
    integral=slope*(x-c)**(1-order)/((1-order)*math.gamma(1-order))
    p=torch.nn.Parameter(torch.tensor([x],dtype=torch.float64)); p.grad=torch.tensor([slope],dtype=p.dtype)
    CFGD([p],lr=.01,order=order,anchor=c).step()
    assert p.item()==pytest.approx(x-.01*integral,abs=1e-14)


def test_adaswarm_independent_search_and_chain_rule():
    # Independent NumPy EMPSO with identical raw random draws (no call to loss implementation).
    target=np.array([[.3],[-.4]]); size=4; iters=3; rng=torch.Generator().manual_seed(19)
    pos=target+(torch.rand((size,2,1),generator=rng,dtype=torch.float64).numpy()-.5)*2
    v=np.zeros_like(pos); mom=v.copy(); personal=pos.copy()
    values=((pos-target)**2).mean(axis=(1,2)); best=personal[values.argmin()].copy()
    for _ in range(iters):
        r=torch.rand((size,2),generator=rng,dtype=torch.float64).numpy()
        cog=(.9*r[:,0])[:,None,None]; soc=(.8*r[:,1])[:,None,None]
        mom=.1*mom+.9*v; v=mom+cog*(personal-pos)+soc*(best-pos); pos+=v
        cand=((pos-target)**2).mean(axis=(1,2)); improve=cand<values
        personal[improve]=pos[improve]; values[improve]=cand[improve]; best=personal[values.argmin()].copy()
        cr=(cog+soc).mean()
    w=torch.nn.Parameter(torch.tensor(1.2,dtype=torch.float64)); inputs=torch.tensor([[.8],[-.2]],dtype=w.dtype)
    output=inputs*w; y=torch.tensor(target,dtype=w.dtype)
    loss=AdaSwarmLoss(swarm_size=size,iterations=iters,seed=19)
    (3*loss(output,y,center=y)).backward()
    reference_grad=((inputs.detach().numpy()*1.2-best)*cr/.1*inputs.detach().numpy()).sum()*3
    assert w.grad.item()==pytest.approx(reference_grad,abs=1e-12)
    np.testing.assert_allclose(loss.last_best.numpy(),best,atol=1e-13)


def test_adamw_independent_reference():
    x=np.array([.7,-.3]);m=np.zeros(2);v=np.zeros(2)
    p=torch.nn.Parameter(torch.tensor(x,dtype=torch.float64))
    opt=torch.optim.AdamW([p],lr=.01,betas=(.7,.8),eps=.02,weight_decay=.03)
    for t,raw in enumerate([[.4,-.2],[-.5,.1],[0,0],[.2,-.8]],1):
        g=np.array(raw);m=.7*m+.3*g;v=.8*v+.2*g*g
        x=x*(1-.01*.03)-.01*(m/(1-.7**t))/(np.sqrt(v/(1-.8**t))+.02)
        p.grad=torch.tensor(g,dtype=p.dtype);opt.step()
        np.testing.assert_allclose(p.detach().numpy(),x,atol=1e-13)


def test_adaswarm_vectorization_preserves_random_path():
    y=torch.tensor([[.3],[-.4]],dtype=torch.float64);p=torch.nn.Parameter(torch.ones_like(y))
    a=AdaSwarmLoss(seed=17,iterations=4);b=AdaSwarmLoss(seed=17,iterations=4)
    a(p,y,center=y);b(p,y,center=y,fitness_fn=lambda z:(z-y).square().mean((1,2)))
    torch.testing.assert_close(a.last_best,b.last_best,rtol=0,atol=0)
    torch.testing.assert_close(a.last_gradient,b.last_gradient,rtol=0,atol=0)
