import math
import pytest
import torch
from swarmpnmlab.benchmarks import objective,PAPER_FUNCTIONS,STARTS


@pytest.mark.parametrize('name',PAPER_FUNCTIONS)
def test_manuscript_functions_are_vectorized_with_finite_autograd(name):
    point=torch.tensor(STARTS[name],dtype=torch.float64,requires_grad=True)
    loss=objective(name,point);loss.backward()
    assert torch.isfinite(loss) and torch.isfinite(point.grad).all()
    batch=torch.stack([point.detach(),point.detach()*.7])
    torch.testing.assert_close(objective(name,batch),torch.stack([objective(name,p) for p in batch]))


@pytest.mark.parametrize('name,point,value',[
    ('rastrigin',[0,0],0),('rosenbrock',[1,1],0),('ackley',[0,0],0),
    ('levy',[1,1],0),('schwefel_220',[0,0],0),('alpine',[0,0],0),
    ('pinter',[0,0],0),('salomon',[0,0],0),('schaffer_n2',[0,0],0),
    ('weierstrass',[0,0],0),('holder_table',[8.05502,9.66459],-19.2085),
    ('carrom',[9.64616,9.64616],-24.1568),('trefethen',[-.024403,.210612],-3.30687)])
def test_known_reference_values(name,point,value):
    assert float(objective(name,torch.tensor(point,dtype=torch.float64)))==pytest.approx(value,abs=6e-5)


def test_printed_easom_and_plateau_are_not_silently_changed_to_have_minimum_zero():
    origin=torch.zeros(2,dtype=torch.float64)
    corner=torch.tensor([10.,10.],dtype=torch.float64)
    assert objective('modified_easom',corner)<objective('modified_easom',origin)
    x=torch.tensor([-4.,4.],dtype=torch.float64,requires_grad=True)
    objective('plateau',x).backward()
    assert torch.equal(x.grad,torch.zeros_like(x))
    assert objective('plateau',-corner)==-20


def test_pinter_cyclic_definition_independent_scalar_calculation():
    values=[.37,-.52];expected=0.
    for i,x in enumerate(values,1):
        neighbor=values[2-i]
        A=neighbor*math.sin(x)+math.sin(neighbor)
        B=neighbor**2-2*x+3*neighbor-math.cos(x)+1
        expected+=i*x*x+20*i*math.sin(A)**2+i*math.log10(1+i*B*B)
    assert float(objective('pinter',torch.tensor(values,dtype=torch.float64)))==pytest.approx(expected)
