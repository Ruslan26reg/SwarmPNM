import math
import pytest
pytest.importorskip('rdkit')
pytest.importorskip('torch_geometric')
from molclr.data_utils import auc,load_dataset,graph

def test_auc_ties_and_missing_class():
    assert auc([0,1],[.2,.8])==1
    assert auc([0,1],[.8,.2])==0
    assert auc([0,1],[.2,.2])==.5
    assert math.isnan(auc([1,1],[.2,.8]))

def test_first_csv_row_preserved_and_graph_empty_edges(tmp_path):
    (tmp_path/'BBBP.csv').write_text('smiles,p_np\nCCO,1\nCCN,0\n',encoding='utf-8')
    rows,rejected=load_dataset('BBBP',limit=1,data_dir=tmp_path)
    assert rows[0][1].rowid==0
    assert rows[0][1].y.item()==1
    g=graph('[He]',0)
    assert g.edge_index.shape==(2,0)
    assert g.edge_attr.shape==(0,2)
