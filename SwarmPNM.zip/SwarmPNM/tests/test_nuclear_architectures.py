import io
import pytest
import torch
from nuclear.architectures import make_architecture
from swarmpnmlab.registry import make_method
from swarmpnmlab.training import RepeatableClosure


def test_rbf_checkpoint_retains_training_basis_for_new_inputs():
    spec = dict(kind='rbf', centers=8, width_in_spacings=1, output_gain=5)
    train_x = torch.tensor([[-1.2], [0.1], [1.8]])
    train_y = torch.tensor([[0.], [1.1], [1.5]])
    model = make_architecture(spec, train_x, train_y)
    with torch.no_grad():
        model.head.weight.copy_(torch.linspace(-.2, .5, 8).reshape(1, -1))
    new_x = torch.tensor([[-1.0], [.8], [2.]])
    expected = model(new_x).detach()
    serialized = io.BytesIO()
    torch.save(model.state_dict(), serialized)
    serialized.seek(0)
    restored = make_architecture(spec, torch.tensor([[-5.], [5.]]), train_y)
    restored.load_state_dict(torch.load(serialized, weights_only=True))
    torch.testing.assert_close(restored(new_x), expected)
    torch.testing.assert_close(restored.centers, model.centers)
    assert not restored.centers.requires_grad


@pytest.mark.parametrize('gain', [1, 5, 10])
def test_output_gain_keeps_initial_prediction_in_raw_target_units(gain):
    x = torch.tensor([[-1.], [0.], [1.]])
    y = torch.tensor([[.1], [1.2], [1.7]])
    model = make_architecture(dict(kind='rbf', centers=8, width_in_spacings=1, output_gain=gain), x, y)
    torch.testing.assert_close(model(x), y.mean().expand(3, 1))


def test_swarmpnm_actually_trains_rbf_head():
    x = torch.linspace(-1, 1, 20).reshape(-1, 1)
    y = 1 + .3 * torch.sin(2 * x)
    model = make_architecture(dict(kind='rbf', centers=8, width_in_spacings=1), x, y)
    before = torch.nn.functional.mse_loss(model(x), y).item()
    initial = model.head.weight.detach().clone()
    opt, _ = make_method('swarmpnm_sqrt', model.parameters(), dict(lr=.0005, seed=0))
    for _ in range(6):
        model.train()
        closure = RepeatableClosure(model, opt, lambda: torch.nn.functional.mse_loss(model(x), y))
        try:
            opt.step(closure)
        finally:
            closure.commit()
    assert not torch.equal(model.head.weight, initial)
    assert torch.nn.functional.mse_loss(model(x), y).item() < before


def test_bad_spec_fails_instead_of_silently_truncating_layers():
    with pytest.raises(ValueError, match='Invalid MLP'):
        make_architecture(dict(kind='mlp', hidden=[32, 64], activations=['Tanh'], dropout=[0, 0]),
                          torch.tensor([[0.], [1.]]), torch.ones(2, 1))
    with pytest.raises(ValueError, match='distinct training energies'):
        make_architecture(dict(kind='rbf', centers=8, width_in_spacings=1), torch.ones(3, 1), torch.ones(3, 1))


def test_ensemble_training_and_state_restore_reach_all_members():
    member = dict(kind='mlp', hidden=[8, 8], activations=['ReLU', 'ReLU'], dropout=[0, 0])
    spec = dict(kind='ensemble', members=[member, member, member])
    x = torch.linspace(-1, 1, 20).reshape(-1, 1)
    y = x.square() + .1
    model = make_architecture(spec, x, y)
    opt, _ = make_method('swarmpnm_sqrt', model.parameters(), dict(lr=.0005, seed=0))
    closure = RepeatableClosure(model, opt, lambda: torch.nn.functional.mse_loss(model(x), y))
    try:
        opt.step(closure)
    finally:
        closure.commit()
    assert all(any(p in opt.state and 'velocity' in opt.state[p] for p in net.parameters()) for net in model.members)
    restored = make_architecture(spec, x, y)
    restored.load_state_dict(model.state_dict())
    torch.testing.assert_close(restored(x), model(x))
