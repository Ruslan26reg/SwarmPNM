import json
from pathlib import Path
import pytest
import torch
from swarmpnmlab.benchmarks import PAPER_FUNCTIONS
from swarmpnmlab.registry import METHODS,make_method
from swarmpnmlab.training import RepeatableClosure
from nuclear.architectures import make_architecture
from scripts.predict_nuclear import predict_energies

ROOT=Path(__file__).resolve().parents[1]
SPECS=json.loads((ROOT/'configs/architectures.json').read_text())


def test_catalog_matches_actual_registry_and_architecture_specifications():
    catalog=json.loads((ROOT/'configs/tasks.json').read_text())
    assert catalog['methods']==list(METHODS)
    assert catalog['benchmark_functions']==list(PAPER_FUNCTIONS)
    assert catalog['nuclear']['architecture_names']==list(SPECS)
    assert len(SPECS)==22


@pytest.mark.parametrize('name',list(SPECS))
def test_every_declared_nuclear_architecture_trains_and_restores(name,tmp_path):
    torch.set_num_threads(1);torch.manual_seed(0)
    x=torch.linspace(-1,1,24).reshape(-1,1);y=(.4*x+.3*x.square()+1)
    model=make_architecture(SPECS[name],x,y)
    opt,_=make_method('swarmpnm_sqrt',model.parameters(),dict(lr=5e-4,seed=0,bounds=[-10,10]))
    before=[p.detach().clone() for p in model.parameters()]
    closure=RepeatableClosure(model,opt,lambda:(model(x)-y).square().mean())
    try:opt.step(closure)
    finally:closure.commit()
    assert any(not torch.equal(a,b) for a,b in zip(before,model.parameters()))
    model.eval()
    state=dict(model=model.state_dict(),spec=SPECS[name],split=dict(input_mean_mev=10.,input_std_mev=3.),
               nuclear_context=dict(za=54135,isotope='135Xe',mt=16,energy_domain_mev=[7.,13.]))
    path=tmp_path/'model.pt';torch.save(state,path)
    expected=model(torch.tensor([[-1.],[0.],[1.]])).flatten().detach()
    actual=predict_energies(path,[7.,10.,13.],expected_za=54135,expected_mt=16)
    torch.testing.assert_close(torch.tensor(actual),expected)
