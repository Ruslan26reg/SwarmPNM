import hashlib
import json
import struct
import zipfile
from scripts import fetch_assets as fetcher
import pytest


def test_local_import_hash_validation_and_existing_file_preservation(tmp_path):
    data=b'exact data';archive=tmp_path/'source.zip'
    with zipfile.ZipFile(archive,'w') as stream:stream.writestr('folder/BBBP.csv',data)
    asset=dict(target='molclr/data/BBBP.csv',url='https://example.invalid/file',bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
    root=tmp_path/'repo';path=fetcher.fetch('bbbp',asset,root,archive)
    assert path.read_bytes()==data
    assert json.loads(path.with_name('BBBP_acquisition.json').read_text())['sha256']==asset['sha256']
    assert fetcher.fetch('bbbp',asset,root,archive)==path
    path.write_bytes(b'preserve me')
    with pytest.raises(ValueError,match='Existing'):fetcher.fetch('bbbp',asset,root,archive)
    assert path.read_bytes()==b'preserve me'


def test_bad_digest_writes_no_asset(tmp_path):
    source=tmp_path/'source';source.mkdir();(source/'a.csv').write_bytes(b'bad')
    asset=dict(target='data/a.csv',url='x',bytes=3,sha256='0'*64)
    with pytest.raises(ValueError,match='differs'):fetcher.fetch('a',asset,tmp_path/'repo',source)
    assert not (tmp_path/'repo/data/a.csv').exists()


def test_asset_cannot_escape_root(tmp_path):
    with pytest.raises(ValueError,match='escapes'):
        fetcher.fetch('x',dict(target='../escape',sha256='0'*64),tmp_path/'repo')


def test_zip_range_member_bytes_and_crc(monkeypatch,tmp_path):
    path=tmp_path/'archive.zip';payload=b'cross section\n'*100
    with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED) as stream:
        stream.writestr('unrelated.bin',b'x'*20);stream.writestr('lib/Fe56.endf',payload)
    raw=path.read_bytes();calls=[]
    def request(url,start=None,end=None,suffix=None):
        calls.append((start,end,suffix))
        return raw[-suffix:] if suffix else raw[start:end+1]
    monkeypatch.setattr(fetcher,'request_bytes',request)
    assert fetcher.zip_member('fake','lib/Fe56.endf')==payload
    assert len(calls)==4


def test_fixture_hashes_match_recorded_provenance():
    from pathlib import Path
    root=Path(__file__).parent/'fixtures'
    for record in json.loads((root/'provenance.json').read_text()):
        assert hashlib.sha256((root/record['file']).read_bytes()).hexdigest()==record['fixture_sha256']


def test_bace_header_transform_requires_both_exact_hashes(tmp_path,monkeypatch):
    raw=b'mol,Class\nCCO,1\n';expected=b'smiles,Class\nCCO,1\n'
    asset=dict(target='data/bace.csv',url='fake',bytes=len(expected),sha256=hashlib.sha256(expected).hexdigest(),
               transform='bace_header_mol_to_smiles',source_sha256=hashlib.sha256(raw).hexdigest())
    monkeypatch.setattr(fetcher,'request_bytes',lambda *args:raw)
    path=fetcher.fetch('bace',asset,tmp_path/'good')
    assert path.read_bytes()==expected
    monkeypatch.setattr(fetcher,'request_bytes',lambda *args:b'mol,Class\nCCO,0\n')
    with pytest.raises(ValueError,match='raw file hash'):fetcher.fetch('bace',asset,tmp_path/'bad')
    assert not (tmp_path/'bad/data/bace.csv').exists()


@pytest.mark.parametrize('status,content_range',[(200,''),(206,'bytes 10-19/100'),(206,'missing')])
def test_http_range_errors_rejected_before_reading_large_body(status,content_range,monkeypatch):
    class Response:
        def __init__(self):self.status=status;self.headers={'Content-Range':content_range}
        def __enter__(self):return self
        def __exit__(self,*args):pass
        def read(self,size):raise AssertionError('Must reject header before reading body')
    monkeypatch.setattr(fetcher.urllib.request,'urlopen',lambda *args,**kwargs:Response())
    with pytest.raises(ValueError):fetcher.request_bytes('https://example.invalid',0,9)


def test_retry_is_bounded_and_recovers_transient_network_error(monkeypatch):
    calls=[]
    def request(*args):
        calls.append(1)
        if len(calls)<3:raise fetcher.urllib.error.URLError('temporary')
        return b'ok'
    monkeypatch.setattr(fetcher,'_request_bytes',request)
    monkeypatch.setattr(fetcher.time,'sleep',lambda duration:None)
    assert fetcher.request_bytes('fake')==b'ok' and len(calls)==3
