import pytest
import torch
from nuclear.architectures import make_architecture
from scripts.predict_nuclear import predict_energies
from swarmpnmlab.optimizers import SwarmPNM


@pytest.fixture
def checkpoint(tmp_path):
    spec = dict(kind='mlp', hidden=[8,8], activations=['Tanh','Tanh'], dropout=[0,0])
    model = make_architecture(spec, torch.tensor([[0.],[1.]]), torch.zeros(2,1))
    path = tmp_path/'weights.pt'
    torch.save(dict(model=model.state_dict(), spec=spec,
        split=dict(input_mean_mev=13., input_std_mev=4.),
        nuclear_context=dict(za=54135, isotope='135Xe', mt=16, energy_domain_mev=[6.50539,20.])), path)
    return path


@pytest.mark.parametrize('energies', [[0.],[-1.],[float('nan')],[float('inf')],[]])
def test_invalid_neutron_energy_rejected(checkpoint, energies):
    with pytest.raises(ValueError,match='finite positive'):
        predict_energies(checkpoint, energies)


def test_wrong_isotope_and_reaction_rejected(checkpoint):
    with pytest.raises(ValueError,match='isotope'):
        predict_energies(checkpoint,[12.],expected_za=26056)
    with pytest.raises(ValueError,match='reaction'):
        predict_energies(checkpoint,[12.],expected_mt=102)


def test_extrapolation_requires_explicit_opt_in(checkpoint):
    with pytest.raises(ValueError,match='outside recorded data domain'):
        predict_energies(checkpoint,[25.])
    assert len(predict_energies(checkpoint,[25.],allow_extrapolation=True))==1


def test_loading_for_inference_preserves_rng_and_original_weights(checkpoint):
    state = torch.load(checkpoint,weights_only=True)
    rng = torch.get_rng_state().clone()
    actual = predict_energies(checkpoint,[7.,12.,20.],expected_za=54135,expected_mt=16)
    assert torch.equal(torch.get_rng_state(),rng)
    with torch.random.fork_rng(devices=[]):
        model = make_architecture(state['spec'],torch.tensor([[0.],[1.]]),torch.zeros(2,1))
    model.load_state_dict(state['model']);model.eval()
    x = ((torch.tensor([7.,12.,20.],dtype=torch.float64)-13.)/4.).float().reshape(-1,1)
    torch.testing.assert_close(torch.tensor(actual),model(x).flatten())


@pytest.mark.parametrize('config', [dict(lr=float('nan')),dict(c1=float('inf')),dict(delta=float('nan')),
                                  dict(eps=float('inf')),dict(bounds=[float('-inf'),10.]),dict(lambda_manuscript=float('nan'))])
def test_nonfinite_swarmpnm_configuration_is_rejected(config):
    with pytest.raises(ValueError,match='finite'):
        SwarmPNM([torch.nn.Parameter(torch.ones(1))],**config)
