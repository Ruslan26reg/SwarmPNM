from pathlib import Path
import pytest
from nuclear.endf import number,read_cross_section
from nuclear.metrics import regression_metrics

ROOT=Path(__file__).resolve().parents[1]
FIXTURES=Path(__file__).resolve().parent/'fixtures'

@pytest.mark.parametrize('field,expected', [(' 1.250000+3',1250.),('-6.457100+6',-6457100.),(' 5.198380-1',.519838),(' 1.2E-3',.0012),('           ',0.)])
def test_endf_numeric_formats(field,expected):assert number(field)==pytest.approx(expected)

def test_archived_official_tab1_known_values():
    table=read_cross_section(FIXTURES/'endf8_xe135.endf')
    assert table['native_points']==24
    assert table['interpolation']==[(24,2)]
    assert table['energy_ev'][0]==6505390.
    assert table['sigma_barn'][0]==0.
    assert table['energy_ev'][-1]==20000000.
    assert table['sigma_barn'][-1]==pytest.approx(.663479)
    assert table['sigma_barn'][table['energy_ev'].index(14000000.)]==pytest.approx(1.38446)

def test_wrong_isotope_and_missing_reaction_rejected():
    path=FIXTURES/'endf8_xe135.endf'
    with pytest.raises(ValueError,match='Wrong isotope'):read_cross_section(path,expected_za=54134)
    with pytest.raises(ValueError,match='complete'):read_cross_section(path,mt=999)

def test_truncated_tab1_rejected(tmp_path):
    lines=(FIXTURES/'endf8_xe135.endf').read_text().splitlines()
    lines=[line for line in lines if len(line)>=75 and line[70:72].strip()=='3' and line[72:75].strip()=='16']
    path=tmp_path/'truncated.endf';path.write_text('\n'.join(lines[:-1]))
    with pytest.raises(ValueError,match='Truncated'):read_cross_section(path)

def test_metrics_in_raw_target_units():
    result=regression_metrics([1.,2.,3.,4.],[2.,2.,2.,4.])
    assert result['rmse']==pytest.approx(2**-.5)
    assert result['mae']==.5
    assert result['r2']==pytest.approx(.6)

def test_constant_target_r2_undefined():
    assert regression_metrics([1.,1.],[1.,1.])['r2'] is None


@pytest.mark.parametrize('name,za,native_points',[('endf8_fe56.endf',26056,42),('endf8_u235.endf',92235,39)])
def test_other_official_isotopes_require_the_correct_explicit_za(name,za,native_points):
    path=FIXTURES/name
    table=read_cross_section(path,expected_za=za)
    assert table['za']==za and table['native_points']==native_points
    with pytest.raises(ValueError,match='Wrong isotope'):
        read_cross_section(path)
