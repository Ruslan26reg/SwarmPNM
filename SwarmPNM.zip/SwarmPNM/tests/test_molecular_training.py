import copy
import json
from pathlib import Path
import pytest
pytest.importorskip('rdkit')
pytest.importorskip('torch_geometric')
import torch
from torch_geometric.data import Batch
from swarmpnmlab.registry import METHODS, make_method
from molclr.data_utils import graph
from scripts.run_molclr import model_for,update
from scripts import reproduce_swarmpnm as runner

ROOT=Path(__file__).resolve().parents[1]


@pytest.mark.parametrize('method',METHODS)
@pytest.mark.parametrize('backbone',['gin','gcn'])
def test_both_backbones_train_with_every_method(method,backbone):
    torch.set_num_threads(1);torch.manual_seed(4)
    cfg=json.loads((ROOT/f'configs/bbbp_{backbone}.json').read_text())
    model=model_for(cfg,small=True);model.train()
    batch=Batch.from_data_list([graph('CCO',0),graph('CCN',1)])
    before=[p.detach().clone() for p in model.parameters()]
    opt,criterion=make_method(method,model.parameters(),cfg['methods'][method])
    loss=update(model,batch,opt,criterion)
    assert torch.isfinite(loss)
    assert all(torch.isfinite(p).all() for p in model.parameters())
    assert any(not torch.equal(a,b) for a,b in zip(before,model.parameters()))


@pytest.mark.parametrize('method',['swarmpnm_sqrt','adamw','adaswarm'])
def test_full_training_resume_matches_uninterrupted_weights_and_rng(method,tmp_path,monkeypatch):
    cfg=json.loads((ROOT/'configs/bbbp_gcn.json').read_text())
    cfg['batch_size']=4
    cfg['model'].update(num_layer=2,emb_dim=8,feat_dim=8,drop_ratio=.2)
    cfg['methods']['adaswarm']['swarm'].update(iterations=2,swarm_size=3)
    path=tmp_path/'config.json';path.write_text(json.dumps(cfg))
    data=tmp_path/'molclr/data';data.mkdir(parents=True)
    (data/'BBBP.csv').write_text('smiles,p_np\nCCO,0\nCCN,1\n')
    items=[('CCO' if i%2==0 else 'CCN',graph('CCO' if i%2==0 else 'CCN',i%2)) for i in range(12)]
    monkeypatch.setattr(runner,'ROOT',tmp_path)
    monkeypatch.setattr(runner,'load_dataset',lambda name:(items,[]))
    monkeypatch.setattr(runner,'split',lambda *args:([0,1,2,3,4,5],[6,7],[8,9,10,11]))
    runner.run('BBBP','gcn',method,0,3,1,'continuous',pretrained=False,config_path=path)
    runner.run('BBBP','gcn',method,0,1,1,'resumed',pretrained=False,config_path=path)
    runner.run('BBBP','gcn',method,0,3,1,'resumed',resume=True,pretrained=False,config_path=path)
    a=torch.load(tmp_path/'results/reproduction/continuous/last_state.pt',weights_only=False)
    b=torch.load(tmp_path/'results/reproduction/resumed/last_state.pt',weights_only=False)
    def equal(x,y):
        if isinstance(x,torch.Tensor):assert torch.equal(x,y)
        elif isinstance(x,dict):
            assert x.keys()==y.keys()
            for k in x:equal(x[k],y[k])
        elif isinstance(x,(list,tuple)):
            assert len(x)==len(y)
            for u,v in zip(x,y):equal(u,v)
        else:assert x==y
    for key in ['model','optimizer','criterion','torch_rng','loader_rng']:equal(a[key],b[key])
