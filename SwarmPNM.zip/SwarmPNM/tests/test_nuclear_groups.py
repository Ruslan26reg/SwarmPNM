import numpy as np
from scripts.check_nuclear_transfer import energy_group_split


def test_duplicate_and_nearby_library_nodes_are_never_split_across_holdout():
    energy=np.repeat(np.arange(7e6,20e6,2e5),2)
    energy[1::2]+=100
    for seed in range(3):
        train,test,groups=energy_group_split(energy,seed,25000)
        assert not set(train)&set(test)
        assert set(train)|set(test)==set(range(len(energy)))
        assert not set(groups[train])&set(groups[test])
        assert all((i in train)==(i+1 in train) for i in range(0,len(energy),2))
