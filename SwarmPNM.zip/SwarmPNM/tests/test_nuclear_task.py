import json
from pathlib import Path
import numpy as np
import pytest
from swarmpnmlab.registry import METHODS
from scripts.train_nuclear import run
from scripts.predict_nuclear import predict_energies

ROOT=Path(__file__).resolve().parents[1]
SPECS=[dict(kind='mlp',hidden=[8],activations=['Tanh'],dropout=[0]),
       dict(kind='rbf',centers=6,width_in_spacings=1,output_gain=1),
       dict(kind='ensemble',members=[dict(kind='mlp',hidden=[8],activations=['ReLU'],dropout=[0])]*2)]


@pytest.mark.parametrize('method',METHODS)
@pytest.mark.parametrize('spec',SPECS,ids=['mlp','rbf','ensemble'])
def test_all_method_architecture_combinations_train_and_restore(method,spec,tmp_path):
    cfg=json.loads((ROOT/'configs/checks.json').read_text())['methods'][method]
    source=ROOT/'tests/fixtures/endf8_xe135.endf'
    directory=tmp_path/'trial'
    result=run([source],54135,'135Xe',16,spec,method,cfg,2,0,directory)
    assert result['epochs']==2 and np.isfinite(result['rmse'])
    protocol=json.loads((directory/'protocol.json').read_text());split=protocol['split']
    assert not set(split['train_ids'])&set(split['test_ids'])
    groups=split['energy_groups']
    assert not {groups[i] for i in split['train_ids']}&{groups[i] for i in split['test_ids']}
    import csv
    rows=list(csv.DictReader((directory/'test_predictions.csv').open()))
    pred=predict_energies(directory/'model.pt',[float(r['energy_ev'])/1e6 for r in rows],expected_za=54135,expected_mt=16)
    np.testing.assert_allclose(pred,[float(r['predicted_sigma_barn']) for r in rows],rtol=1e-6,atol=1e-6)


def test_training_does_not_replace_existing_run(tmp_path):
    with pytest.raises(ValueError,match='Preserve'):
        run([],54135,'135Xe',16,SPECS[0],'adamw',{},1,0,tmp_path)


def test_requested_seed_propagates_when_manuscript_coefficients_omit_seed(tmp_path):
    cfg=json.loads((ROOT/'configs/nuclear_xe135.json').read_text())['methods']['swarmpnm_sqrt']
    assert 'seed' not in cfg
    directory=tmp_path/'seed2'
    run([ROOT/'tests/fixtures/endf8_xe135.endf'],54135,'135Xe',16,SPECS[0],'swarmpnm_sqrt',cfg,1,2,directory)
    assert json.loads((directory/'protocol.json').read_text())['optimizer']['seed']==2
