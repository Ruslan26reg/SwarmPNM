import copy
import json
from pathlib import Path
import pytest
import torch
from swarmpnmlab.registry import METHODS,make_method
from swarmpnmlab.optimizers import SwarmPNM,CFGD,GLFGD

CONFIG=json.loads((Path(__file__).parents[1]/'configs/checks.json').read_text())['methods']


def finite(tree):
    if isinstance(tree,torch.Tensor): assert torch.isfinite(tree).all()
    elif isinstance(tree,dict):
        for x in tree.values(): finite(x)
    elif isinstance(tree,(list,tuple)):
        for x in tree: finite(x)


@pytest.mark.parametrize('name',METHODS)
@pytest.mark.parametrize('dtype',[torch.float32,torch.float64])
def test_groups_missing_zero_and_finite(name,dtype):
    a=torch.nn.Parameter(torch.tensor([.8,-.3],dtype=dtype)); b=torch.nn.Parameter(torch.tensor([[.2]],dtype=dtype)); inactive=torch.nn.Parameter(torch.tensor([.7],dtype=dtype))
    opt,criterion=make_method(name,[{'params':[a,inactive]},{'params':[b],'lr':.002}],CONFIG[name])
    def closure():
        opt.zero_grad(); loss=a.square().sum()+b.square().sum(); loss.backward(); return loss
    old=a.detach().clone()
    for i in range(4):
        if isinstance(opt,SwarmPNM): opt.step(closure)
        else:
            closure()
            if i==1: b.grad.zero_()
            opt.step()
        finite(opt.state_dict()); finite([a,b,inactive])
    assert not torch.equal(a,old)
    assert inactive.item()==pytest.approx(.7)
    assert opt.param_groups[1]['lr']==.002
    assert 't' not in opt.state.get(inactive,{})


@pytest.mark.parametrize('name',METHODS)
def test_state_resume_including_rng(name,tmp_path):
    a=torch.nn.Parameter(torch.tensor([.8,-.3],dtype=torch.float64))
    opt,crit=make_method(name,[a],CONFIG[name])
    def advance(p,o,c):
        def closure():
            o.zero_grad(); loss=p.square().sum(); loss.backward(); return loss
        if isinstance(o,SwarmPNM): o.step(closure)
        else:
            o.zero_grad()
            loss=c(p,loss_fn=lambda x:x.square().sum()) if c is not None else p.square().sum()
            loss.backward(); o.step()
    for _ in range(3): advance(a,opt,crit)
    b=torch.nn.Parameter(a.detach().clone()); opt2,crit2=make_method(name,[b],CONFIG[name])
    path=tmp_path/'state.pt'
    torch.save(dict(optimizer=opt.state_dict(),criterion=crit.state_dict() if crit else None),path)
    restored=torch.load(path,weights_only=False)
    opt2.load_state_dict(restored['optimizer'])
    if crit: crit2.load_state_dict(restored['criterion'])
    for _ in range(5): advance(a,opt,crit); advance(b,opt2,crit2)
    torch.testing.assert_close(a,b,rtol=0,atol=0)
    finite(opt2.state_dict())


@pytest.mark.parametrize('name',['swarmpnm_sqrt','swarmpnm_inverse','diffpnm','yogipnm','cfgd','glfgd'])
def test_clear_unsupported_dtype_and_sparse(name):
    p=torch.nn.Parameter(torch.ones(2,dtype=torch.float16))
    with pytest.raises(ValueError,match='float32/float64'): make_method(name,[p],CONFIG[name])
    p=torch.nn.Parameter(torch.ones(2)); opt,_=make_method(name,[p],CONFIG[name])
    p.grad=torch.sparse_coo_tensor(torch.tensor([[0]]),torch.tensor([1.]),[2])
    if isinstance(opt,SwarmPNM):
        with pytest.raises(ValueError,match='Sparse'): opt.step(lambda:torch.tensor(1.))
    else:
        with pytest.raises(ValueError,match='Sparse'): opt.step()


def test_clear_domain_and_closure_errors():
    p=torch.nn.Parameter(torch.tensor([-2.]))
    with pytest.raises(ValueError,match='bounds'): SwarmPNM([p],variant='inverse')
    with pytest.raises(ValueError,match='closure'): SwarmPNM([p]).step()
    p.grad=torch.ones_like(p)
    with pytest.raises(ValueError,match='anchor'): CFGD([p],anchor=-1).step()
    with pytest.raises(ValueError,match='memory'): GLFGD([p],memory=5)


def test_literal_yogipnm_direction_failure_is_visible():
    p=torch.nn.Parameter(torch.tensor([1.],dtype=torch.float64))
    c=dict(CONFIG['yogipnm']); c['interpretation']='literal_2024'; c['eps']=1e-8
    opt,_=make_method('yogipnm',[p],c); p.grad=torch.tensor([2.],dtype=p.dtype); opt.step()
    assert opt.state[p]['v'].item()<0
    assert p.item()>1 # printed update moves uphill; this is NOT a passed convergence test


def test_swarmpnm_zero_gradient_stays_finite():
    p=torch.nn.Parameter(torch.tensor([.4],dtype=torch.float64)); opt=SwarmPNM([p])
    def closure():
        opt.zero_grad();loss=(p*0).sum();loss.backward();return loss
    for _ in range(3):opt.step(closure)
    assert p.item()==.4;finite(opt.state_dict())
