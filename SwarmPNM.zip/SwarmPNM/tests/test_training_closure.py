import copy
import torch
from swarmpnmlab.training import RepeatableClosure
from swarmpnmlab.optimizers import SwarmPNM

def test_dropout_and_batchnorm_committed_once():
    torch.manual_seed(17)
    model=torch.nn.Sequential(torch.nn.Linear(3,8),torch.nn.BatchNorm1d(8),torch.nn.Dropout(.4),torch.nn.Linear(8,1)).double().train()
    control=copy.deepcopy(model);x=torch.randn(12,3,dtype=torch.float64)
    rng=torch.get_rng_state();control(x);expected_rng=torch.get_rng_state()
    expected_buffers={k:v.clone() for k,v in control.named_buffers()}
    torch.set_rng_state(rng)
    opt=SwarmPNM(model.parameters(),lr=0.)
    bridge=RepeatableClosure(model,opt,lambda:model(x).square().mean())
    opt.step(bridge);bridge.commit()
    for k,v in model.named_buffers():torch.testing.assert_close(v,expected_buffers[k],rtol=0,atol=0)
    assert torch.equal(torch.get_rng_state(),expected_rng)
    assert model[1].num_batches_tracked.item()==1

def test_objective_probes_use_same_mask_and_leave_gradients():
    model=torch.nn.Sequential(torch.nn.Linear(3,4),torch.nn.Dropout(.5),torch.nn.Linear(4,1)).double().train()
    x=torch.ones(6,3,dtype=torch.float64);opt=SwarmPNM(model.parameters())
    bridge=RepeatableClosure(model,opt,lambda:model(x).square().mean())
    first=bridge();grads=[p.grad.clone() for p in model.parameters()]
    for _ in range(2):
        torch.testing.assert_close(first.detach(),bridge.evaluate(),rtol=0,atol=0)
        for p,g in zip(model.parameters(),grads):torch.testing.assert_close(p.grad,g,rtol=0,atol=0)
    bridge.commit()
