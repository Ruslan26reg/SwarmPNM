# SwarmPNM

SwarmPNM is a single-trajectory adaptive optimizer that combines positive-negative
momentum with an attraction towards the best stored weights. The repository contains
the optimizer, the baseline optimizers and the scripts for the benchmark-function,
molecular (MolCLR GIN/GCN on BBBP, HIV, BACE) and nuclear cross-section experiments.

## Methods

| Key | Method |
|---|---|
| `swarmpnm_sqrt` | SwarmPNM, square-root denominator |
| `swarmpnm_inverse` | SwarmPNM, inverse denominator with box projection |
| `adamw` | AdamW (`torch.optim.AdamW`) |
| `adaswarm` | AdaSwarm |
| `diffpnm` | DiffPNM |
| `yogipnm` | YogiPNM |
| `cfgd` | Caputo fractional gradient descent |
| `glfgd` | Grünwald–Letnikov fractional gradient descent |

## Installation

Python 3.11 or 3.12, CPU.

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install torch==2.7.1 --index-url https://download.pytorch.org/whl/cpu
python -m pip install -e ".[test,molecular,plots]"
python -m pytest -q
```

## Usage

```bash
python scripts/run.py list
python scripts/run.py benchmarks --steps 500 --run-name paper_functions
python scripts/run.py checks --steps 10 --regression-steps 10

# datasets, evaluated nuclear data and pretrained encoders (downloaded, SHA256-checked)
python scripts/run.py fetch --group molecular
python scripts/run.py fetch --group xe135

python scripts/run.py molecular --dataset BBBP --backbone gcn --method swarmpnm_sqrt --epochs 100 --run-name bbbp_swarmpnm_seed0
python scripts/run.py nuclear --isotope xe135 --architecture ensemble_3_relu --method swarmpnm_sqrt --epochs 595 --run-name xe135_swarmpnm_seed0
```

Settings are in `configs/`; results are written to `results/`.

## License

MIT, see `LICENSE`. Third-party notices are in `third_party/`.
