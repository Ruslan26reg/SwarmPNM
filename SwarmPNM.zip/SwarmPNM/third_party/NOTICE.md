# Third-party notices

`molclr/models/gcn_finetune.py` and `molclr/models/ginet_finetune.py` are adapted from
MolCLR (<https://github.com/yuyangw/MolCLR>, commit `3d3bc1912be27b0c97435fd9134f4d4c73d4c5ab`),
MIT license: [MolCLR_LICENSE](MolCLR_LICENSE).

`swarmpnmlab/adaswarm.py` follows AdaSwarm (<https://github.com/AdaSwarm/AdaSwarm>,
commit `8633559ecc88e7545c685cffb1c2508988a09ad0`), MIT license: [AdaSwarm_LICENSE](AdaSwarm_LICENSE).

Datasets, evaluated nuclear-data libraries and pretrained weights are not included;
`scripts/fetch_assets.py` downloads them and checks their SHA256. `tests/fixtures/*.endf`
are small MF3/MT16 sections of the public ENDF/B-VIII.0 evaluations used in parser tests
(sources in `tests/fixtures/provenance.json`).
