# AdaSwarm reference attribution: third_party/AdaSwarm_LICENSE.
"""Output-space swarm + ordinary Adam, adapted from author architecture.

No swarm over neural weights. The generic scalar-objective bridge also permits
benchmark functions. Vectorised candidate search follows upstream SwarmLoss;
the legacy sum(c*r)/eta surrogate scale is available explicitly.
"""
import torch
from torch import nn


class _Bridge(torch.autograd.Function):
    @staticmethod
    def forward(ctx, output, value, estimated):
        ctx.save_for_backward(estimated)
        return value.clone()

    @staticmethod
    def backward(ctx, grad_output):
        return grad_output*ctx.saved_tensors[0],None,None


class AdaSwarmLoss(nn.Module):
    def __init__(self, swarm_size=10, iterations=40, span=1., inertia=.1,
                 c1=.9,c2=.8,eta=.1,scale='legacy',seed=0,bounds=None):
        super().__init__()
        if swarm_size<2 or iterations<1 or span<=0 or eta<=0 or scale not in ('legacy','modern'):
            raise ValueError('Invalid AdaSwarm settings')
        self.config=dict(swarm_size=swarm_size,iterations=iterations,span=span,
                         inertia=inertia,c1=c1,c2=c2,eta=eta,scale=scale,bounds=bounds)
        self.generator=torch.Generator().manual_seed(seed)
        self.last_best=None; self.last_gradient=None; self.evaluations=0

    def get_extra_state(self):
        return dict(config=self.config.copy(),rng=self.generator.get_state(),evaluations=self.evaluations)

    def set_extra_state(self,state):
        self.config=state['config'].copy(); self.generator.set_state(state['rng']); self.evaluations=state['evaluations']

    def forward(self, output, target=None, loss_fn=None, center=None, fitness_fn=None):
        if output.device.type!='cpu' or output.dtype not in (torch.float32,torch.float64):
            raise ValueError('AdaSwarm supports CPU float32/float64 only')
        if loss_fn is None: loss_fn=lambda z:(z-target).square().mean()
        cfg=self.config; n=cfg['swarm_size']; shape=(n,)+tuple(output.shape)
        center=output.detach() if center is None else center.detach()
        with torch.no_grad():
            positions=center+(torch.rand(shape,generator=self.generator,dtype=output.dtype)-.5)*2*cfg['span']
            if cfg['bounds'] is not None: positions.clamp_(*cfg['bounds'])
            velocity=torch.zeros_like(positions); momentum=torch.zeros_like(positions)
            def fitness(xs):
                self.evaluations+=n
                values=torch.stack([loss_fn(x).detach() for x in xs]) if fitness_fn is None else fitness_fn(xs).detach()
                if values.shape!=(n,): raise ValueError('Vectorized fitness must return shape (swarm_size,)')
                if not torch.isfinite(values).all(): raise FloatingPointError('Non-finite AdaSwarm fitness')
                return values
            personal=positions.clone(); values=fitness(positions)
            best=personal[int(values.argmin())].clone(); cr=0.
            for _ in range(cfg['iterations']):
                r=torch.rand((n,2),generator=self.generator,dtype=output.dtype)
                cognitive=(cfg['c1']*r[:,0]).reshape(n,*([1]*output.ndim))
                social=(cfg['c2']*r[:,1]).reshape(n,*([1]*output.ndim))
                momentum=cfg['inertia']*momentum+(1-cfg['inertia'])*velocity
                velocity=momentum+cognitive*(personal-positions)+social*(best-positions)
                positions+=velocity
                if cfg['bounds'] is not None: positions.clamp_(*cfg['bounds'])
                candidate=fitness(positions); improve=candidate<values
                personal[improve]=positions[improve]; values[improve]=candidate[improve]
                best=personal[int(values.argmin())].clone()
                cr=float((cognitive+social).mean())
            factor=cr/cfg['eta'] if cfg['scale']=='legacy' else 1/max(1,output.shape[0])
            estimated=(output.detach()-best)*factor
            value=loss_fn(output.detach())
            self.evaluations+=1
            self.last_best=best; self.last_gradient=estimated
        return _Bridge.apply(output,value,estimated)
