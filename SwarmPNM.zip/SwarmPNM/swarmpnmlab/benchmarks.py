"""The 15 two-dimensional formulas printed in manuscript BDCC-4611382.

Names preserve manuscript terminology, including its noncanonical Levy and
Modified Easom-type. These formulas are not silently repaired to match the
paper's claims about minima. Sphere is an additional elementary sanity check.
"""
import math
import torch

STARTS = {
    'rastrigin': (-2.,3.5), 'rosenbrock': (-2.,2.), 'ackley': (-2.,3.5),
    'levy': (-1.5,3.5), 'schwefel_220': (0.,7.5), 'modified_easom': (-7.5,7.5),
    'alpine': (-7.5,7.5), 'carrom': (.001,.001), 'pinter': (-7.5,7.5),
    'salomon': (-7.5,7.5), 'holder_table': (-10.,10.), 'plateau': (-4.,4.),
    'schaffer_n2': (-10.,10.), 'trefethen': (-7.5,7.5), 'weierstrass': (-5.,5.),
}
PAPER_FUNCTIONS = tuple(STARTS)
FUNCTIONS = PAPER_FUNCTIONS + ('sphere',)


def objective(name, x):
    if x.shape[-1] != 2:raise ValueError('Benchmark requires two coordinates')
    a,b=x[...,0],x[...,1]
    radius=torch.linalg.vector_norm(x,dim=-1)
    if name=='sphere':return x.square().sum(dim=-1)
    if name=='rastrigin':return 20+(x.square()-10*torch.cos(2*math.pi*x)).sum(dim=-1)
    if name=='rosenbrock':return 100*(b-a.square()).square()+(1-a).square()
    if name=='ackley':return -20*torch.exp(-.2*radius/math.sqrt(2))-torch.exp(torch.cos(2*math.pi*x).mean(dim=-1))+20+math.e
    if name=='levy':return torch.sin(3*math.pi*a).square()+(a-1).square()*(1+torch.sin(3*math.pi*b).square())+(b-1).square()*(1+torch.sin(2*math.pi*b).square())
    if name=='schwefel_220':return x.abs().sum(dim=-1)
    if name=='modified_easom':return 20-20*torch.exp(.2*radius/math.sqrt(2))+math.e-torch.exp(torch.cos(2*math.pi*x).mean(dim=-1))
    if name=='alpine':return (x*torch.sin(x)+.1*x).abs().sum(dim=-1)
    if name=='carrom':return -torch.exp(2*(1-radius/math.pi).abs())*torch.cos(a).square()*torch.cos(b).square()/30
    if name=='pinter':
        previous=x.flip(-1);following=previous
        index=x.new_tensor([1.,2.])
        A=previous*torch.sin(x)+torch.sin(following)
        B=previous.square()-2*x+3*following-torch.cos(x)+1
        return (index*x.square()+20*index*torch.sin(A).square()+index*torch.log10(1+index*B.square())).sum(dim=-1)
    if name=='salomon':return 1-torch.cos(2*math.pi*radius)+.1*radius
    if name=='holder_table':return -(torch.sin(a)*torch.cos(b)*torch.exp((1-radius/math.pi).abs())).abs()
    if name=='plateau':return torch.floor(x).sum(dim=-1)
    if name=='schaffer_n2':return .5+(torch.sin(a.square()-b.square()).square()-.5)/(1+.001*x.square().sum(dim=-1)).square()
    if name=='trefethen':return .25*(a.square()+b.square())+torch.exp(torch.sin(50*a))-torch.sin(10*(a+b))+torch.sin(60*torch.exp(b))+torch.sin(70*torch.sin(a))+torch.sin(torch.sin(80*b))
    if name=='weierstrass':
        k=torch.arange(21,device=x.device,dtype=x.dtype)
        amplitude=.5**k;frequency=3.**k
        angles=2*math.pi*frequency*(x.unsqueeze(-1)+.5)
        baseline=2*(amplitude*torch.cos(2*math.pi*frequency*.5)).sum()
        return (amplitude*torch.cos(angles)).sum(dim=(-1,-2))-baseline
    raise ValueError(f'Unknown benchmark: {name}')
