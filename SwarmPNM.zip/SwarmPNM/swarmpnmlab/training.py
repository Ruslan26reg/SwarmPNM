"""Repeatable stochastic training objective for SwarmPNM's best comparisons."""
import torch


class RepeatableClosure:
    """Same dropout draws and pre-step buffers for every objective evaluation.

    Commit buffers/RNG from the current-parameter forward exactly once.
    Only the initial call computes gradients; best/new probes use no_grad.
    """
    def __init__(self, model, optimizer, objective):
        self.model=model;self.optimizer=optimizer;self.objective=objective
        self.buffers={name:value.clone() for name,value in model.named_buffers()}
        self.rng=torch.get_rng_state().clone()
        self.committed_buffers=None;self.committed_rng=None;self.initial_loss=None

    def reset(self):
        with torch.no_grad():
            for name,value in self.model.named_buffers():value.copy_(self.buffers[name])
        torch.set_rng_state(self.rng)

    def __call__(self):
        self.reset();self.optimizer.zero_grad()
        loss=self.objective();loss.backward()
        if self.initial_loss is None:
            self.initial_loss=loss.detach().clone()
            self.committed_buffers={name:value.clone() for name,value in self.model.named_buffers()}
            self.committed_rng=torch.get_rng_state().clone()
        return loss

    @torch.no_grad()
    def evaluate(self):
        self.reset();return self.objective()

    def commit(self):
        with torch.no_grad():
            values=self.committed_buffers or self.buffers
            for name,value in self.model.named_buffers():value.copy_(values[name])
        torch.set_rng_state(self.committed_rng if self.committed_rng is not None else self.rng)
