"""Reconstructed research code; see recovery_notes.md for provenance."""
from .optimizers import SwarmPNM, DiffPNM, YogiPNM, CFGD, GLFGD
from .registry import make_method
