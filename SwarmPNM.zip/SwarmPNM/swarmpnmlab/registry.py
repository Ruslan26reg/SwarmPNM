import torch
from .optimizers import SwarmPNM,DiffPNM,YogiPNM,CFGD,GLFGD
from .adaswarm import AdaSwarmLoss

METHODS=('swarmpnm_sqrt','swarmpnm_inverse','adamw','adaswarm','diffpnm','yogipnm','cfgd','glfgd')

def make_method(name,params,config):
    c=dict(config)
    if name=='adamw': return torch.optim.AdamW(params,**c),None
    if name=='adaswarm':
        swarm=c.pop('swarm'); return torch.optim.Adam(params,**c),AdaSwarmLoss(**swarm)
    if name.startswith('swarmpnm_'): return SwarmPNM(params,variant=name.split('_')[1],**c),None
    cls={'diffpnm':DiffPNM,'yogipnm':YogiPNM,'cfgd':CFGD,'glfgd':GLFGD}.get(name)
    if cls is None: raise ValueError(f'Unknown method {name}; choose {METHODS}')
    return cls(params,**c),None
