import copy
import math
import torch
from torch.optim import Optimizer


def check(p):
    if p.device.type != 'cpu' or p.dtype not in (torch.float32, torch.float64):
        raise ValueError('Recovery optimizers support dense CPU float32/float64 only')
    if p.grad is not None:
        if p.grad.is_sparse:
            raise ValueError('Sparse gradients are not supported')
        if not torch.isfinite(p.grad).all():
            raise FloatingPointError('Non-finite gradient')
    if not torch.isfinite(p).all():
        raise FloatingPointError('Non-finite parameter')


class ResearchOptimizer(Optimizer):
    def __init__(self, params, defaults, seed=0):
        super().__init__(params, defaults)
        self.generator = torch.Generator().manual_seed(seed)
        self.meta = {}
        for group in self.param_groups:
            if group['lr'] < 0 or group.get('weight_decay', 0) < 0:
                raise ValueError('lr and weight_decay must be non-negative')
            for p in group['params']:
                check(p)

    def state_dict(self):
        out = super().state_dict()
        out['research_meta'] = copy.deepcopy(self.meta)
        out['rng_state'] = self.generator.get_state().clone()
        return out

    def load_state_dict(self, state_dict):
        d = copy.deepcopy(state_dict)
        self.meta = d.pop('research_meta')
        rng = d.pop('rng_state')
        super().load_state_dict(d)
        self.generator.set_state(rng)

    def active(self):
        for group in self.param_groups:
            for p in group['params']:
                check(p)
                if p.grad is not None:
                    yield group, p, self.state[p]


class DiffPNM(ResearchOptimizer):
    """Sequential PNM in authors' equations (not alternating-buffer AdaPNM).

    Historical bias denominator 1-beta1**t is deliberately retained.
    Weight decay is coupled, applied before moments and friction.
    """
    def __init__(self, params, lr=1e-3, beta0=.9, beta1=.9, beta2=.999,
                 eps=1e-8, weight_decay=0, normalization='printed'):
        if not all(0 <= x < 1 for x in (beta0, beta1, beta2)) or eps <= 0:
            raise ValueError('Invalid moment coefficients or epsilon')
        if normalization not in ('printed','pnm_variance'): raise ValueError('Unknown PNM normalization')
        super().__init__(params, dict(lr=lr,beta0=beta0,beta1=beta1,beta2=beta2,
                                     eps=eps,weight_decay=weight_decay,normalization=normalization))

    @staticmethod
    def normalization(q):
        b0=q['beta0']
        return math.sqrt(1+2*b0*b0) if q['normalization']=='printed' else math.sqrt((1+b0)**2+b0*b0)

    @torch.no_grad()
    def step(self, closure=None):
        loss = None
        if closure is not None:
            with torch.enable_grad(): loss = closure()
        for q,p,s in self.active():
            if not s:
                s.update(t=0,m=torch.zeros_like(p),v=torch.zeros_like(p),
                         vmax=torch.zeros_like(p),previous_grad=torch.zeros_like(p))
            s['t'] += 1
            t=s['t']; b0=q['beta0']; b1=q['beta1']; b2=q['beta2']
            g=p.grad.add(p, alpha=q['weight_decay'])
            previous_m=s['m'].clone()
            s['m'].mul_(b1*b1).add_(g,alpha=1-b1*b1)
            s['v'].mul_(b2).addcmul_(g,g,value=1-b2)
            torch.maximum(s['vmax'],s['v'],out=s['vmax'])
            mhat=((1+b0)*s['m']-b0*previous_m)/(1-b1**t)
            vhat=s['vmax']/(1-b2**t)
            friction=torch.sigmoid((g-s['previous_grad']).abs())
            p.addcdiv_(friction*mhat,vhat.sqrt().add(q['eps']),
                       value=-q['lr']/self.normalization(q))
            s['previous_grad'].copy_(g)
        return loss


class YogiPNM(DiffPNM):
    """Explicit interpretations: 'corrected' or 'literal_2024'.

    literal follows printed Algorithm 1, including signed first moment and
    plus-sign second moment. corrected uses ordinary first moment and
    nonnegative Yogi recurrence with a minus sign (documented correction).
    """
    def __init__(self, params, interpretation='corrected', **kwargs):
        if interpretation not in ('corrected','literal_2024'):
            raise ValueError('Unknown YogiPNM interpretation')
        super().__init__(params, **kwargs)
        for group in self.param_groups: group['interpretation']=interpretation

    @torch.no_grad()
    def step(self, closure=None):
        loss=None
        if closure is not None:
            with torch.enable_grad(): loss=closure()
        for q,p,s in self.active():
            if not s:
                s.update(t=0,m=torch.zeros_like(p),v=torch.zeros_like(p),vmax=torch.zeros_like(p))
            s['t']+=1
            t=s['t']; b0=q['beta0']; b1=q['beta1']; b2=q['beta2']
            g=p.grad.add(p,alpha=q['weight_decay']); g2=g.square()
            old=s['m'].clone(); sign=(s['v']-g2).sign()
            if q['interpretation']=='literal_2024':
                s['m'].mul_(b1*b1).add_(sign*g,alpha=1-b1*b1)
                s['v'].mul_(b2).add_(sign*g2,alpha=1-b2)
            else:
                s['m'].mul_(b1*b1).add_(g,alpha=1-b1*b1)
                s['v'].add_(sign*g2,alpha=-(1-b2))
            torch.maximum(s['vmax'],s['v'],out=s['vmax'])
            mhat=((1+b0)*s['m']-b0*old)/(1-b1**t)
            vhat=s['vmax']/(1-b2**t)
            p.addcdiv_(mhat,vhat.sqrt().add(q['eps']),
                       value=-q['lr']/self.normalization(q))
        return loss


class CFGD(ResearchOptimizer):
    """One-term Caputo Taylor approximation, NOT recovered historical code.

    D_c^a f(x) ~= f'(x)*(x-c)^(1-a)/Gamma(2-a).
    Fixed lower terminal c, real-valued x>=c, zero-memory approximation.
    Box projection keeps the real domain; no abs(x-c) substitution.
    """
    def __init__(self, params, lr=1e-3, order=.9, anchor=-10., weight_decay=0):
        if not 0 < order <= 1: raise ValueError('Caputo order must be in (0,1]')
        super().__init__(params,dict(lr=lr,order=order,anchor=anchor,weight_decay=weight_decay))

    @torch.no_grad()
    def step(self, closure=None):
        loss=None
        if closure is not None:
            with torch.enable_grad(): loss=closure()
        for q,p,s in self.active():
            if torch.any(p<q['anchor']): raise ValueError('CFGD parameter below fixed Caputo anchor')
            factor=(p-q['anchor']).pow(1-q['order'])/math.gamma(2-q['order'])
            direction=p.grad*factor+q['weight_decay']*p
            p.add_(direction,alpha=-q['lr']).clamp_(min=q['anchor'])
            s['t']=s.get('t',0)+1
        return loss


class GLFGD(ResearchOptimizer):
    """Zhou et al. 2023 Algorithm 1: modified GL recurrence, h=1,
    past ten gradients and one randomly dropped history term per step.
    This is the paper's modified temporal GL, not coordinate-wise exact GL.
    """
    def __init__(self, params, lr=1e-3, order=.9, memory=10, dropout=True,
                 weight_decay=0, seed=0):
        if memory != 10 or not math.isfinite(order):
            raise ValueError('Published GLFGD uses memory=10 and a finite order')
        super().__init__(params,dict(lr=lr,order=order,memory=memory,dropout=dropout,
                                     weight_decay=weight_decay),seed=seed)

    @torch.no_grad()
    def step(self, closure=None):
        loss=None
        if closure is not None:
            with torch.enable_grad(): loss=closure()
        # One shuffled coefficient vector shared by the whole parameter trajectory.
        drop=int(torch.randint(10,(),generator=self.generator))
        self.meta['last_drop']=drop
        for q,p,s in self.active():
            if not s: s.update(t=0,history=[])
            d=p.grad.clone(); w=1.
            for j in range(1,11):
                w*=1-(q['order']+1)/(j+1)
                if j<=len(s['history']) and (not q['dropout'] or j-1!=drop):
                    d.add_(s['history'][j-1],alpha=w)
            d.add_(p,alpha=q['weight_decay'])
            s['history']=[p.grad.clone()]+s['history'][:9]; s['t']+=1
            p.add_(d,alpha=-q['lr'])
        return loss


class SwarmPNM(ResearchOptimizer):
    """Single trajectory, P=G. No invented particle population.

    closure must zero gradients, backward and return a scalar on the SAME
    objective within a step. Best objective re-evaluated each step to avoid
    comparing losses from different mini-batches. Closure may be called three
    times. Use a deterministic model/objective, with no side effects.
    """
    def __init__(self, params, lr=3e-4, beta0=.88, beta1=.92, beta2=.998,
                 c1=.25, c2=.45, delta=1e-6, eps=1e-8, variant='sqrt',
                 bounds=None, lambda_manuscript=0., seed=0):
        if not all(math.isfinite(x) for x in (lr,beta0,beta1,beta2,c1,c2,delta,eps,lambda_manuscript)):
            raise ValueError('SwarmPNM coefficients must be finite')
        if bounds is not None and (len(bounds)!=2 or not all(math.isfinite(x) for x in bounds)):
            raise ValueError('SwarmPNM bounds must contain two finite numbers')
        if variant not in ('sqrt','inverse'): raise ValueError('SwarmPNM variant must be sqrt or inverse')
        if not all(0<=x<1 for x in (beta0,beta1,beta2)) or delta<=0 or eps<=0:
            raise ValueError('Invalid SwarmPNM coefficients')
        if c1<0 or c2<0 or (bounds is not None and bounds[0]>=bounds[1]):
            raise ValueError('Invalid swarm coefficients or bounds')
        if variant=='inverse' and bounds is None:
            raise ValueError('Algorithm 1 inverse variant requires explicit box bounds')
        super().__init__(params,dict(lr=lr,beta0=beta0,beta1=beta1,beta2=beta2,c1=c1,c2=c2,
                                     delta=delta,eps=eps,variant=variant,bounds=bounds,
                                     lambda_manuscript=lambda_manuscript),seed)

    @torch.no_grad()
    def step(self, closure=None):
        if closure is None: raise ValueError('SwarmPNM requires an objective closure for best selection')
        with torch.enable_grad(): before=closure()
        if not torch.isfinite(before): raise FloatingPointError('Non-finite SwarmPNM objective')
        active=list(self.active())
        if not active: return before
        all_params=[p for q in self.param_groups for p in q['params']]
        for p in all_params:
            s=self.state[p]
            if 'best' not in s: s['best']=p.clone()
        # Compare whole-model snapshots, never individual tensor losses.
        current=[p.clone() for p in all_params]
        gradients=[None if p.grad is None else p.grad.clone() for p in all_params]
        try:
            for p in all_params: p.copy_(self.state[p]['best'])
            if hasattr(closure,'evaluate'):
                best_loss=closure.evaluate()
            else:
                with torch.enable_grad(): best_loss=closure()
        finally:
            for p,x,g in zip(all_params,current,gradients): p.copy_(x); p.grad=g
        if float(before)<float(best_loss):
            for p in all_params: self.state[p]['best'].copy_(p)
            best_loss=before
        r=torch.rand(2,generator=self.generator,dtype=torch.float64)
        self.meta['last_random']=r.tolist()
        for q,p,s in active:
            if 'm' not in s:
                s.update(t=0,m=torch.zeros_like(p),v=torch.zeros_like(p),
                         vmax=torch.zeros_like(p),velocity=torch.zeros_like(p))
            s['t']+=1; t=s['t']; b0=q['beta0']; b1=q['beta1']; b2=q['beta2']
            old=s['m'].clone(); g=p.grad
            s['m'].mul_(b1*b1).add_(g,alpha=1-b1*b1)
            mh=((1+b0)*s['m']-b0*old)/(1-b1**(2*t))
            s['v'].mul_(b2).addcmul_(g,g,value=1-b2)
            torch.maximum(s['vmax'],s['v'],out=s['vmax'])
            V=s['vmax']+q['delta']/t
            s['velocity'].add_(s['best']-p,alpha=q['c1']*float(r[0])+q['c2']*float(r[1]))
            denom=V.sqrt()+q['eps'] if q['variant']=='sqrt' else V
            p.add_(s['velocity']).addcdiv_(mh,denom,value=-q['lr']/math.sqrt((1+b0)**2+b0*b0))
            if q['bounds'] is not None: p.clamp_(*q['bounds'])
        if hasattr(closure,'evaluate'):
            after=closure.evaluate()
        else:
            with torch.enable_grad(): after=closure()
        if not torch.isfinite(after): raise FloatingPointError('Non-finite SwarmPNM objective after update')
        if float(after)<float(best_loss):
            for p in all_params: self.state[p]['best'].copy_(p)
            best_loss=after
        self.meta['best_loss']=float(best_loss)
        self.meta['trajectory_steps']=self.meta.get('trajectory_steps',0)+1
        return after
